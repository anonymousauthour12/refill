CREATE TABLE `Course` (
  `course_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `instructor` varchar(60) DEFAULT NULL,
  `credit_hours` int DEFAULT NULL,
  `total_enrollments` int DEFAULT NULL,
  `pass_rate` float DEFAULT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32522 DEFAULT CHARSET=utf8mb3;
CREATE TABLE `Enrollment` (
  `std_id` int NOT NULL,
  `course_id` int NOT NULL,
  `grade` float DEFAULT NULL,
  `passed` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`std_id`,`course_id`),
  KEY `FK_2` (`course_id`),
  CONSTRAINT `FK_1` FOREIGN KEY (`std_id`) REFERENCES `Student` (`std_id`),
  CONSTRAINT `FK_2` FOREIGN KEY (`course_id`) REFERENCES `Course` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
CREATE TABLE `Student` (
  `std_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `birth_date` date NOT NULL,
  `gpa` float DEFAULT NULL,
  PRIMARY KEY (`std_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

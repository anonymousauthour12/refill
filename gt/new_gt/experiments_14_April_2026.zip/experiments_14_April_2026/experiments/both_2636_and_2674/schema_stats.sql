CREATE TABLE `badges` (
  `Id` int NOT NULL,
  `UserId` int DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `badges_UserId_fkey` (`UserId`),
  CONSTRAINT `badges_UserId_fkey` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
CREATE TABLE `comments` (
  `Id` int NOT NULL,
  `PostId` int DEFAULT NULL,
  `Score` int DEFAULT NULL,
  `Text` longtext,
  `CreationDate` datetime DEFAULT NULL,
  `UserId` int DEFAULT NULL,
  `UserDisplayName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `comment_staged_UserId_fkey` (`UserId`),
  KEY `comment_PostId_fkey` (`PostId`),
  CONSTRAINT `comment_PostId_fkey` FOREIGN KEY (`PostId`) REFERENCES `posts` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `comment_staged_UserId_fkey` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
CREATE TABLE `postHistory` (
  `Id` int NOT NULL,
  `PostHistoryTypeId` int DEFAULT NULL,
  `PostId` int DEFAULT NULL,
  `RevisionGUID` varchar(255) DEFAULT NULL,
  `CreationDate` datetime DEFAULT NULL,
  `UserId` int DEFAULT NULL,
  `Text` longtext,
  `Comment` text,
  `UserDisplayName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `postHistory_Id_key` (`Id`),
  KEY `postHistory_UserId_fkey` (`UserId`),
  KEY `postHistory_PostId_fkey` (`PostId`),
  CONSTRAINT `postHistory_PostId_fkey` FOREIGN KEY (`PostId`) REFERENCES `posts` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `postHistory_UserId_fkey` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
CREATE TABLE `postLinks` (
  `Id` int NOT NULL,
  `CreationDate` datetime DEFAULT NULL,
  `PostId` int DEFAULT NULL,
  `RelatedPostId` int DEFAULT NULL,
  `LinkTypeId` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `postlinks_stripped_PostId_fkey` (`PostId`),
  KEY `postlinks_stripped_RelatedPostId_fkey` (`RelatedPostId`),
  CONSTRAINT `postlinks_stripped_PostId_fkey` FOREIGN KEY (`PostId`) REFERENCES `posts` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `postlinks_stripped_RelatedPostId_fkey` FOREIGN KEY (`RelatedPostId`) REFERENCES `posts` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
CREATE TABLE `posts` (
  `Id` int NOT NULL,
  `PostTypeId` int DEFAULT NULL,
  `AcceptedAnswerId` int DEFAULT NULL,
  `CreaionDate` datetime DEFAULT NULL,
  `Score` int DEFAULT NULL,
  `ViewCount` int DEFAULT NULL,
  `Body` longtext,
  `OwnerUserId` int DEFAULT NULL,
  `LasActivityDate` datetime DEFAULT NULL,
  `Title` varchar(255) DEFAULT NULL,
  `Tags` varchar(255) DEFAULT NULL,
  `AnswerCount` int DEFAULT NULL,
  `CommentCount` int DEFAULT NULL,
  `FavoriteCount` int DEFAULT NULL,
  `LastEditorUserId` int DEFAULT NULL,
  `LastEditDate` datetime DEFAULT NULL,
  `CommunityOwnedDate` datetime DEFAULT NULL,
  `ParentId` int DEFAULT NULL,
  `ClosedDate` datetime DEFAULT NULL,
  `OwnerDisplayName` varchar(255) DEFAULT NULL,
  `LastEditorDisplayName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `posts_Id_key` (`Id`),
  KEY `posts_ParentId_fkey` (`ParentId`),
  KEY `posts_OwnerUserId_fkey` (`OwnerUserId`),
  KEY `posts_LastEditorUserId_fkey` (`LastEditorUserId`),
  CONSTRAINT `posts_LastEditorUserId_fkey` FOREIGN KEY (`LastEditorUserId`) REFERENCES `users` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `posts_OwnerUserId_fkey` FOREIGN KEY (`OwnerUserId`) REFERENCES `users` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `posts_ParentId_fkey` FOREIGN KEY (`ParentId`) REFERENCES `posts` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
CREATE TABLE `tags` (
  `Id` int NOT NULL,
  `TagName` varchar(255) DEFAULT NULL,
  `Count` int DEFAULT NULL,
  `ExcerptPostId` int DEFAULT NULL,
  `WikiPostId` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `tags_ExcerptPostId_fkey` (`ExcerptPostId`),
  CONSTRAINT `tags_ExcerptPostId_fkey` FOREIGN KEY (`ExcerptPostId`) REFERENCES `posts` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
CREATE TABLE `users` (
  `Id` int NOT NULL,
  `Reputation` int DEFAULT NULL,
  `CreationDate` datetime DEFAULT NULL,
  `DisplayName` varchar(255) DEFAULT NULL,
  `LastAccessDate` datetime DEFAULT NULL,
  `WebsiteUrl` varchar(255) DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `AboutMe` longtext,
  `Views` int DEFAULT NULL,
  `UpVotes` int DEFAULT NULL,
  `DownVotes` int DEFAULT NULL,
  `AccountId` int DEFAULT NULL,
  `Age` int DEFAULT NULL,
  `ProfileImageUrl` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `users_staged_Id_key` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
CREATE TABLE `votes` (
  `Id` int NOT NULL,
  `PostId` int DEFAULT NULL,
  `VoteTypeId` int DEFAULT NULL,
  `CreationDate` date DEFAULT NULL,
  `UserId` int DEFAULT NULL,
  `BountyAmount` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `votes_stripped_UserId_fkey` (`UserId`),
  KEY `votes_stripped_PostId_fkey` (`PostId`),
  CONSTRAINT `votes_stripped_PostId_fkey` FOREIGN KEY (`PostId`) REFERENCES `posts` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `votes_stripped_UserId_fkey` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

##########################################################################################################################################################################################################################################
SELECT `target_table`.`PlannedCost` AS computed_value, `target_table`.`ActualCost` AS actual_value FROM `WorkOrderRouting` AS `target_table`;
##########################################################################################################################################################################################################################################
SELECT
  (CAST(target_table.ActualResourceHrs AS DECIMAL(38,10)) * (CAST(target_table.PlannedCost AS DECIMAL(38,10)) / NULLIF(CAST(target_table.ActualResourceHrs AS DECIMAL(38,10)), 0))) AS computed_value,
  target_table.ActualCost AS actual_value
FROM WorkOrderRouting AS target_table;
##########################################################################################################################################################################################################################################
SELECT
  CAST(l.CostRate AS DECIMAL(19,4)) * CAST(target_table.ActualResourceHrs AS DECIMAL(19,4)) AS computed_value,
  target_table.ActualCost AS actual_value
FROM WorkOrderRouting AS target_table
INNER JOIN Location AS l ON l.LocationID = target_table.LocationID;
##########################################################################################################################################################################################################################################
SELECT 
  CAST(target_table.ActualResourceHrs AS DECIMAL(19,4)) * r.rate AS computed_value,
  target_table.ActualCost AS actual_value
FROM WorkOrderRouting AS target_table
JOIN WorkOrder w
  ON w.WorkOrderID = target_table.WorkOrderID
LEFT JOIN (
  SELECT 
    wr.LocationID,
    YEAR(w2.StartDate) AS yr,
    (SUM(wr.PlannedCost) / NULLIF(SUM(wr.ActualResourceHrs), 0)) AS rate
  FROM WorkOrderRouting wr
  JOIN WorkOrder w2
    ON w2.WorkOrderID = wr.WorkOrderID
  GROUP BY wr.LocationID, YEAR(w2.StartDate)
) r
  ON r.LocationID = target_table.LocationID
 AND r.yr = YEAR(w.StartDate);
##########################################################################################################################################################################################################################################
SELECT 
  CAST(target_table.ActualResourceHrs AS DECIMAL(19,4)) * rp.rate AS computed_value,
  target_table.ActualCost AS actual_value
FROM WorkOrderRouting AS target_table
LEFT JOIN ProductCostHistory pch_curr
  ON pch_curr.ProductID = target_table.ProductID
 AND target_table.ActualStartDate BETWEEN pch_curr.StartDate AND COALESCE(pch_curr.EndDate, '9999-12-31')
LEFT JOIN (
  SELECT 
    wr.LocationID,
    pch.StartDate AS pch_startdate,
    (SUM(wr.PlannedCost) / NULLIF(SUM(wr.ActualResourceHrs), 0)) AS rate
  FROM WorkOrderRouting wr
  JOIN ProductCostHistory pch
    ON pch.ProductID = wr.ProductID
   AND wr.ActualStartDate BETWEEN pch.StartDate AND COALESCE(pch.EndDate, '9999-12-31')
  GROUP BY wr.LocationID, pch.StartDate
) rp
  ON rp.LocationID = target_table.LocationID
 AND rp.pch_startdate = pch_curr.StartDate;
##########################################################################################################################################################################################################################################
SELECT 
  (CAST(target_table.ActualResourceHrs AS DECIMAL(19,4)) * rate_by_step_loc.hourly_rate) AS computed_value,
  target_table.ActualCost AS actual_value
FROM WorkOrderRouting AS target_table
LEFT JOIN (
  SELECT 
    wr.OperationSequence,
    wr.LocationID,
    (SUM(wr.PlannedCost) / NULLIF(SUM(wr.ActualResourceHrs), 0)) AS hourly_rate
  FROM WorkOrderRouting wr
  INNER JOIN WorkOrder wo ON wo.WorkOrderID = wr.WorkOrderID
  INNER JOIN Product p ON p.ProductID = wo.ProductID
  WHERE wr.ActualResourceHrs IS NOT NULL AND wr.ActualResourceHrs > 0
  GROUP BY wr.OperationSequence, wr.LocationID
) AS rate_by_step_loc
  ON rate_by_step_loc.OperationSequence = target_table.OperationSequence
 AND rate_by_step_loc.LocationID = target_table.LocationID;
##########################################################################################################################################################################################################################################
SELECT 
  (CAST(target_table.ActualResourceHrs AS DECIMAL(19,4)) * rate_by_loc.hourly_rate) AS computed_value,
  target_table.ActualCost AS actual_value
FROM WorkOrderRouting AS target_table
LEFT JOIN (
  SELECT 
    wr.LocationID,
    (SUM(wr.PlannedCost) / NULLIF(SUM(wr.ActualResourceHrs), 0)) AS hourly_rate
  FROM WorkOrderRouting wr
  INNER JOIN WorkOrder wo ON wo.WorkOrderID = wr.WorkOrderID
  INNER JOIN Product p ON p.ProductID = wo.ProductID
  WHERE wr.ActualResourceHrs IS NOT NULL AND wr.ActualResourceHrs > 0
  GROUP BY wr.LocationID
) AS rate_by_loc
  ON rate_by_loc.LocationID = target_table.LocationID;
##########################################################################################################################################################################################################################################
SELECT
  (l.CostRate * target_table.ActualResourceHrs) AS computed_value,
  target_table.ActualCost AS actual_value
FROM WorkOrderRouting AS target_table
JOIN Location AS l ON l.LocationID = target_table.LocationID;
##########################################################################################################################################################################################################################################
SELECT
  (l.CostRate * target_table.ActualResourceHrs * (CAST(w.StockedQty AS DECIMAL(19,4)) / NULLIF(CAST(w.OrderQty AS DECIMAL(19,4)), 0))) AS computed_value,
  target_table.ActualCost AS actual_value
FROM WorkOrderRouting AS target_table
JOIN Location AS l ON l.LocationID = target_table.LocationID
LEFT JOIN WorkOrder AS w ON w.WorkOrderID = target_table.WorkOrderID AND w.ProductID = target_table.ProductID;

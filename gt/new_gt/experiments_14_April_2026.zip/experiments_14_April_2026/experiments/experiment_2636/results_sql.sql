# uni	Course	name	-1
-- Not computed
###########################################################
# uni	Course	instructor	-1
-- Not computed
###########################################################
# uni	Course	credit_hours	-1
-- Not computed
###########################################################
# uni	Enrollment	grade	-1
-- Not computed
###########################################################
# uni	Student	name	-1
-- Not computed
###########################################################
# uni	Student	birth_date	-1
-- Not computed
###########################################################
# Dallas	incidents	grand_jury_disposition	-1
-- Not computed
###########################################################
# Dallas	incidents	attorney_general_forms_url	-1
-- Not computed
###########################################################
# Dallas	incidents	latitude	-1
-- Not computed
###########################################################
# Mondial	borders	Length	-1
-- Not computed
###########################################################
# Mondial	city	Population	-1
-- Not computed
###########################################################
# Mondial	city	Longitude	-1
-- Not computed
###########################################################
# Mondial	city	Latitude	-1
-- Not computed
###########################################################
# Mondial	country	Name	-1
-- Not computed
###########################################################
# Mondial	desert	Area	-1
-- Not computed
###########################################################
# Mondial	desert	Longitude	-1
-- Not computed
###########################################################
# Mondial	desert	Latitude	-1
-- Not computed
###########################################################
# Mondial	economy	GDP	-1
-- Not computed
###########################################################
# Mondial	economy	Inflation	-1
-- Not computed
###########################################################
# Mondial	encompasses	Percentage	-1
-- Not computed
###########################################################
# Mondial	ethnicGroup	Percentage	-1
-- Not computed
###########################################################
# Mondial	isMember	Type	-1
-- Not computed
###########################################################
# Mondial	island	Islands	-1
-- Not computed
###########################################################
# Mondial	island	Area	-1
-- Not computed
###########################################################
# Mondial	island	Type	-1
-- Not computed
###########################################################
# Mondial	island	Latitude	-1
-- Not computed
###########################################################
# Mondial	lake	Area	-1
-- Not computed
###########################################################
# Mondial	lake	Depth	-1
-- Not computed
###########################################################
# Mondial	lake	Altitude	-1
-- Not computed
###########################################################
# Mondial	lake	Type	-1
-- Not computed
###########################################################
# Mondial	lake	River	-1
-- Not computed
###########################################################
# Mondial	lake	Longitude	-1
-- Not computed
###########################################################
# Mondial	lake	Latitude	-1
-- Not computed
###########################################################
# Mondial	language	Percentage	-1
-- Not computed
###########################################################
# Mondial	mountain	Mountains	-1
-- Not computed
###########################################################
# Mondial	mountain	Height	-1
-- Not computed
###########################################################
# Mondial	mountain	Type	-1
-- Not computed
###########################################################
# Mondial	mountain	Longitude	-1
-- Not computed
###########################################################
# Mondial	mountain	Latitude	-1
-- Not computed
###########################################################
# Mondial	organization	Name	-1
-- Not computed
###########################################################
# Mondial	organization	Established	-1
-- Not computed
###########################################################
# Mondial	politics	Independence	-1
-- Not computed
###########################################################
# Mondial	politics	Government	-1
-- Not computed
###########################################################
# Mondial	population	Population_Growth	-1
-- Not computed
###########################################################
# Mondial	population	Infant_Mortality	-1
-- Not computed
###########################################################
# Mondial	province	Population	-1
-- Not computed
###########################################################
# Mondial	province	Area	-1
-- Not computed
###########################################################
# Mondial	province	Capital	-1
-- Not computed
###########################################################
# Mondial	religion	Percentage	-1
-- Not computed
###########################################################
# Mondial	river	River	-1
-- Not computed
###########################################################
# Mondial	river	Sea	-1
-- Not computed
###########################################################
# Mondial	river	Length	-1
-- Not computed
###########################################################
# Mondial	river	SourceLongitude	-1
-- Not computed
###########################################################
# Mondial	river	SourceLatitude	-1
-- Not computed
###########################################################
# Mondial	river	Mountains	-1
-- Not computed
###########################################################
# Mondial	river	SourceAltitude	-1
-- Not computed
###########################################################
# Mondial	river	EstuaryLongitude	-1
-- Not computed
###########################################################
# Mondial	river	EstuaryLatitude	-1
-- Not computed
###########################################################
# Mondial	sea	Depth	-1
-- Not computed
###########################################################
# Mondial	target	Target	-1
-- Not computed
###########################################################
# PTE	pte_atm	Arg4	-1
-- Not computed
###########################################################
# PTE	pte_has_property	Arg1	-1
-- Not computed
###########################################################
# PTE	pte_has_property	Arg2	-1
-- Not computed
###########################################################
# PTE	pte_ind	Arg2	-1
-- Not computed
###########################################################
# employee	departments	dept_name	-1
-- Not computed
###########################################################
# employee	dept_emp	from_date	-1
-- Not computed
###########################################################
# employee	employees	birth_date	-1
-- Not computed
###########################################################
# employee	employees	first_name	-1
-- Not computed
###########################################################
# employee	employees	last_name	-1
-- Not computed
###########################################################
# employee	employees	gender	-1
-- Not computed
###########################################################
# employee	salaries	salary	-1
-- Not computed
###########################################################
# stats	badges	Name	-1
-- Not computed
###########################################################
# stats	badges	Date	-1
-- Not computed
###########################################################
# stats	comments	Score	-1
-- Not computed
###########################################################
# stats	comments	CreationDate	-1
-- Not computed
###########################################################
# stats	comments	UserDisplayName	-1
-- Not computed
###########################################################
# stats	postHistory	RevisionGUID	-1
-- Not computed
###########################################################
# stats	postHistory	CreationDate	-1
-- Not computed
###########################################################
# stats	postHistory	UserDisplayName	-1
-- Not computed
###########################################################
# stats	postLinks	CreationDate	-1
-- Not computed
###########################################################
# stats	postLinks	LinkTypeId	-1
-- Not computed
###########################################################
# stats	posts	ViewCount	-1
-- Not computed
###########################################################
# stats	posts	Title	-1
-- Not computed
###########################################################
# stats	posts	Tags	-1
-- Not computed
###########################################################
# stats	tags	TagName	-1
-- Not computed
###########################################################
# stats	users	Reputation	-1
-- Not computed
###########################################################
# stats	users	CreationDate	-1
-- Not computed
###########################################################
# stats	users	DisplayName	-1
-- Not computed
###########################################################
# stats	users	LastAccessDate	-1
-- Not computed
###########################################################
# stats	users	WebsiteUrl	-1
-- Not computed
###########################################################
# stats	users	Location	-1
-- Not computed
###########################################################
# stats	users	Views	-1
-- Not computed
###########################################################
# stats	users	AccountId	-1
-- Not computed
###########################################################
# stats	users	Age	-1
-- Not computed
###########################################################
# stats	users	ProfileImageUrl	-1
-- Not computed
###########################################################
# stats	votes	VoteTypeId	-1
-- Not computed
###########################################################
# stats	votes	CreationDate	-1
-- Not computed
###########################################################
# stats	votes	BountyAmount	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	MK	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	GL	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	BH	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	HO	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	TK	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	RB	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	IF	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	CL	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	CG	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	FF	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	FA	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	BR	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	CP	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	UP	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	CM	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	MI	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	1P	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	BO	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	GA	-1
-- Not computed
###########################################################
# AustralianFootball	match_stats	PP	-1
-- Not computed
###########################################################
# AustralianFootball	matches	start_dt	-1
-- Not computed
###########################################################
# AustralianFootball	matches	venue	-1
-- Not computed
###########################################################
# AustralianFootball	matches	att	-1
-- Not computed
###########################################################
# AustralianFootball	matches	h_q1g	-1
-- Not computed
###########################################################
# AustralianFootball	matches	h_q2g	-1
-- Not computed
###########################################################
# AustralianFootball	matches	h_q3g	-1
-- Not computed
###########################################################
# AustralianFootball	matches	h_q1b	-1
-- Not computed
###########################################################
# AustralianFootball	matches	h_q2b	-1
-- Not computed
###########################################################
# AustralianFootball	matches	h_q3b	-1
-- Not computed
###########################################################
# AustralianFootball	matches	a_q1g	-1
-- Not computed
###########################################################
# AustralianFootball	matches	a_q2g	-1
-- Not computed
###########################################################
# AustralianFootball	matches	a_q3g	-1
-- Not computed
###########################################################
# AustralianFootball	matches	a_q1b	-1
-- Not computed
###########################################################
# AustralianFootball	matches	a_q2b	-1
-- Not computed
###########################################################
# AustralianFootball	matches	a_q3b	-1
-- Not computed
###########################################################
# AustralianFootball	players	dob	-1
-- Not computed
###########################################################
# AustralianFootball	players	first_name	-1
-- Not computed
###########################################################
# AustralianFootball	players	last_name	-1
-- Not computed
###########################################################
# AustralianFootball	players	height	-1
-- Not computed
###########################################################
# AustralianFootball	teams	tname	-1
-- Not computed
###########################################################
# Basketball_men	coaches	won	-1
-- Not computed
###########################################################
# Basketball_men	coaches	lost	-1
-- Not computed
###########################################################
# Basketball_men	draft	draftRound	-1
-- Not computed
###########################################################
# Basketball_men	draft	draftSelection	-1
-- Not computed
###########################################################
# Basketball_men	draft	draftFrom	-1
-- Not computed
###########################################################
# Basketball_men	player_allstar	minutes	-1
-- Not computed
###########################################################
# Basketball_men	player_allstar	d_rebounds	-1
-- Not computed
###########################################################
# Basketball_men	player_allstar	assists	-1
-- Not computed
###########################################################
# Basketball_men	player_allstar	steals	-1
-- Not computed
###########################################################
# Basketball_men	player_allstar	personal_fouls	-1
-- Not computed
###########################################################
# Basketball_men	player_allstar	ft_attempted	-1
-- Not computed
###########################################################
# Basketball_men	player_allstar	ft_made	-1
-- Not computed
###########################################################
# Basketball_men	player_allstar	three_attempted	-1
-- Not computed
###########################################################
# Basketball_men	players	middleName	-1
-- Not computed
###########################################################
# Basketball_men	players	lastName	-1
-- Not computed
###########################################################
# Basketball_men	players	fullGivenName	-1
-- Not computed
###########################################################
# Basketball_men	players	nameNick	-1
-- Not computed
###########################################################
# Basketball_men	players	height	-1
-- Not computed
###########################################################
# Basketball_men	players	weight	-1
-- Not computed
###########################################################
# Basketball_men	players	college	-1
-- Not computed
###########################################################
# Basketball_men	players	collegeOther	-1
-- Not computed
###########################################################
# Basketball_men	players	birthDate	-1
-- Not computed
###########################################################
# Basketball_men	players	birthCity	-1
-- Not computed
###########################################################
# Basketball_men	players	birthState	-1
-- Not computed
###########################################################
# Basketball_men	players	birthCountry	-1
-- Not computed
###########################################################
# Basketball_men	players	highSchool	-1
-- Not computed
###########################################################
# Basketball_men	players	hsCity	-1
-- Not computed
###########################################################
# Basketball_men	players	hsCountry	-1
-- Not computed
###########################################################
# Basketball_men	players	deathDate	-1
-- Not computed
###########################################################
# Basketball_men	players	race	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	GP	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	GS	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	minutes	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	assists	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	steals	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	blocks	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	turnovers	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	PF	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	fgAttempted	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	ftAttempted	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	threeAttempted	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	PostGP	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	PostGS	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	PostMinutes	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	PostAssists	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	PostSteals	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	PostBlocks	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	PostTurnovers	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	PostPF	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	PostfgAttempted	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	PostftAttempted	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	PostthreeAttempted	-1
-- Not computed
###########################################################
# Basketball_men	players_teams	note	-1
-- Not computed
###########################################################
# Basketball_men	series_post	round	-1
-- Not computed
###########################################################
# Basketball_men	series_post	series	-1
-- Not computed
###########################################################
# Basketball_men	teams	franchID	-1
-- Not computed
###########################################################
# Basketball_men	teams	divID	-1
-- Not computed
###########################################################
# Basketball_men	teams	name	-1
-- Not computed
###########################################################
# Basketball_men	teams	o_oreb	-1
-- Not computed
###########################################################
# Basketball_men	teams	d_fga	-1
-- Not computed
###########################################################
# Basketball_men	teams	d_fta	-1
-- Not computed
###########################################################
# Basketball_men	teams	d_3pa	-1
-- Not computed
###########################################################
# Basketball_men	teams	d_oreb	-1
-- Not computed
###########################################################
# Basketball_men	teams	d_reb	-1
-- Not computed
###########################################################
# Basketball_men	teams	d_asts	-1
-- Not computed
###########################################################
# Basketball_men	teams	d_pf	-1
-- Not computed
###########################################################
# Basketball_men	teams	d_stl	-1
-- Not computed
###########################################################
# Basketball_men	teams	d_to	-1
-- Not computed
###########################################################
# Basketball_men	teams	d_blk	-1
-- Not computed
###########################################################
# Basketball_men	teams	confWon	-1
-- Not computed
###########################################################
# Basketball_men	teams	confLoss	-1
-- Not computed
###########################################################
# Basketball_men	teams	divWon	-1
-- Not computed
###########################################################
# Basketball_men	teams	divLoss	-1
-- Not computed
###########################################################
# Basketball_men	teams	arena	-1
-- Not computed
###########################################################
# Basketball_men	teams	attendance	-1
-- Not computed
###########################################################
# Chinook	Album	Title	-1
-- Not computed
###########################################################
# Chinook	Artist	Name	-1
-- Not computed
###########################################################
# Chinook	Customer	FirstName	-1
-- Not computed
###########################################################
# Chinook	Customer	LastName	-1
-- Not computed
###########################################################
# Chinook	Customer	Company	-1
-- Not computed
###########################################################
# Chinook	Customer	Phone	-1
-- Not computed
###########################################################
# Chinook	Customer	Fax	-1
-- Not computed
###########################################################
# Chinook	Customer	Email	-1
-- Not computed
###########################################################
# Chinook	Employee	LastName	-1
-- Not computed
###########################################################
# Chinook	Employee	BirthDate	-1
-- Not computed
###########################################################
# Chinook	Employee	HireDate	-1
-- Not computed
###########################################################
# Chinook	Employee	Address	-1
-- Not computed
###########################################################
# Chinook	Employee	PostalCode	-1
-- Not computed
###########################################################
# Chinook	Employee	Phone	-1
-- Not computed
###########################################################
# Chinook	Employee	Fax	-1
-- Not computed
###########################################################
# Chinook	Genre	Name	-1
-- Not computed
###########################################################
# Chinook	Invoice	InvoiceDate	-1
-- Not computed
###########################################################
# Chinook	Invoice	BillingState	-1
-- Not computed
###########################################################
# Chinook	InvoiceLine	Quantity	-1
-- Not computed
###########################################################
# Chinook	MediaType	Name	-1
-- Not computed
###########################################################
# Chinook	Playlist	Name	-1
-- Not computed
###########################################################
# Chinook	Track	Name	-1
-- Not computed
###########################################################
# Chinook	Track	Composer	-1
-- Not computed
###########################################################
# Chinook	Track	Milliseconds	-1
-- Not computed
###########################################################
# Chinook	Track	Bytes	-1
-- Not computed
###########################################################
# ErgastF1	circuits	circuitRef	-1
-- Not computed
###########################################################
# ErgastF1	circuits	name	-1
-- Not computed
###########################################################
# ErgastF1	circuits	location	-1
-- Not computed
###########################################################
# ErgastF1	circuits	lat	-1
-- Not computed
###########################################################
# ErgastF1	circuits	lng	-1
-- Not computed
###########################################################
# ErgastF1	circuits	alt	-1
-- Not computed
###########################################################
# ErgastF1	circuits	url	-1
-- Not computed
###########################################################
# ErgastF1	constructorResults	status	-1
-- Not computed
###########################################################

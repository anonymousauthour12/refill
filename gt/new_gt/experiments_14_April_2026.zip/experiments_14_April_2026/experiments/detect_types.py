import csv, re
from collections import Counter

filepath = "C:/Users/QCRI-MMG25/OneDrive - Hamad bin Khalifa University/Desktop/Work/experiments_14_April_2026/experiments_14_April_2026/experiments/cc.csv"

with open(filepath, newline='', encoding='utf-8') as f:
    rows = list(csv.reader(f))

aa_idx = rows[0].index('further_simplified_sql')
f_idx  = rows[0].index('numeric')
g_idx  = rows[0].index('string')
h_idx  = rows[0].index('date')

def unwrap(e):
    e = e.strip()
    while e.startswith('(') and e.endswith(')'):
        depth = 0
        for i, c in enumerate(e):
            if c == '(':  depth += 1
            elif c == ')': depth -= 1
            if depth == 0 and i < len(e) - 1:
                return e
        e = e[1:-1].strip()
    return e

def first_arg(s):
    depth = 0
    for i, c in enumerate(s):
        if c == '(':   depth += 1
        elif c == ')': depth -= 1
        elif c == ',' and depth == 0:
            return s[:i].strip()
    return s.strip()

def nth_arg(s, n):
    depth, start, idx = 0, 0, 0
    for i, c in enumerate(s):
        if c == '(':   depth += 1
        elif c == ')': depth -= 1
        elif c == ',' and depth == 0:
            if idx == n: return s[start:i].strip()
            idx += 1
            start = i + 1
    return s[start:].strip() if idx == n else ''

def col_name_type(name):
    n = name.lower().strip('`')
    # _at suffix: Rails/web convention for timestamp columns (created_at, closed_at, etc.)
    if n.endswith('_at'): return 'date'
    date_kw = ['date','time','start','end','created','modified','updated','born','death',
               'dob','timestamp','hiredate','schedend','schedstart','sched','from_date',
               'to_date','birthdate','deathdate','modifieddate','orderdate','shipdate',
               'duedate','startdate','enddate','min_creation','max_creation']
    str_kw  = ['name','desc','title','text','label','code','type','status','state',
               'address','city','country','region','comment','note','message','email',
               'phone','nation','node','body','wiki','init','model','category','street',
               'zip','postal','addr','birth_state','death_state','nationality',
               'gender','sex','language','lang','format','mode','map','key']
    num_kw  = ['id','count','num','number','total','sum','avg','amount','price','rate',
               'ratio','score','pts','gp','games','wins','losses','points','goals',
               'assists','rebounds','qty','quantity','salary','cost','level','rank','age',
               'size','length','width','height','weight','value','pct','percent','fraction',
               'days','hours','minutes','seconds','votes','round','season','year','yr','mnth',
               'day','hour','week','depth','hops','result','val','cnt',
               'profit','revenue','fee','tax','discount','margin','diff','delta',
               'pos','position','post_a','computed_g','computed_w','computed_l',
               'w','l','t','g','a']
    for kw in date_kw:
        if kw in n: return 'date'
    for kw in str_kw:
        if kw in n: return 'string'
    for kw in num_kw:
        if kw in n or n == kw: return 'numeric'
    return 'unknown'

def detect(expr, d=0):
    if d > 6: return 'unknown'
    if not expr or not expr.strip(): return 'unknown'
    e = unwrap(expr.strip())
    eu = e.upper()

    if re.match(r'^-?\d+(\.\d+)?$', e): return 'numeric'
    if e.startswith("'"): return 'string'
    if eu == 'NULL': return 'unknown'

    # scalar subquery
    if eu.startswith('SELECT ') or eu.startswith('SELECT\t'):
        sub_m = re.match(r'SELECT\s+(?:DISTINCT\s+)?', eu)
        rest = e[sub_m.end():]
        depth2 = 0
        for i2, c in enumerate(rest):
            if c == '(':   depth2 += 1
            elif c == ')': depth2 -= 1
            elif depth2 == 0:
                if c == ',': return detect(rest[:i2].strip(), d+1)
                if re.match(r'\bFROM\b', rest[i2:], re.IGNORECASE):
                    part = rest[:i2].strip()
                    part = re.sub(r'\s+AS\s+\S+\s*$', '', part, flags=re.IGNORECASE).strip()
                    return detect(part, d+1)
        return detect(rest.strip(), d+1)

    # CAST
    if re.match(r'CAST\s*\(', eu):
        m = re.search(r'\bAS\s+(SIGNED|UNSIGNED|INT(?:EGER)?|BIGINT|SMALLINT|TINYINT|'
                      r'DECIMAL|FLOAT|DOUBLE|NUMERIC|REAL|'
                      r'DATE|DATETIME|TIMESTAMP|TIME|'
                      r'CHAR|VARCHAR|TEXT|NCHAR|NVARCHAR|BINARY|STRING)\b', eu)
        if m:
            t = m.group(1)
            if t in ('SIGNED','UNSIGNED','INT','INTEGER','BIGINT','SMALLINT','TINYINT',
                     'DECIMAL','FLOAT','DOUBLE','NUMERIC','REAL'): return 'numeric'
            if t in ('DATE','DATETIME','TIMESTAMP','TIME'): return 'date'
            if t in ('CHAR','VARCHAR','TEXT','NCHAR','NVARCHAR','BINARY','STRING'): return 'string'

    # date functions
    if re.match(r'(DATE_ADD|DATE_SUB|STR_TO_DATE|ADDDATE|SUBDATE|FROM_UNIXTIME|'
                r'MAKEDATE|LAST_DAY|CURDATE|CURRENT_DATE|NOW|SYSDATE|'
                r'DATE|DATETIME|TIMESTAMP|SEC_TO_TIME)\s*[\(\s]', eu):
        return 'date'

    # numeric functions
    if re.match(r'(COUNT|SUM|AVG|ROUND|FLOOR|CEIL(?:ING)?|ABS|SQRT|LOG|POW(?:ER)?|'
                r'DATEDIFF|TIMESTAMPDIFF|YEAR|MONTH|DAY|HOUR|MINUTE|SECOND|WEEK|'
                r'DAYOFWEEK|DAYOFYEAR|QUARTER|WEEKDAY|LENGTH|LEN|CHAR_LENGTH|'
                r'CHARACTER_LENGTH|BIT_LENGTH|ROW_NUMBER|RANK|DENSE_RANK|NTILE|'
                r'STD(?:DEV)?|VARIANCE|MOD|EXP|SIGN|TRUNCATE|PI|RAND)\s*\(', eu):
        return 'numeric'

    # string functions
    if re.match(r'(CONCAT(?:_WS)?|SUBSTR(?:ING(?:_INDEX)?)?|UPPER|LOWER|TRIM|[LR]TRIM|'
                r'REPLACE|REGEXP_REPLACE|LEFT|RIGHT|SPACE|REPEAT|REVERSE|LPAD|RPAD|'
                r'HEX|BIN|DATE_FORMAT|TIME_FORMAT|GROUP_CONCAT|FORMAT|CHAR)\s*\(', eu):
        return 'string'

    # COALESCE
    if re.match(r'COALESCE\s*\(', eu):
        inner = e[re.match(r'COALESCE\s*\(', eu).end():].rstrip(')')
        t = detect(first_arg(inner), d+1)
        if t != 'unknown': return t
        return detect(nth_arg(inner, 1), d+1)

    # MAX / MIN
    if re.match(r'(MAX|MIN)\s*\(', eu):
        inner = e[re.match(r'(MAX|MIN)\s*\(', eu).end():].rstrip(')')
        return detect(inner.strip(), d+1)

    # GREATEST / LEAST
    if re.match(r'(GREATEST|LEAST)\s*\(', eu):
        inner = e[re.match(r'(GREATEST|LEAST)\s*\(', eu).end():].rstrip(')')
        return detect(first_arg(inner), d+1)

    # NULLIF
    if re.match(r'NULLIF\s*\(', eu):
        inner = e[re.match(r'NULLIF\s*\(', eu).end():].rstrip(')')
        return detect(first_arg(inner), d+1)

    # IF(cond, then, else)
    if re.match(r'IF\s*\(', eu):
        inner = e[re.match(r'IF\s*\(', eu).end():].rstrip(')')
        return detect(nth_arg(inner, 1), d+1)

    # CASE WHEN
    if eu.startswith('CASE'):
        votes = Counter()
        for v in re.findall(r'\bTHEN\s+(.*?)(?=\s+(?:WHEN|ELSE|END)\b)', e, re.I|re.S):
            t = detect(v.strip(), d+1)
            if t != 'unknown': votes[t] += 1
        for v in re.findall(r'\bELSE\s+(.*?)(?=\s+END\b)', e, re.I|re.S):
            t = detect(v.strip(), d+1)
            if t != 'unknown': votes[t] += 1
        if votes: return votes.most_common(1)[0][0]

    # numeric literal / arithmetic
    if re.match(r'\d', e): return 'numeric'
    if re.search(r'[\+\-\*\/]', e): return 'numeric'

    # column reference
    col_m = re.match(r'`?\w+`?\s*\.\s*`?(\w+)`?', e)
    if col_m: return col_name_type(col_m.group(1))
    bare_m = re.match(r'`?(\w+)`?$', e)
    if bare_m: return col_name_type(bare_m.group(1))

    return 'unknown'

def extract_computed_expr(sql):
    sql = sql.strip()
    m = re.match(r'SELECT\s+(?:DISTINCT\s+)?', sql, re.IGNORECASE)
    if not m: return None
    rest = sql[m.end():]
    as_m = re.search(r'\bAS\s+`?computed_value`?', rest, re.IGNORECASE)
    if not as_m: return None
    return rest[:as_m.start()].strip().rstrip(', \t')

# ── apply to file ─────────────────────────────────────────────────────────────
results = []
for i, row in enumerate(rows[1:], start=2):
    sql = row[aa_idx] if aa_idx < len(row) else ''
    expr = extract_computed_expr(sql) or ''
    t = detect(expr)
    results.append((i, t, expr[:80]))
    if t != 'unknown':
        row[f_idx] = 1 if t == 'numeric' else 0
        row[g_idx] = 1 if t == 'string'  else 0
        row[h_idx] = 1 if t == 'date'    else 0

with open(filepath, 'w', newline='', encoding='utf-8') as f:
    csv.writer(f).writerows(rows)

type_counts = Counter(t for _, t, _ in results)
print("Type distribution:")
for t, n in type_counts.most_common():
    print(f"  {n:3d}  {t}")

unknowns = [(i, e) for i, t, e in results if t == 'unknown']
print(f"\nUnknowns left unchanged ({len(unknowns)}):")
for i, e in unknowns:
    print(f"  Row {i}: {e!r}")

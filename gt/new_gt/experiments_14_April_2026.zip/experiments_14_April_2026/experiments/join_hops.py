import csv, re
from collections import deque

filepath = "C:/Users/QCRI-MMG25/OneDrive - Hamad bin Khalifa University/Desktop/Work/experiments_14_April_2026/experiments_14_April_2026/experiments/cc.csv"

with open(filepath, newline='', encoding='utf-8') as f:
    rows = list(csv.reader(f))

aa_idx = rows[0].index('further_simplified_sql')
o_idx  = rows[0].index('max_join_hobs')

SQL_KEYWORDS = {
    'ON','WHERE','JOIN','INNER','LEFT','RIGHT','OUTER','FULL','CROSS','NATURAL',
    'GROUP','ORDER','HAVING','LIMIT','UNION','EXCEPT','INTERSECT','SET',
    'AND','OR','NOT','IN','IS','NULL','BY','CASE','WHEN','THEN','ELSE','END',
    'WITH','DISTINCT','ALL','BETWEEN','LIKE','AS','FROM','SELECT'
}

END_KW = re.compile(
    r'\b((?:LEFT|RIGHT|INNER|OUTER|FULL|CROSS|NATURAL)?\s*JOIN'
    r'|WHERE|GROUP\s+BY|ORDER\s+BY|HAVING|LIMIT|UNION|EXCEPT|INTERSECT)\b',
    re.IGNORECASE
)

JOIN_PREFIX = re.compile(
    r'\b(?:LEFT\s+(?:OUTER\s+)?|RIGHT\s+(?:OUTER\s+)?|INNER\s+|'
    r'FULL\s+(?:OUTER\s+)?|CROSS\s+|NATURAL\s+)?JOIN\s+',
    re.IGNORECASE
)

def strip_comments(sql):
    sql = re.sub(r'/\*.*?\*/', ' ', sql, flags=re.DOTALL)
    sql = re.sub(r'--[^\n]*', ' ', sql)
    return sql

def skip_subquery(sql, start):
    """Given that sql[start]=='(', return index after matching ')'."""
    depth = 1
    i = start + 1
    while i < len(sql) and depth > 0:
        if sql[i] == '(':   depth += 1
        elif sql[i] == ')': depth -= 1
        i += 1
    return i

def extract_on_clause(sql, start):
    """
    Extract ON clause text starting at 'start' (after 'ON ').
    Returns (clause_text, end_index).
    """
    chars = []
    depth = 0
    i = start
    n = len(sql)
    while i < n:
        c = sql[i]
        if c == '(':
            depth += 1
            chars.append(c)
        elif c == ')':
            if depth == 0:
                break           # closing paren of enclosing context
            depth -= 1
            chars.append(c)
        elif depth == 0 and END_KW.match(sql[i:]):
            break
        else:
            chars.append(c)
        i += 1
    return ''.join(chars), i

def aliases_in_expr(expr):
    """Return set of unquoted table aliases referenced as alias.col."""
    return {a.strip('`') for a in re.findall(r'`?(\w+)`?\s*\.', expr)}

def max_join_hops(sql):
    sql = strip_comments(sql)
    n   = len(sql)

    # depths[alias] = shortest-path hops from target_table
    depths = {'target_table': 0}

    i = 0
    outer_depth = 0

    while i < n:
        c = sql[i]
        if c == '(':
            outer_depth += 1
            i += 1
            continue
        if c == ')':
            outer_depth -= 1
            i += 1
            continue
        if outer_depth != 0:
            i += 1
            continue

        # ── look for JOIN at depth 0 ───────────────────────────────────────
        jm = JOIN_PREFIX.match(sql[i:])
        if not jm:
            i += 1
            continue

        j = i + jm.end()
        # skip leading whitespace
        while j < n and sql[j] in ' \t\n\r':
            j += 1

        new_alias = None

        if j < n and sql[j] == '(':
            # subquery join: skip to matching )
            j = skip_subquery(sql, j)
            # look for AS alias
            as_m = re.match(r'\s*AS\s+`?(\w+)`?', sql[j:], re.IGNORECASE)
            if as_m:
                new_alias = as_m.group(1)
                j += as_m.end()
        else:
            # regular table: table_name [AS] alias
            tbl_m = re.match(r'`?(\w+(?:\.\w+)?)`?\s+(?:AS\s+)?`?(\w+)`?',
                             sql[j:], re.IGNORECASE)
            if tbl_m:
                tname = tbl_m.group(1).split('.')[-1]
                alias_candidate = tbl_m.group(2)
                if alias_candidate.upper() in SQL_KEYWORDS:
                    new_alias = tname          # no explicit alias
                    j += len(tbl_m.group(1))
                else:
                    new_alias = alias_candidate
                    j += tbl_m.end()
            else:
                bare_m = re.match(r'`?(\w+)`?', sql[j:])
                if bare_m:
                    new_alias = bare_m.group(1)
                    j += bare_m.end()

        if not new_alias:
            i += jm.end()
            continue

        # skip whitespace
        while j < n and sql[j] in ' \t\n\r':
            j += 1

        on_m = re.match(r'\bON\b\s+', sql[j:], re.IGNORECASE)
        if on_m:
            clause, j = extract_on_clause(sql, j + on_m.end())
            mentioned    = aliases_in_expr(clause)
            existing_refs = {a for a in mentioned
                             if a in depths and a != new_alias}
            if existing_refs:
                new_depth = min(depths[a] for a in existing_refs) + 1
            else:
                new_depth = 1
        else:
            # CROSS JOIN or no ON → treat as directly connected to target_table
            new_depth = 1

        # keep shortest observed depth for this alias
        if new_alias not in depths or depths[new_alias] > new_depth:
            depths[new_alias] = new_depth

        i = j

    if len(depths) <= 1:
        return 0
    return max(v for k, v in depths.items() if k != 'target_table')


# ── unit tests ────────────────────────────────────────────────────────────────
tests = [
    ("select * from t as target_table join t1 tt1 on tt1.x=target_table.x", 1),
    ("select * from t as target_table join t1 tt1 on tt1.x=target_table.x "
     "join t2 tt2 on tt2.x=tt1.x", 2),
    ("select * from t as target_table join t1 tt1 on tt1.x=target_table.x "
     "join t2 tt2 on tt2.x=target_table.x", 1),
    ("select * from t as target_table", 0),
]
print("Tests:")
all_ok = True
for sql, expected in tests:
    got = max_join_hops(sql)
    ok = got == expected
    all_ok = all_ok and ok
    print(f"  expected={expected} got={got}  {'OK' if ok else 'FAIL'}  {sql[:70]}")

if not all_ok:
    raise SystemExit("Fix tests before writing to file.")

# ── apply ─────────────────────────────────────────────────────────────────────
for row in rows[1:]:
    sql = row[aa_idx] if aa_idx < len(row) else ''
    row[o_idx] = max_join_hops(sql)

with open(filepath, 'w', newline='', encoding='utf-8') as f:
    csv.writer(f).writerows(rows)

from collections import Counter
print("\nmax_join_hobs distribution:",
      Counter(row[o_idx] for row in rows[1:]).most_common(8))

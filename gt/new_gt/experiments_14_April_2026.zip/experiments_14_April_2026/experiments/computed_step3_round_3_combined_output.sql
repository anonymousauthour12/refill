###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrder_StartDate.csv
# StartDate = DueDate - 11 days
# [row_scope]
SELECT DATE_SUB(target_table.`DueDate`, INTERVAL 11 DAY) AS `computed_value`, target_table.`StartDate` AS `actual_value` FROM `WorkOrder` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrder_StartDate.csv
# For each work order, StartDate equals the earliest ScheduledStartDate across all its routing operations: StartDate = MIN(WorkOrderRouting.ScheduledStartDate) grouped by WorkOrderID.
# [across_tables], used_tables: ['WorkOrderRouting']
SELECT wr_first.min_sched_start AS computed_value, target_table.StartDate AS actual_value
FROM WorkOrder AS target_table
LEFT JOIN (
  SELECT WorkOrderID, MIN(ScheduledStartDate) AS min_sched_start
  FROM WorkOrderRouting
  GROUP BY WorkOrderID
) AS wr_first
  ON wr_first.WorkOrderID = target_table.WorkOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrder_StartDate.csv
# StartDate = DueDate - (10 + max(BillOfMaterials.BOMLevel for the product as ComponentID)) days.
# [across_tables], used_tables: ['BillOfMaterials', 'PurchaseOrderDetail']
SELECT DATE_SUB(target_table.DueDate, INTERVAL CAST(10 + COALESCE(b.max_bom_level, 0) AS SIGNED) DAY) AS computed_value, target_table.StartDate AS actual_value
FROM WorkOrder AS target_table
LEFT JOIN (
    SELECT ComponentID, MAX(BOMLevel) AS max_bom_level
    FROM BillOfMaterials
    GROUP BY ComponentID
) AS b
ON b.ComponentID = target_table.ProductID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_PPG.csv
# For each team-season in TeamsPost identified by (year, lgID, tmID), postseason PPG equals the sum of players PostPPG in Scoring for the same (year, lgID, tmID): PPG_post(team, year, lgID) = ? over players p of Scoring.PostPPG(p, year, lgID, team).
# [across_tables], used_tables: ['Scoring']
SELECT COALESCE(team_ppg.sum_postppg, 0) AS computed_value, target_table.PPG AS actual_value FROM TeamsPost AS target_table LEFT JOIN (SELECT s.year, s.lgID, s.tmID, SUM(CAST(s.PostPPG AS SIGNED)) AS sum_postppg FROM Scoring AS s WHERE s.PostPPG IS NOT NULL GROUP BY s.year, s.lgID, s.tmID) AS team_ppg ON team_ppg.year = target_table.year AND team_ppg.lgID = target_table.lgID AND team_ppg.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderDetail_UnitPriceDiscount.csv
# UnitPriceDiscount = (OrderQty * UnitPrice - LineTotal) / (OrderQty * UnitPrice)
# [row_scope]
SELECT (((CAST(target_table.OrderQty AS SIGNED) * CAST(target_table.UnitPrice AS DECIMAL(38,10))) - CAST(target_table.LineTotal AS DECIMAL(38,10))) / NULLIF((CAST(target_table.OrderQty AS SIGNED) * CAST(target_table.UnitPrice AS DECIMAL(38,10))), 0)) AS computed_value, target_table.UnitPriceDiscount AS actual_value FROM SalesOrderDetail AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrderRouting_ActualEndDate.csv
# ActualEndDate = CAST(CONVERT(date, ModifiedDate) AS datetime)
# [row_scope]
SELECT CAST(DATE(target_table.ModifiedDate) AS DATETIME) AS computed_value, target_table.ActualEndDate AS actual_value FROM WorkOrderRouting AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrderRouting_ActualEndDate.csv
# For each WorkOrderRouting row, ActualEndDate equals the EndDate of its parent WorkOrder: ActualEndDate = WorkOrder.EndDate where WorkOrder.WorkOrderID = WorkOrderRouting.WorkOrderID.
# [across_tables], used_tables: ['WorkOrder']
SELECT w.EndDate AS computed_value, target_table.ActualEndDate AS actual_value FROM WorkOrderRouting AS target_table INNER JOIN WorkOrder AS w ON w.WorkOrderID = target_table.WorkOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrderRouting_ActualEndDate.csv
# For each WorkOrderRouting row, ActualEndDate equals the parent WorkOrders ModifiedDate minus one hour: ActualEndDate = WorkOrder.ModifiedDate - INTERVAL 1 HOUR where WorkOrder.WorkOrderID = WorkOrderRouting.WorkOrderID.
# [across_tables], used_tables: ['Location', 'WorkOrder']
SELECT DATE_SUB(W.ModifiedDate, INTERVAL 1 HOUR) AS computed_value, target_table.ActualEndDate AS actual_value
FROM WorkOrderRouting AS target_table
JOIN WorkOrder AS W ON W.WorkOrderID = target_table.WorkOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrderRouting_ActualEndDate.csv
# ActualEndDate equals the last Work Order transaction date recorded in TransactionHistory for the same WorkOrderID and TransactionType = 'W'; if no such transaction exists, fallback to WorkOrder.EndDate.
# [across_tables], used_tables: ['TransactionHistory', 'WorkOrder']
SELECT 
  COALESCE(tx.last_txn_date, wo.EndDate) AS computed_value,
  target_table.ActualEndDate AS actual_value
FROM WorkOrderRouting AS target_table
LEFT JOIN WorkOrder AS wo
  ON wo.WorkOrderID = target_table.WorkOrderID
LEFT JOIN (
  SELECT ReferenceOrderID AS WorkOrderID, MAX(TransactionDate) AS last_txn_date
  FROM TransactionHistory
  WHERE TransactionType = 'W'
  GROUP BY ReferenceOrderID
) AS tx
  ON tx.WorkOrderID = target_table.WorkOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_fgMade.csv
# fgMade = (points - ftMade - threeMade) / 2
# [row_scope]
SELECT (CAST(target_table.points AS SIGNED) - CAST(target_table.ftMade AS SIGNED) - CAST(target_table.threeMade AS SIGNED)) / 2 AS computed_value, target_table.fgMade AS actual_value FROM players_teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_GoaliesSC_T.csv
# For each row in GoaliesSC, T equals the team-level Stanley Cup ties for the same team and year: T_goalie(year, tmID) = TeamsSC.T(year, tmID). Join keys: (year, tmID).
# [across_tables], used_tables: ['TeamsSC', 'SeriesPost']
SELECT ts.T AS computed_value, target_table.T AS actual_value FROM GoaliesSC AS target_table LEFT JOIN TeamsSC AS ts ON ts.year = target_table.year AND ts.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_GoaliesSC_T.csv
# T = GP - W - L
# [row_scope]
SELECT (CAST(target_table.GP AS SIGNED) - CAST(target_table.W AS SIGNED) - CAST(target_table.L AS SIGNED)) AS computed_value, target_table.T AS actual_value FROM GoaliesSC AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_PPG.csv
# For each team-season (year, tmID), the team regular-season PPG equals the sum of its players regular-season power-play goals recorded in Scoring for that same team-season: Teams.PPG = SUM_over_Scoring(year=Teams.year AND tmID=Teams.tmID)(CAST(Scoring.PPG AS INTEGER)), treating NULL PPG as 0.
# [across_tables], used_tables: ['TeamsPost', 'Scoring']
SELECT
  COALESCE(sc_ppg.value, 0) AS computed_value,
  target_table.PPG AS actual_value
FROM Teams AS target_table
LEFT JOIN (
  SELECT s.year, s.tmID, SUM(CAST(IFNULL(s.PPG, '0') AS SIGNED)) AS value
  FROM Scoring AS s
  GROUP BY s.year, s.tmID
) AS sc_ppg
  ON sc_ppg.year = target_table.year
 AND sc_ppg.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_hT.csv
# For each (year, tmID), compute home ties as: hT = COALESCE(Teams.T, 0) - COALESCE(TeamSplits.rT, 0). This uses the season-level total ties from Teams and subtracts the road ties from TeamSplits to yield home ties.
# [across_tables], used_tables: ['Teams']
SELECT (COALESCE(CAST(t.T AS SIGNED), 0) - COALESCE(CAST(target_table.rT AS SIGNED), 0)) AS computed_value, target_table.hT AS actual_value FROM TeamSplits AS target_table JOIN Teams AS t ON t.year = target_table.year AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_hL.csv
# For each (year, tmID): hL = Teams.L - TeamSplits.rL. This uses total regulation losses from Teams and subtracts road regulation losses from TeamSplits to yield home regulation losses.
# [across_tables], used_tables: ['Teams']
SELECT CAST(COALESCE(t.L, 0) AS SIGNED) - CAST(COALESCE(target_table.rL, 0) AS SIGNED) AS computed_value, target_table.hL AS actual_value FROM TeamSplits AS target_table INNER JOIN Teams AS t ON t.year = target_table.year AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Invoice_BillingPostalCode.csv
# For each invoice, BillingPostalCode equals the PostalCode of its billed customer referenced by Invoice.CustomerId -> Customer.CustomerId.
# [across_tables], used_tables: ['Customer']
SELECT
  c.PostalCode AS computed_value,
  target_table.BillingPostalCode AS actual_value
FROM Invoice AS target_table
JOIN Customer AS c
  ON c.CustomerId = target_table.CustomerId;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Master_deathCountry.csv
# 1) If deathState is a US postal code, set deathCountry = 'USA'. 2) Else if deathState is a Canadian province/territory code, set deathCountry = 'Canada'. 3) Else, if (a) the player?s most recent league in Scoring is NHL or WHA and (b) birthCountry is either 'USA' or 'Canada', then set deathCountry = birthCountry. 4) Otherwise, leave as NULL.
# [across_tables], used_tables: ['Scoring']
SELECT
  CASE
    WHEN target_table.deathState IN ('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY') THEN 'USA'
    WHEN target_table.deathState IN ('AB','BC','MB','NB','NL','NS','NT','NU','ON','PE','QC','SK','YT') THEN 'Canada'
    WHEN last_sc.last_lgID IN ('NHL','WHA') AND target_table.birthCountry IN ('USA','Canada') AND target_table.deathCountry IS NULL THEN target_table.birthCountry
    ELSE NULL
  END AS computed_value,
  target_table.deathCountry AS actual_value
FROM Master AS target_table
LEFT JOIN (
  SELECT ls.playerID, MIN(ls.lgID) AS last_lgID
  FROM (
    SELECT s.playerID, s.lgID
    FROM Scoring s
    JOIN (
      SELECT playerID, MAX(year) AS last_year
      FROM Scoring
      GROUP BY playerID
    ) mx ON mx.playerID = s.playerID AND mx.last_year = s.year
  ) ls
  GROUP BY ls.playerID
) AS last_sc ON last_sc.playerID = target_table.playerID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Master_deathCountry.csv
# 1) Build two state/province-to-country sets using cross-table evidence from Scoring: S_US = distinct birthState values among people who have at least one Scoring row and birthCountry = 'USA'; S_CAN = distinct birthState values among people who have at least one Scoring row and birthCountry = 'Canada'. 2) For each person in Master, predict deathCountry as follows: if deathState is in S_US then 'USA'; else if deathState is in S_CAN then 'Canada'; else, if deathCity is not null, look up the most frequent (deathCity, deathCountry) pairing observed among people who appear in Scoring or Coaches and use that country; else NULL.
# [across_tables], used_tables: ['Coaches', 'Scoring']
SELECT
  CASE
    WHEN us_map.state_code IS NOT NULL THEN 'USA'
    WHEN ca_map.state_code IS NOT NULL THEN 'Canada'
    WHEN city_map.selected_country IS NOT NULL THEN city_map.selected_country
    ELSE NULL
  END AS computed_value,
  target_table.deathCountry AS actual_value
FROM Master AS target_table
LEFT JOIN (
  SELECT DISTINCT m.birthState AS state_code
  FROM Master AS m
  JOIN Scoring AS s ON s.playerID = m.playerID
  WHERE m.birthCountry = 'USA' AND m.birthState IS NOT NULL
) AS us_map ON us_map.state_code = target_table.deathState
LEFT JOIN (
  SELECT DISTINCT m.birthState AS state_code
  FROM Master AS m
  JOIN Scoring AS s ON s.playerID = m.playerID
  WHERE m.birthCountry = 'Canada' AND m.birthState IS NOT NULL
) AS ca_map ON ca_map.state_code = target_table.deathState
LEFT JOIN (
  SELECT top.city, MIN(top.country) AS selected_country
  FROM (
    SELECT totals.city, totals.country, totals.cnt
    FROM (
      SELECT uc.city, uc.country, SUM(uc.cnt) AS cnt
      FROM (
        SELECT m.deathCity AS city, m.deathCountry AS country, COUNT(*) AS cnt
        FROM Master AS m
        JOIN Scoring AS s ON s.playerID = m.playerID
        WHERE m.deathCity IS NOT NULL AND m.deathCountry IS NOT NULL
        GROUP BY m.deathCity, m.deathCountry
        UNION ALL
        SELECT m.deathCity AS city, m.deathCountry AS country, COUNT(*) AS cnt
        FROM Master AS m
        JOIN Coaches AS c ON c.coachID = m.coachID
        WHERE m.deathCity IS NOT NULL AND m.deathCountry IS NOT NULL
        GROUP BY m.deathCity, m.deathCountry
      ) AS uc
      GROUP BY uc.city, uc.country
    ) AS totals
    JOIN (
      SELECT city, MAX(cnt) AS max_cnt
      FROM (
        SELECT m.deathCity AS city, m.deathCountry AS country, COUNT(*) AS cnt
        FROM Master AS m
        JOIN Scoring AS s ON s.playerID = m.playerID
        WHERE m.deathCity IS NOT NULL AND m.deathCountry IS NOT NULL
        GROUP BY m.deathCity, m.deathCountry
        UNION ALL
        SELECT m.deathCity AS city, m.deathCountry AS country, COUNT(*) AS cnt
        FROM Master AS m
        JOIN Coaches AS c ON c.coachID = m.coachID
        WHERE m.deathCity IS NOT NULL AND m.deathCountry IS NOT NULL
        GROUP BY m.deathCity, m.deathCountry
      ) AS tmp
      GROUP BY city
    ) AS mx ON totals.city = mx.city AND totals.cnt = mx.max_cnt
  ) AS top
  GROUP BY top.city
) AS city_map ON city_map.city = target_table.deathCity;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Employee_Email.csv
# Email = lower(FirstName) + '@chinookcorp.com'
# [row_scope]
SELECT CONCAT(LOWER(`target_table`.`FirstName`), '@chinookcorp.com') AS `computed_value`, `target_table`.`Email` AS `actual_value` FROM `Employee` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsHalf_L.csv
# L = G - W
# [row_scope]
SELECT CAST(target_table.G AS SIGNED) - CAST(target_table.W AS SIGNED) AS computed_value, target_table.L AS actual_value FROM TeamsHalf AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_a_q4g.csv
# For each match mid, a_q4g equals the sum of player goals (GL) recorded in match_stats for the away team: sum(GL) where match_stats.mid = matches.mid AND match_stats.tid = matches.a_tid AND match_stats.loc = 'a'.
# [across_tables], used_tables: ['match_stats']
SELECT
  total_away_goals.value AS computed_value,
  target_table.a_q4g AS actual_value
FROM matches AS target_table
LEFT JOIN (
  SELECT ms.mid, ms.tid, SUM(COALESCE(ms.GL, 0)) AS value
  FROM match_stats AS ms
  WHERE ms.loc = 'a'
  GROUP BY ms.mid, ms.tid
) AS total_away_goals
  ON total_away_goals.mid = target_table.mid
 AND total_away_goals.tid = target_table.a_tid;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_DecOL.csv
# For each (year, tmID), DecOL = Teams.OTL - (SepOL + OctOL + NovOL + JanOL + FebOL + MarOL + AprOL).
# [across_tables], used_tables: ['Teams']
SELECT
  (
    CAST(t.OTL AS SIGNED)
    - COALESCE(CAST(target_table.SepOL AS SIGNED), 0)
    - COALESCE(CAST(target_table.OctOL AS SIGNED), 0)
    - COALESCE(CAST(target_table.NovOL AS SIGNED), 0)
    - COALESCE(CAST(target_table.JanOL AS SIGNED), 0)
    - COALESCE(CAST(target_table.FebOL AS SIGNED), 0)
    - COALESCE(CAST(target_table.MarOL AS SIGNED), 0)
    - COALESCE(CAST(target_table.AprOL AS SIGNED), 0)
  ) AS computed_value,
  target_table.DecOL AS actual_value
FROM TeamSplits AS target_table
LEFT JOIN Teams AS t
  ON t.year = target_table.year
 AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_pts.csv
# o_pts = o_ftm + 2 * o_fgm + o_3pm
# [row_scope]
SELECT (CAST(target_table.o_ftm AS SIGNED) + 2 * CAST(target_table.o_fgm AS SIGNED) + CAST(target_table.o_3pm AS SIGNED)) AS computed_value, target_table.o_pts AS actual_value FROM teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_W.csv
# W = Pts - G + L
# [row_scope]
SELECT (CAST(`target_table`.`Pts` AS SIGNED) - CAST(`target_table`.`G` AS SIGNED) + CAST(`target_table`.`L` AS SIGNED)) AS computed_value, `target_table`.`W` AS actual_value FROM `Teams` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_DecT.csv
# DecT = [(hW + hL + hT + hOTL) + (rW + rL + rT + rOTL)] - [(SepW + SepL + SepT + SepOL) + (OctW + OctL + OctT + OctOL) + (NovW + NovL + NovT + NovOL) + (JanW + JanL + JanT + JanOL) + (FebW + FebL + FebT + FebOL) + (MarW + MarL + MarT + MarOL) + (AprW + AprL + AprT + AprOL)] - (DecW + DecL + DecOL)
# [row_scope]
SELECT ((CAST(COALESCE(target_table.hW, 0) AS SIGNED) + CAST(COALESCE(target_table.hL, 0) AS SIGNED) + CAST(COALESCE(target_table.hT, 0) AS SIGNED) + CAST(COALESCE(target_table.hOTL, 0) AS SIGNED)) + (CAST(COALESCE(target_table.rW, 0) AS SIGNED) + CAST(COALESCE(target_table.rL, 0) AS SIGNED) + CAST(COALESCE(target_table.rT, 0) AS SIGNED) + CAST(COALESCE(target_table.rOTL, 0) AS SIGNED))) - ((CAST(COALESCE(target_table.SepW, 0) AS SIGNED) + CAST(COALESCE(target_table.SepL, 0) AS SIGNED) + CAST(COALESCE(target_table.SepT, 0) AS SIGNED) + CAST(COALESCE(target_table.SepOL, 0) AS SIGNED)) + (CAST(COALESCE(target_table.OctW, 0) AS SIGNED) + CAST(COALESCE(target_table.OctL, 0) AS SIGNED) + CAST(COALESCE(target_table.OctT, 0) AS SIGNED) + CAST(COALESCE(target_table.OctOL, 0) AS SIGNED)) + (CAST(COALESCE(target_table.NovW, 0) AS SIGNED) + CAST(COALESCE(target_table.NovL, 0) AS SIGNED) + CAST(COALESCE(target_table.NovT, 0) AS SIGNED) + CAST(COALESCE(target_table.NovOL, 0) AS SIGNED)) + (CAST(COALESCE(target_table.JanW, 0) AS SIGNED) + CAST(COALESCE(target_table.JanL, 0) AS SIGNED) + CAST(COALESCE(target_table.JanT, 0) AS SIGNED) + CAST(COALESCE(target_table.JanOL, 0) AS SIGNED)) + (CAST(COALESCE(target_table.FebW, 0) AS SIGNED) + CAST(COALESCE(target_table.FebL, 0) AS SIGNED) + CAST(COALESCE(target_table.FebT, 0) AS SIGNED) + CAST(COALESCE(target_table.FebOL, 0) AS SIGNED)) + (CAST(COALESCE(target_table.MarW, 0) AS SIGNED) + CAST(COALESCE(target_table.MarL, 0) AS SIGNED) + CAST(COALESCE(target_table.MarT, 0) AS SIGNED) + CAST(COALESCE(target_table.MarOL, 0) AS SIGNED)) + (CAST(COALESCE(target_table.AprW, 0) AS SIGNED) + CAST(COALESCE(target_table.AprL, 0) AS SIGNED) + CAST(COALESCE(target_table.AprT, 0) AS SIGNED) + CAST(COALESCE(target_table.AprOL, 0) AS SIGNED))) - (CAST(COALESCE(target_table.DecW, 0) AS SIGNED) + CAST(COALESCE(target_table.DecL, 0) AS SIGNED) + CAST(COALESCE(target_table.DecOL, 0) AS SIGNED)) AS computed_value, target_table.DecT AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_FebL.csv
# FebL = COALESCE(hL, 0) + COALESCE(rL, 0) - (COALESCE(SepL, 0) + COALESCE(OctL, 0) + COALESCE(NovL, 0) + COALESCE(DecL, 0) + COALESCE(JanL, 0) + COALESCE(MarL, 0) + COALESCE(AprL, 0))
# [row_scope]
SELECT CAST(COALESCE(target_table.hL, 0) AS SIGNED) + CAST(COALESCE(target_table.rL, 0) AS SIGNED) - (CAST(COALESCE(target_table.SepL, 0) AS SIGNED) + CAST(COALESCE(target_table.OctL, 0) AS SIGNED) + CAST(COALESCE(target_table.NovL, 0) AS SIGNED) + CAST(COALESCE(target_table.DecL, 0) AS SIGNED) + CAST(COALESCE(target_table.JanL, 0) AS SIGNED) + CAST(COALESCE(target_table.MarL, 0) AS SIGNED) + CAST(COALESCE(target_table.AprL, 0) AS SIGNED)) AS computed_value, target_table.FebL AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Master_birthCountry.csv
# For any player who appears as a goalie in CombinedShutouts (i.e., their Master.playerID matches CombinedShutouts.IDgoalie1 or CombinedShutouts.IDgoalie2), infer birthCountry from Master.birthState as follows: if birthState is one of the Canadian province/territory codes {AB, BC, MB, NB, NL, NS, NT, NU, ON, PE, QC, SK, YT}, then computed birthCountry = 'Canada'; if birthState is one of the U.S. state/DC codes {AL, AK, AZ, AR, CA, CO, CT, DC, DE, FL, GA, HI, IA, ID, IL, IN, KS, KY, LA, MA, MD, ME, MI, MN, MO, MS, MT, NC, ND, NE, NH, NJ, NM, NV, NY, OH, OK, OR, PA, RI, SC, SD, TN, TX, UT, VA, VT, WA, WI, WV, WY}, then computed birthCountry = 'USA'; otherwise NULL.
# [across_tables], used_tables: ['CombinedShutouts']
SELECT
  CASE
    WHEN target_table.birthState IN ('AB','BC','MB','NB','NL','NS','NT','NU','ON','PE','QC','SK','YT') THEN 'Canada'
    WHEN target_table.birthState IN ('AL','AK','AZ','AR','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','ME','MI','MN','MO','MS','MT','NC','ND','NE','NH','NJ','NM','NV','NY','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VA','VT','WA','WI','WV','WY') THEN 'USA'
    ELSE NULL
  END AS computed_value,
  target_table.birthCountry AS actual_value
FROM Master AS target_table
JOIN (
  SELECT IDgoalie1 AS playerID FROM CombinedShutouts WHERE IDgoalie1 IS NOT NULL
  UNION
  SELECT IDgoalie2 AS playerID FROM CombinedShutouts WHERE IDgoalie2 IS NOT NULL
) cs ON cs.playerID = target_table.playerID
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Master_birthCountry.csv
# If a player appears in ScoringSC or GoaliesSC in any season up to and including 1925, predict 'Canada' for birthCountry; otherwise, if Master.birthState is a U.S. state code, predict 'USA'; if Master.birthState is a Canadian province/territory code, predict 'Canada'; else NULL.
# [across_tables], used_tables: ['ScoringSC', 'GoaliesSC']
SELECT
  CASE
    WHEN sc.min_sc_year IS NOT NULL AND sc.min_sc_year <= 1925 THEN 'Canada'
    WHEN target_table.birthState IN ('AL','AK','AZ','AR','CA','CO','CT','DC','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','ME','MI','MN','MO','MS','MT','NC','ND','NE','NH','NJ','NM','NV','NY','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VA','VT','WA','WI','WV','WY') THEN 'USA'
    WHEN target_table.birthState IN ('AB','BC','MB','NB','NL','NS','NT','NU','ON','PE','QC','SK','YT') THEN 'Canada'
    ELSE NULL
  END AS computed_value,
  target_table.birthCountry AS actual_value
FROM Master AS target_table
LEFT JOIN (
  SELECT u.playerID, MIN(u.year) AS min_sc_year
  FROM (
    SELECT playerID, year FROM ScoringSC
    UNION ALL
    SELECT playerID, year FROM GoaliesSC
  ) AS u
  WHERE u.playerID IS NOT NULL
  GROUP BY u.playerID
) AS sc
  ON sc.playerID = target_table.playerID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_MarOL.csv
# MarOL = Teams.OTL - (SepOL + OctOL + NovOL + DecOL + JanOL + FebOL + AprOL). Treat any NULLs as 0 and cast all operands to SIGNED before arithmetic.
# [across_tables], used_tables: ['Teams']
SELECT ( COALESCE(CAST(t.OTL AS SIGNED), 0) - ( COALESCE(CAST(target_table.SepOL AS SIGNED), 0) + COALESCE(CAST(target_table.OctOL AS SIGNED), 0) + COALESCE(CAST(target_table.NovOL AS SIGNED), 0) + COALESCE(CAST(target_table.DecOL AS SIGNED), 0) + COALESCE(CAST(target_table.JanOL AS SIGNED), 0) + COALESCE(CAST(target_table.FebOL AS SIGNED), 0) + COALESCE(CAST(target_table.AprOL AS SIGNED), 0) ) ) AS computed_value, CAST(target_table.MarOL AS SIGNED) AS actual_value FROM TeamSplits AS target_table LEFT JOIN Teams AS t ON t.year = target_table.year AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_GF.csv
# For seasons split into halves, GF equals the sum of the team?s GF across all halves in TeamsHalf for that team-year: GF(year, tmID) = SUM_{rows in TeamsHalf where year, tmID match}(GF).
# [across_tables], used_tables: ['Scoring', 'TeamsHalf']
SELECT totals_half.computed_value, target_table.GF AS actual_value
FROM Teams AS target_table
LEFT JOIN (
  SELECT year, tmID, CAST(SUM(GF) AS SIGNED) AS computed_value
  FROM TeamsHalf
  GROUP BY year, tmID
) AS totals_half
  ON totals_half.year = target_table.year
 AND totals_half.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_GF.csv
# For each row in Teams, GF equals the sum of Scoring.G across all player-season-stint rows where Scoring.year = Teams.year and Scoring.tmID = Teams.tmID and Scoring.lgID = Teams.lgID.
# [across_tables], used_tables: ['Scoring']
SELECT scoring_goals.total_goals AS computed_value, target_table.GF AS actual_value FROM Teams AS target_table LEFT JOIN (SELECT year, tmID, lgID, SUM(G) AS total_goals FROM Scoring GROUP BY year, tmID, lgID) AS scoring_goals ON scoring_goals.year = target_table.year AND scoring_goals.tmID = target_table.tmID AND scoring_goals.lgID = target_table.lgID;
###########################################################

###########################################################
# filtered_reported_accuracy_Dallas_officers_last_name.csv
# last_name = trim(split(full_name, ',')[0])
# [row_scope]
SELECT TRIM(SUBSTRING_INDEX(target_table.full_name, ',', 1)) AS computed_value, target_table.last_name AS actual_value FROM officers AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderDetail_LineTotal.csv
# LineTotal = OrderQty * UnitPrice
# [row_scope]
SELECT (CAST(target_table.OrderQty AS SIGNED) * target_table.UnitPrice) AS computed_value, target_table.LineTotal AS actual_value FROM PurchaseOrderDetail AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_L.csv
# L = G - W - T
# [row_scope]
SELECT (CAST(`target_table`.`G` AS SIGNED) - CAST(`target_table`.`W` AS SIGNED) - CAST(`target_table`.`T` AS SIGNED)) AS `computed_value`, `target_table`.`L` AS `actual_value` FROM `TeamsPost` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_L.csv
# For each (year, tmID), team playoff losses L equal the sum of all goalies PostL for that team and year: L(year, tmID) = SUM_{g in Goalies where g.year = TeamsPost.year AND g.tmID = TeamsPost.tmID} (g.PostL).
# [across_tables], used_tables: ['Goalies']
SELECT g_agg.sum_postl AS computed_value,
       target_table.L AS actual_value
FROM TeamsPost AS target_table
LEFT JOIN (
  SELECT year, tmID, SUM(CAST(PostL AS SIGNED)) AS sum_postl
  FROM Goalies
  GROUP BY year, tmID
) AS g_agg
  ON g_agg.year = target_table.year
 AND g_agg.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_driverStandings_position.csv
# For each driverStandings row (driverId, raceId), rank all drivers that have a driverStandings entry for the same raceId by: (1) the driverStandings cumulative points (DESC), (2) the driverStandings cumulative wins (DESC), then use results as tie-breakers across season-to-date races (same year, round <= current): (3) best (lowest) classified finish (ASC; treat no classified finish as worst), (4) number of classified finishes (DESC), and finally (5) driverId (ASC). The dense rank of this ordering is the computed position.
# [across_tables], used_tables: ['races', 'results']
SELECT ranked.computed_position AS computed_value, target_table.position AS actual_value
FROM driverStandings AS target_table
JOIN (
  SELECT y.raceId, y.driverId,
         DENSE_RANK() OVER (
           PARTITION BY y.raceId
           ORDER BY y.ds_points DESC,
                    y.ds_wins DESC,
                    COALESCE(y.best_finish, 9999) ASC,
                    y.classified_finishes DESC,
                    y.driverId ASC
         ) AS computed_position
  FROM (
    SELECT ds2.raceId,
           ds2.driverId,
           ds2.points AS ds_points,
           ds2.wins AS ds_wins,
           MIN(CASE WHEN rr.raceId IS NOT NULL AND r.position IS NOT NULL THEN r.position ELSE NULL END) AS best_finish,
           SUM(CASE WHEN rr.raceId IS NOT NULL AND r.position IS NOT NULL THEN 1 ELSE 0 END) AS classified_finishes
    FROM driverStandings ds2
    JOIN races cur ON cur.raceId = ds2.raceId
    LEFT JOIN results r ON r.driverId = ds2.driverId
    LEFT JOIN races rr
      ON rr.raceId = r.raceId
     AND rr.year = cur.year
     AND rr.round <= cur.round
    GROUP BY ds2.raceId, ds2.driverId, ds2.points, ds2.wins
  ) y
) AS ranked
ON ranked.raceId = target_table.raceId AND ranked.driverId = target_table.driverId
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_lapTimes_time.csv
# time = CONCAT(FLOOR(milliseconds / 60000), ':', LPAD(FLOOR((milliseconds % 60000) / 1000), 2, '0'), '.', LPAD(milliseconds % 1000, 3, '0'))
# [row_scope]
SELECT CONCAT(FLOOR(target_table.milliseconds / 60000), ':', LPAD(FLOOR((target_table.milliseconds % 60000) / 1000), 2, '0'), '.', LPAD(target_table.milliseconds % 1000, 3, '0')) AS computed_value, target_table.`time` AS actual_value FROM lapTimes AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Coaches_w.csv
# w = g - l - t
# [row_scope]
SELECT (CAST(target_table.g AS SIGNED) - CAST(target_table.l AS SIGNED) - CAST(target_table.t AS SIGNED)) AS computed_value, target_table.w AS actual_value FROM Coaches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Coaches_w.csv
# For each coach row (identified by coachID, year, tmID, stint), regular-season wins w = Team?s season wins W (from Teams by matching year and tmID) minus the sum of wins credited to all other coaching stints on the same team and season. Formally: w = Teams.W(year, tmID) - SUM(Coaches.w WHERE year = target.year AND tmID = target.tmID AND NOT (coachID = target.coachID AND stint = target.stint)). In practice (for SQL), compute SUM of all Coaches.w for the team-season, then subtract the current row?s w to get the other-stints sum, and subtract that from Teams.W.
# [across_tables], used_tables: ['Teams']
SELECT
  CAST(t.W AS SIGNED) - CAST(COALESCE(s.sum_all_w, 0) - COALESCE(target_table.w, 0) AS SIGNED) AS computed_value,
  target_table.w AS actual_value
FROM Coaches AS target_table
LEFT JOIN Teams AS t
  ON t.year = target_table.year AND t.tmID = target_table.tmID
LEFT JOIN (
  SELECT c.year, c.tmID, SUM(c.w) AS sum_all_w
  FROM Coaches c
  GROUP BY c.year, c.tmID
) AS s
  ON s.year = target_table.year AND s.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Coaches_w.csv
# For each Coaches row (coachID, year, tmID, stint), estimate the coach?s regular-season wins as the team?s total regular-season wins for that season multiplied by the coach?s share of the team?s regular-season games: w_computed = Teams.W * (Coaches.g / Teams.G).
# [across_tables], used_tables: ['TeamVsTeam']
SELECT
  (CAST(t.W AS DECIMAL(20,10)) * CAST(target_table.g AS DECIMAL(20,10))) / NULLIF(CAST(t.G AS DECIMAL(20,10)), 0) AS computed_value,
  target_table.w AS actual_value
FROM Coaches AS target_table
LEFT JOIN Teams AS t
  ON t.year = target_table.year
 AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_player_allstar_o_rebounds.csv
# o_rebounds = rebounds - d_rebounds
# [row_scope]
SELECT (CAST(target_table.rebounds AS SIGNED) - CAST(target_table.d_rebounds AS SIGNED)) AS computed_value, target_table.o_rebounds AS actual_value FROM player_allstar AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_draft_lgID.csv
# For each draft row, set lgID to the league ID from teams where teams.tmID = draft.tmID and teams.year = draft.draftYear (leveraging the FK (tmID, draftYear) -> teams(tmID, year)).
# [across_tables], used_tables: ['teams']
SELECT t.lgID AS computed_value, target_table.lgID AS actual_value
FROM draft AS target_table
LEFT JOIN teams AS t
  ON t.tmID = target_table.tmID
 AND t.year = target_table.draftYear;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_CommunityOwnedDate.csv
# For each post P, CommunityOwnedDate(P) = earliest postHistory.CreationDate where postHistory.PostId = P.Id and postHistory.PostHistoryTypeId = 16 (the event marking the post as community wiki). If no such postHistory rows exist, the computed value is NULL.
# [across_tables], used_tables: ['postHistory']
SELECT ph_wiki.value AS computed_value, target_table.CommunityOwnedDate AS actual_value
FROM posts AS target_table
LEFT JOIN (
  SELECT PostId, MIN(CreationDate) AS value
  FROM postHistory
  WHERE PostHistoryTypeId = 16
  GROUP BY PostId
) AS ph_wiki ON ph_wiki.PostId = target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrderRouting_ScheduledStartDate.csv
# ScheduledStartDate equals the StartDate in WorkOrder for the same WorkOrderID: ScheduledStartDate = WorkOrder.StartDate.
# [across_tables], used_tables: ['WorkOrder', 'Location']
SELECT w.StartDate AS computed_value, target_table.ScheduledStartDate AS actual_value
FROM WorkOrderRouting AS target_table
INNER JOIN WorkOrder AS w ON w.WorkOrderID = target_table.WorkOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrderRouting_ScheduledStartDate.csv
# ScheduledStartDate equals the DueDate in WorkOrder minus a fixed 11-day scheduling window: ScheduledStartDate = WorkOrder.DueDate - INTERVAL 11 DAY.
# [across_tables], used_tables: ['WorkOrder', 'Location']
SELECT DATE_SUB(w.DueDate, INTERVAL 11 DAY) AS computed_value, target_table.ScheduledStartDate AS actual_value
FROM WorkOrderRouting AS target_table
INNER JOIN WorkOrder AS w ON w.WorkOrderID = target_table.WorkOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsHalf_lgID.csv
# For each TeamsHalf row identified by (year, tmID), set lgID to the lgID of the corresponding Teams row with the same (year, tmID). In other words: TeamsHalf.lgID := (SELECT lgID FROM Teams WHERE Teams.year = TeamsHalf.year AND Teams.tmID = TeamsHalf.tmID).
# [across_tables], used_tables: ['Teams']
SELECT t.lgID AS computed_value, target_table.lgID AS actual_value
FROM TeamsHalf AS target_table
JOIN Teams AS t
  ON t.year = target_table.year
 AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_constructorStandings_position.csv
# For each raceId, rank constructors by: (1) cumulative season points up to and including that race (computed from results.points for races in the same year with round <= current races round) in descending order; (2) cumulative season wins up to that race (count of results.position = 1 in the same range) in descending order; (3) best season positionOrder up to that race (minimum results.positionOrder across those races, treating null as +infinity) in ascending order; (4) constructor name (or constructorRef if name is null) ascending; (5) constructorId ascending. The resulting 1-based rank is the position.
# [across_tables], used_tables: ['races', 'results', 'constructors']
SELECT
  ROW_NUMBER() OVER (
    PARTITION BY target_table.raceId
    ORDER BY
      COALESCE(agg.tot_points, 0) DESC,
      COALESCE(agg.wins_count, 0) DESC,
      COALESCE(agg.best_position_order, 9999) ASC,
      COALESCE(ctor.name, ctor.constructorRef) ASC,
      target_table.constructorId ASC
  ) AS computed_value,
  target_table.position AS actual_value
FROM constructorStandings AS target_table
JOIN races AS rcur ON rcur.raceId = target_table.raceId
LEFT JOIN (
  SELECT
    tt.raceId,
    tt.constructorId,
    SUM(CASE WHEN r2.raceId IS NOT NULL THEN COALESCE(rs.points, 0) ELSE 0 END) AS tot_points,
    SUM(CASE WHEN r2.raceId IS NOT NULL AND rs.position = 1 THEN 1 ELSE 0 END) AS wins_count,
    MIN(CASE WHEN r2.raceId IS NOT NULL AND rs.positionOrder IS NOT NULL THEN rs.positionOrder ELSE 9999 END) AS best_position_order
  FROM constructorStandings AS tt
  JOIN races AS rc ON rc.raceId = tt.raceId
  LEFT JOIN results AS rs ON rs.constructorId = tt.constructorId
  LEFT JOIN races AS r2 ON r2.raceId = rs.raceId AND r2.year = rc.year AND r2.round <= rc.round
  GROUP BY tt.raceId, tt.constructorId
) AS agg ON agg.raceId = target_table.raceId AND agg.constructorId = target_table.constructorId
LEFT JOIN constructors AS ctor ON ctor.constructorId = target_table.constructorId;
###########################################################

###########################################################
# filtered_reported_accuracy_Dallas_subjects_gender.csv
# Join subjects to incidents on case_number and parse the gender from incidents.subjects by detecting the slash-coded pattern anywhere in the string: set computed gender to 'M' if the string contains '/M', else to 'F' if it contains '/F'; otherwise NULL.
# [across_tables], used_tables: ['incidents']
SELECT
  CASE
    WHEN inc.subjects LIKE '%/M%' THEN 'M'
    WHEN inc.subjects LIKE '%/F%' THEN 'F'
    ELSE NULL
  END AS computed_value,
  target_table.gender AS actual_value
FROM subjects AS target_table
LEFT JOIN incidents AS inc
  ON inc.case_number = target_table.case_number;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderHeader_SubTotal.csv
# SubTotal = TotalDue - TaxAmt - Freight
# [row_scope]
SELECT (CAST(`target_table`.`TotalDue` AS DECIMAL(65,30)) - CAST(`target_table`.`TaxAmt` AS DECIMAL(65,30)) - CAST(`target_table`.`Freight` AS DECIMAL(65,30))) AS `computed_value`, `target_table`.`SubTotal` AS `actual_value` FROM `PurchaseOrderHeader` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderHeader_SubTotal.csv
# SubTotal for a purchase order = SUM of (TransactionHistory.Quantity * TransactionHistory.ActualCost) for TransactionHistory rows where TransactionType = 'P' and ReferenceOrderID = PurchaseOrderHeader.PurchaseOrderID.
# [across_tables], used_tables: ['TransactionHistory']
SELECT th_sum.sum_cost AS computed_value, target_table.SubTotal AS actual_value
FROM PurchaseOrderHeader AS target_table
LEFT JOIN (
   SELECT ReferenceOrderID AS PurchaseOrderID, SUM(CAST(Quantity AS DECIMAL(19,4)) * ActualCost) AS sum_cost
   FROM TransactionHistory
   WHERE TransactionType = 'P'
   GROUP BY ReferenceOrderID
) AS th_sum
ON th_sum.PurchaseOrderID = target_table.PurchaseOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderDetail_OrderQty.csv
# OrderQty = (LineTotal / UnitPrice) / (1 - UnitPriceDiscount)
# [row_scope]
SELECT (target_table.LineTotal / target_table.UnitPrice) / (1 - target_table.UnitPriceDiscount) AS computed_value, target_table.OrderQty AS actual_value FROM SalesOrderDetail AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderDetail_OrderQty.csv
# Fallback when the line number mapping is unavailable: OrderQty equals the total quantity posted to TransactionHistory with TransactionType = 'S' where (TransactionHistory.ReferenceOrderID, TransactionHistory.ProductID) match (SalesOrderDetail.SalesOrderID, SalesOrderDetail.ProductID). The (SpecialOfferID, ProductID) pair must exist in SpecialOfferProduct and Product.ProductID must exist.
# [across_tables], used_tables: ['TransactionHistory']
SELECT th_sales.qty AS computed_value, target_table.OrderQty AS actual_value FROM SalesOrderDetail AS target_table LEFT JOIN (  SELECT ProductID, ReferenceOrderID AS SalesOrderID, SUM(CAST(Quantity AS SIGNED)) AS qty  FROM TransactionHistory  WHERE TransactionType = 'S'  GROUP BY ProductID, ReferenceOrderID) AS th_sales  ON th_sales.ProductID = target_table.ProductID AND th_sales.SalesOrderID = target_table.SalesOrderID LEFT JOIN SpecialOfferProduct AS sop  ON sop.ProductID = target_table.ProductID AND sop.SpecialOfferID = target_table.SpecialOfferID LEFT JOIN Product AS p  ON p.ProductID = target_table.ProductID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_rank.csv
# For each team-season (Teams row), compute standings points from TeamVsTeam as: points = sum over all its opponent rows in the same league-season of (2*W + 1*T + 1*OTL). The rank is the ordinal position within the grouping defined by (year, lgID, divID if divID is not null; otherwise within (year, lgID) only), ordered by descending points, with ties broken by descending goal differential (GF - GA) from Teams.
# [across_tables], used_tables: ['Coaches', 'TeamVsTeam']
SELECT
  CASE WHEN tvs_pts.pts IS NULL THEN NULL
       ELSE 1 + (
         SELECT COUNT(*)
         FROM (
           SELECT t2.year, t2.lgID, t2.tmID,
                  p2.pts,
                  (CAST(t2.GF AS SIGNED) - CAST(t2.GA AS SIGNED)) AS gd,
                  t2.divID
           FROM Teams t2
           INNER JOIN (
             SELECT year, lgID, tmID,
                    SUM(CAST(W AS SIGNED)*2 + COALESCE(CAST(T AS SIGNED),0) + COALESCE(CAST(OTL AS SIGNED),0)) AS pts
             FROM TeamVsTeam
             GROUP BY year, lgID, tmID
           ) p2 ON p2.year = t2.year AND p2.lgID = t2.lgID AND p2.tmID = t2.tmID
         ) comp
         WHERE comp.year = target_table.year
           AND comp.lgID = target_table.lgID
           AND ((target_table.divID IS NULL) OR (comp.divID <=> target_table.divID))
           AND (comp.pts > tvs_pts.pts OR (comp.pts = tvs_pts.pts AND comp.gd > (CAST(target_table.GF AS SIGNED) - CAST(target_table.GA AS SIGNED))))
       )
  END AS computed_value,
  target_table.rank AS actual_value
FROM Teams target_table
LEFT JOIN (
  SELECT year, lgID, tmID,
         SUM(CAST(W AS SIGNED)*2 + COALESCE(CAST(T AS SIGNED),0) + COALESCE(CAST(OTL AS SIGNED),0)) AS pts
  FROM TeamVsTeam
  GROUP BY year, lgID, tmID
) tvs_pts
  ON tvs_pts.year = target_table.year AND tvs_pts.lgID = target_table.lgID AND tvs_pts.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_drivers_number.csv
# For each driver, take the qualifying car number from the driver?s most recent race appearance (maximum races.date; if multiple on the same date, pick the one with the largest races.raceId). This latest qualifying number is the driver?s number.
# [across_tables], used_tables: ['qualifying', 'races']
SELECT 
  latest_num.computed_value,
  target_table.number AS actual_value
FROM drivers AS target_table
LEFT JOIN (
  SELECT driverId, computed_value
  FROM (
    SELECT 
      q.driverId,
      q.number AS computed_value,
      r.date,
      r.raceId,
      ROW_NUMBER() OVER (
        PARTITION BY q.driverId
        ORDER BY r.date DESC, r.raceId DESC
      ) AS rn
    FROM qualifying q
    JOIN races r ON r.raceId = q.raceId
  ) AS x
  WHERE rn = 1
) AS latest_num
  ON latest_num.driverId = target_table.driverId;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_lgID.csv
# For each Teams row identified by (year, tmID), derive lgID by first taking the league listed for that same (year, tmID) in TeamsSC (Stanley Cup series) if present; if absent, take the league recorded for that team in any SeriesPost row from that same year (using either lgIDWinner or lgIDLoser). Formally: lgID = COALESCE(TeamsSC.lgID, SeriesPost.lgID for that (year, tmID)).
# [across_tables], used_tables: ['TeamsSC', 'SeriesPost']
SELECT
  COALESCE(tsc_agg.lgID, sp_agg.lgID) AS computed_value,
  target_table.lgID AS actual_value
FROM Teams AS target_table
LEFT JOIN (
  SELECT year, tmID, MAX(lgID) AS lgID
  FROM TeamsSC
  GROUP BY year, tmID
) AS tsc_agg
  ON tsc_agg.year = target_table.year AND tsc_agg.tmID = target_table.tmID
LEFT JOIN (
  SELECT year, tmID, MAX(lgID) AS lgID
  FROM (
    SELECT year, tmIDWinner AS tmID, lgIDWinner AS lgID FROM SeriesPost
    UNION ALL
    SELECT year, tmIDLoser AS tmID, lgIDLoser AS lgID FROM SeriesPost
  ) AS s
  GROUP BY year, tmID
) AS sp_agg
  ON sp_agg.year = target_table.year AND sp_agg.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_lgID.csv
# For each Teams row identified by (year, tmID), set lgID to the most frequent lgID recorded for that same (year, tmID) in the Coaches table (mode across Coaches rows for the team-year; break ties by the alphabetically smallest lgID).
# [across_tables], used_tables: ['Coaches', 'AwardsCoaches']
SELECT
  coach_mode.lgID AS computed_value,
  target_table.lgID AS actual_value
FROM Teams AS target_table
LEFT JOIN (
  SELECT cc.year, cc.tmID, MIN(cc.lgID) AS lgID
  FROM (
    SELECT c.year, c.tmID, c.lgID, COUNT(*) AS cnt
    FROM Coaches c
    GROUP BY c.year, c.tmID, c.lgID
  ) AS cc
  INNER JOIN (
    SELECT year, tmID, MAX(cnt) AS max_cnt
    FROM (
      SELECT c.year AS year, c.tmID AS tmID, c.lgID AS lgID, COUNT(*) AS cnt
      FROM Coaches c
      GROUP BY c.year, c.tmID, c.lgID
    ) AS cc2
    GROUP BY year, tmID
  ) AS cm
    ON cc.year = cm.year AND cc.tmID = cm.tmID AND cc.cnt = cm.max_cnt
  GROUP BY cc.year, cc.tmID
) AS coach_mode
ON target_table.year = coach_mode.year AND target_table.tmID = coach_mode.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_neutLoss.csv
# neutLoss = lost - homeLost - awayLost
# [row_scope]
SELECT CAST(`target_table`.`lost` AS SIGNED) - CAST(`target_table`.`homeLost` AS SIGNED) - CAST(`target_table`.`awayLost` AS SIGNED) AS `computed_value`, `target_table`.`neutLoss` AS `actual_value` FROM `teams` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_MarL.csv
# MarL = (COALESCE(hL, 0) + COALESCE(rL, 0)) - (COALESCE(SepL, 0) + COALESCE(OctL, 0) + COALESCE(NovL, 0) + COALESCE(DecL, 0) + COALESCE(JanL, 0) + COALESCE(FebL, 0) + COALESCE(AprL, 0))
# [row_scope]
SELECT (CAST(COALESCE(`target_table`.`hL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`rL`, 0) AS SIGNED)) - (CAST(COALESCE(`target_table`.`SepL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`OctL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`NovL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`DecL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`JanL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`FebL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`AprL`, 0) AS SIGNED)) AS computed_value, `target_table`.`MarL` AS actual_value FROM `TeamSplits` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_MarL.csv
# MarL = (Teams.G(year, tmID) ? ?_{m?{Sep,Oct,Nov,Dec,Jan,Feb,Apr}} (W_m + L_m + T_m + OL_m from TeamSplits)) ? (MarW + MarT + MarOL from TeamSplits) with NULLs treated as 0.
# [across_tables], used_tables: ['Teams']
SELECT
  (
    CAST(t.G AS SIGNED)
    - (
        COALESCE(CAST(target_table.SepW AS SIGNED), 0) + COALESCE(CAST(target_table.SepL AS SIGNED), 0) + COALESCE(CAST(target_table.SepT AS SIGNED), 0) + COALESCE(CAST(target_table.SepOL AS SIGNED), 0)
      + COALESCE(CAST(target_table.OctW AS SIGNED), 0) + COALESCE(CAST(target_table.OctL AS SIGNED), 0) + COALESCE(CAST(target_table.OctT AS SIGNED), 0) + COALESCE(CAST(target_table.OctOL AS SIGNED), 0)
      + COALESCE(CAST(target_table.NovW AS SIGNED), 0) + COALESCE(CAST(target_table.NovL AS SIGNED), 0) + COALESCE(CAST(target_table.NovT AS SIGNED), 0) + COALESCE(CAST(target_table.NovOL AS SIGNED), 0)
      + COALESCE(CAST(target_table.DecW AS SIGNED), 0) + COALESCE(CAST(target_table.DecL AS SIGNED), 0) + COALESCE(CAST(target_table.DecT AS SIGNED), 0) + COALESCE(CAST(target_table.DecOL AS SIGNED), 0)
      + COALESCE(CAST(target_table.JanW AS SIGNED), 0) + COALESCE(CAST(target_table.JanL AS SIGNED), 0) + COALESCE(CAST(target_table.JanT AS SIGNED), 0) + COALESCE(CAST(target_table.JanOL AS SIGNED), 0)
      + COALESCE(CAST(target_table.FebW AS SIGNED), 0) + COALESCE(CAST(target_table.FebL AS SIGNED), 0) + COALESCE(CAST(target_table.FebT AS SIGNED), 0) + COALESCE(CAST(target_table.FebOL AS SIGNED), 0)
      + COALESCE(CAST(target_table.AprW AS SIGNED), 0) + COALESCE(CAST(target_table.AprL AS SIGNED), 0) + COALESCE(CAST(target_table.AprT AS SIGNED), 0) + COALESCE(CAST(target_table.AprOL AS SIGNED), 0)
      )
    - (
        COALESCE(CAST(target_table.MarW AS SIGNED), 0)
      + COALESCE(CAST(target_table.MarT AS SIGNED), 0)
      + COALESCE(CAST(target_table.MarOL AS SIGNED), 0)
      )
  ) AS computed_value,
  CAST(target_table.MarL AS SIGNED) AS actual_value
FROM TeamSplits AS target_table
JOIN Teams AS t
  ON t.year = target_table.year AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_ClosedDate.csv
# For question posts (PostTypeId = 1 and ParentId IS NULL), ClosedDate equals the timestamp of the most recent PostHistory row with PostHistoryTypeId = 10 (post closed) for that PostId, provided there is no later PostHistory row with PostHistoryTypeId = 11 (post reopened). If a reopen exists at or after the latest close, computed ClosedDate is NULL. For non-question posts, computed ClosedDate is NULL.
# [across_tables], used_tables: ['postHistory']
SELECT
  CASE
    WHEN target_table.PostTypeId = 1 AND target_table.ParentId IS NULL AND co.closed_at IS NOT NULL
         AND (ro.reopened_at IS NULL OR co.closed_at > ro.reopened_at)
    THEN co.closed_at
    ELSE NULL
  END AS computed_value,
  target_table.ClosedDate AS actual_value
FROM posts AS target_table
LEFT JOIN (
  SELECT PostId, MAX(CreationDate) AS closed_at
  FROM postHistory
  WHERE PostHistoryTypeId = 10
  GROUP BY PostId
) AS co ON co.PostId = target_table.Id
LEFT JOIN (
  SELECT PostId, MAX(CreationDate) AS reopened_at
  FROM postHistory
  WHERE PostHistoryTypeId = 11
  GROUP BY PostId
) AS ro ON ro.PostId = target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_awayWon.csv
# awayWon = won - homeWon - neutWon
# [row_scope]
SELECT (CAST(target_table.won AS SIGNED) - CAST(target_table.homeWon AS SIGNED) - CAST(target_table.neutWon AS SIGNED)) AS computed_value, target_table.awayWon AS actual_value FROM teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_SepW.csv
# SepW = COALESCE(hW,0) + COALESCE(rW,0) - (COALESCE(OctW,0) + COALESCE(NovW,0) + COALESCE(DecW,0) + COALESCE(JanW,0) + COALESCE(FebW,0) + COALESCE(MarW,0) + COALESCE(AprW,0))
# [row_scope]
SELECT (CAST(COALESCE(target_table.hW, 0) AS SIGNED) + CAST(COALESCE(target_table.rW, 0) AS SIGNED) - (CAST(COALESCE(target_table.OctW, 0) AS SIGNED) + CAST(COALESCE(target_table.NovW, 0) AS SIGNED) + CAST(COALESCE(target_table.DecW, 0) AS SIGNED) + CAST(COALESCE(target_table.JanW, 0) AS SIGNED) + CAST(COALESCE(target_table.FebW, 0) AS SIGNED) + CAST(COALESCE(target_table.MarW, 0) AS SIGNED) + CAST(COALESCE(target_table.AprW, 0) AS SIGNED))) AS computed_value, target_table.SepW AS actual_value FROM TeamSplits AS target_table
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_T.csv
# T = G - (W + L)
# [row_scope]
SELECT CAST(target_table.G AS SIGNED) - (CAST(target_table.W AS SIGNED) + CAST(target_table.L AS SIGNED)) AS computed_value, target_table.T AS actual_value FROM TeamsPost AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_T.csv
# For a given team and postseason year, T equals the total number of tied games across all playoff series that the team participated in that year: T = sum over SeriesPost rows where (year = TeamsPost.year and tmID = tmIDWinner or tmID = tmIDLoser) of SeriesPost.T.
# [across_tables], used_tables: ['GoaliesShootout', 'SeriesPost']
SELECT
  COALESCE(series_ties.ties, 0) AS computed_value,
  target_table.T AS actual_value
FROM TeamsPost AS target_table
LEFT JOIN (
  SELECT s.year, s.tmID, SUM(s.T) AS ties
  FROM (
    SELECT year, tmIDWinner AS tmID, T FROM SeriesPost
    UNION ALL
    SELECT year, tmIDLoser AS tmID, T FROM SeriesPost
  ) AS s
  GROUP BY s.year, s.tmID
) AS series_ties
  ON series_ties.year = target_table.year
  AND series_ties.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_T.csv
# For each (year, lgID, tmID), T = SUM(Coaches.postg) ? TeamsPost.W ? TeamsPost.L. Aggregate Coaches.postg across all coach stints for that team-season, then subtract the team?s postseason wins and losses recorded in TeamsPost.
# [across_tables], used_tables: ['Coaches']
SELECT
  (COALESCE(cg.value, 0) - CAST(target_table.W AS SIGNED) - CAST(target_table.L AS SIGNED)) AS computed_value,
  CAST(target_table.T AS SIGNED) AS actual_value
FROM TeamsPost AS target_table
LEFT JOIN (
  SELECT year, lgID, tmID,
         SUM(CASE WHEN postg IS NOT NULL THEN CAST(postg AS SIGNED) ELSE 0 END) AS value
  FROM Coaches
  GROUP BY year, lgID, tmID
) AS cg
  ON cg.year = target_table.year
 AND cg.lgID = target_table.lgID
 AND cg.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Coaches_lgID.csv
# For each Coaches row (year, tmID), derive lgID by joining to Teams on the same (year, tmID) and taking Teams.lgID.
# [across_tables], used_tables: ['SeriesPost']
SELECT
  t.lgID AS computed_value,
  target_table.lgID AS actual_value
FROM Coaches AS target_table
LEFT JOIN Teams AS t
  ON t.year = target_table.year
 AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Coaches_lgID.csv
# For each Coaches row (coachID, year, tmID), compute lgID as the first non-null among: (1) the unique lgID observed in Coaches for the same team-season (same year and tmID) across any stints; if multiple distinct values exist for that (year, tmID), treat as unknown; else (2) the unique lgID recorded in AwardsCoaches for the same coachID and year; if multiple distinct values exist for that coach-year, treat as unknown.
# [across_tables], used_tables: ['AwardsCoaches']
SELECT
  COALESCE(team_lg.lgID_resolved, award_lg.lgID_resolved) AS computed_value,
  target_table.lgID AS actual_value
FROM Coaches AS target_table
LEFT JOIN (
  SELECT year, tmID,
         CASE WHEN COUNT(DISTINCT lgID) = 1 THEN MAX(lgID) ELSE NULL END AS lgID_resolved
  FROM Coaches
  WHERE lgID IS NOT NULL
  GROUP BY year, tmID
) AS team_lg
  ON team_lg.year = target_table.year AND team_lg.tmID = target_table.tmID
LEFT JOIN (
  SELECT coachID, year,
         CASE WHEN COUNT(DISTINCT lgID) = 1 THEN MAX(lgID) ELSE NULL END AS lgID_resolved
  FROM AwardsCoaches
  WHERE lgID IS NOT NULL
  GROUP BY coachID, year
) AS award_lg
  ON award_lg.coachID = target_table.coachID AND award_lg.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_FebOL.csv
# FebOL = (hOTL + rOTL) - (OctOL + NovOL + DecOL + JanOL + MarOL + AprOL)
# [row_scope]
SELECT (CAST(target_table.hOTL AS SIGNED) + CAST(target_table.rOTL AS SIGNED)) - (CAST(target_table.OctOL AS SIGNED) + CAST(target_table.NovOL AS SIGNED) + CAST(target_table.DecOL AS SIGNED) + CAST(target_table.JanOL AS SIGNED) + CAST(target_table.MarOL AS SIGNED) + CAST(target_table.AprOL AS SIGNED)) AS computed_value, target_table.FebOL AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_ftm.csv
# o_ftm = o_pts - 2 * o_fgm - o_3pm
# [row_scope]
SELECT (CAST(target_table.o_pts AS SIGNED) - 2 * CAST(target_table.o_fgm AS SIGNED) - CAST(target_table.o_3pm AS SIGNED)) AS computed_value, target_table.o_ftm AS actual_value FROM teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_ftm.csv
# For each team-season (tmID, year), o_ftm equals the sum of ftMade across all player stints recorded in players_teams for that team and year.
# [across_tables], used_tables: ['players_teams', 'players']
SELECT
  pt_sum.ftm_sum AS computed_value,
  target_table.o_ftm AS actual_value
FROM teams AS target_table
LEFT JOIN (
  SELECT
    pt.tmID,
    pt.year,
    SUM(CAST(pt.ftMade AS SIGNED)) AS ftm_sum
  FROM players_teams AS pt
  GROUP BY pt.tmID, pt.year
) AS pt_sum
  ON pt_sum.tmID = target_table.tmID
  AND pt_sum.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsSC_PIM.csv
# TeamsSC.PIM equals the sum of player PIM values from ScoringSC for the same (year, lgID, tmID).
# [across_tables], used_tables: ['Scoring', 'ScoringSC']
SELECT sc_sum.total_pim AS computed_value, CAST(target_table.PIM AS SIGNED) AS actual_value
FROM TeamsSC AS target_table
LEFT JOIN (
  SELECT year, lgID, tmID, SUM(CAST(PIM AS SIGNED)) AS total_pim
  FROM ScoringSC
  GROUP BY year, lgID, tmID
) AS sc_sum
  ON sc_sum.year = target_table.year
 AND sc_sum.lgID = target_table.lgID
 AND sc_sum.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_FavoriteCount.csv
# nan
# [count_or_exist with data sharing], given_table_name = votes
SELECT CASE WHEN target_table.PostTypeId = 1 THEN COALESCE(fv.cnt, 0) ELSE NULL END AS computed_value, target_table.FavoriteCount AS actual_value FROM posts AS target_table LEFT JOIN ( SELECT v.PostId, COUNT(*) AS cnt FROM votes v WHERE v.VoteTypeId = 5 GROUP BY v.PostId ) fv ON fv.PostId = target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_games.csv
# games = won + lost
# [row_scope]
SELECT (CAST(`target_table`.`won` AS SIGNED) + CAST(`target_table`.`lost` AS SIGNED)) AS `computed_value`, `target_table`.`games` AS `actual_value` FROM `teams` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Invoice_Total.csv
# For each invoice i, i.Total = SUM over all invoice lines l with l.InvoiceId = i.InvoiceId of (l.UnitPrice * l.Quantity).
# [across_tables], used_tables: ['InvoiceLine', 'Track']
SELECT computed_totals.computed_value, target_table.Total AS actual_value FROM Invoice AS target_table LEFT JOIN (SELECT il.InvoiceId, SUM(il.UnitPrice * il.Quantity) AS computed_value FROM InvoiceLine il GROUP BY il.InvoiceId) AS computed_totals ON computed_totals.InvoiceId = target_table.InvoiceId;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Document_FileName.csv
# FileName = CASE WHEN FolderFlag = 1 THEN Title ELSE Title + FileExtension END
# [row_scope]
SELECT CASE WHEN target_table.`FolderFlag` = 1 THEN target_table.`Title` ELSE CONCAT(target_table.`Title`, target_table.`FileExtension`) END AS computed_value, target_table.`FileName` AS actual_value FROM `Document` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Document_FileName.csv
# If the row is a folder (FolderFlag=1), then FileName = Title. Otherwise (FolderFlag=0), set FileName = Title concatenated with ext*, where ext* is the most frequent non-empty FileExtension among Document rows owned by the same Owner (using a subquery grouped by Owner and FileExtension to find the mode). The Employee table is used to join owners for validation (Employee.BusinessEntityID = Document.Owner), but the ext* selection is driven by Document rows.
# [across_tables], used_tables: ['Employee']
SELECT CASE WHEN target_table.FolderFlag = 1 THEN target_table.Title ELSE CONCAT(target_table.Title, COALESCE(ext_owner.FileExtension, '')) END AS computed_value, target_table.FileName AS actual_value FROM Document AS target_table LEFT JOIN Employee AS e ON e.BusinessEntityID = target_table.Owner LEFT JOIN ( SELECT t.Owner, t.FileExtension FROM ( SELECT Owner, FileExtension, ROW_NUMBER() OVER (PARTITION BY Owner ORDER BY cnt DESC, FileExtension) AS rn FROM ( SELECT Owner, FileExtension, COUNT(*) AS cnt FROM Document WHERE FolderFlag = 0 AND FileExtension IS NOT NULL AND FileExtension <> '' GROUP BY Owner, FileExtension ) c ) t WHERE t.rn = 1 ) AS ext_owner ON ext_owner.Owner = target_table.Owner;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Document_FileName.csv
# Let base_name = CASE WHEN Employee.JobTitle LIKE '%Manager%' OR Document.FolderFlag = 1 OR Document.FileExtension = '' THEN Document.Title ELSE CONCAT(Document.Title, Document.FileExtension) END. If the Document owner (Document.Owner -> Employee.BusinessEntityID) has at least one purchase order (PurchaseOrderHeader) then take the most recent PurchaseOrderHeader by OrderDate for that Employee and join to Vendor via VendorID; if such a Vendor exists, prefix base_name with Vendor.Name and ' - '. Computed FileName = COALESCE(CONCAT(Vendor.Name, ' - ', base_name), base_name).
# [across_tables], used_tables: ['Vendor']
SELECT
  COALESCE(CONCAT(ev.VendorName, ' - ', 
                  CASE 
                    WHEN (e.JobTitle LIKE '%Manager%') OR (target_table.FolderFlag = 1) OR (target_table.FileExtension = '') THEN target_table.Title 
                    ELSE CONCAT(target_table.Title, target_table.FileExtension)
                  END),
           CASE 
             WHEN (e.JobTitle LIKE '%Manager%') OR (target_table.FolderFlag = 1) OR (target_table.FileExtension = '') THEN target_table.Title 
             ELSE CONCAT(target_table.Title, target_table.FileExtension)
           END) AS computed_value,
  target_table.FileName AS actual_value
FROM Document AS target_table
LEFT JOIN Employee AS e
  ON e.BusinessEntityID = target_table.Owner
LEFT JOIN (
  SELECT x.EmployeeID, v.Name AS VendorName
  FROM (
    SELECT poh.EmployeeID, poh.VendorID, poh.OrderDate
    FROM PurchaseOrderHeader AS poh
    INNER JOIN (
      SELECT EmployeeID, MAX(OrderDate) AS MaxOrderDate
      FROM PurchaseOrderHeader
      GROUP BY EmployeeID
    ) AS mx
      ON mx.EmployeeID = poh.EmployeeID
     AND mx.MaxOrderDate = poh.OrderDate
  ) AS x
  INNER JOIN Vendor AS v
    ON v.BusinessEntityID = x.VendorID
) AS ev
  ON ev.EmployeeID = target_table.Owner;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Document_FileName.csv
# For any Document row D: if there exists at least one Product P such that a row (P.ProductID, D.DocumentNode) exists in ProductDocument, then FileName = D.Title || D.FileExtension; otherwise (no linked products) FileName = D.Title.
# [across_tables], used_tables: ['Product']
SELECT
  CASE
    WHEN COALESCE(dp.cnt, 0) > 0 THEN CONCAT(target_table.`Title`, target_table.`FileExtension`)
    ELSE target_table.`Title`
  END AS computed_value,
  target_table.`FileName` AS actual_value
FROM `Document` AS target_table
LEFT JOIN (
  SELECT pd.`DocumentNode`, COUNT(*) AS cnt
  FROM `ProductDocument` pd
  JOIN `Product` p ON p.`ProductID` = pd.`ProductID`
  GROUP BY pd.`DocumentNode`
) AS dp ON dp.`DocumentNode` = target_table.`DocumentNode`;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderDetail_OrderQty.csv
# OrderQty = LineTotal / UnitPrice
# [row_scope]
SELECT (CAST(`target_table`.`LineTotal` AS DECIMAL(65,30)) / CAST(`target_table`.`UnitPrice` AS DECIMAL(65,30))) AS computed_value, `target_table`.`OrderQty` AS actual_value FROM `PurchaseOrderDetail` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderDetail_OrderQty.csv
# OrderQty = ReceivedQty
# [row_scope]
SELECT target_table.ReceivedQty AS computed_value, target_table.OrderQty AS actual_value FROM PurchaseOrderDetail AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderDetail_OrderQty.csv
# OrderQty = ProductVendor.OnOrderQty for the vendor supplying that line item, i.e., match PurchaseOrderDetail.ProductID and PurchaseOrderHeader.VendorID to ProductVendor (BusinessEntityID).
# [across_tables], used_tables: ['PurchaseOrderHeader', 'ProductVendor']
SELECT pv.OnOrderQty AS computed_value, target_table.OrderQty AS actual_value FROM PurchaseOrderDetail AS target_table INNER JOIN PurchaseOrderHeader AS poh ON poh.PurchaseOrderID = target_table.PurchaseOrderID INNER JOIN ProductVendor AS pv ON pv.ProductID = target_table.ProductID AND pv.BusinessEntityID = poh.VendorID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_homeLost.csv
# homeLost = lost - awayLost - neutLoss
# [row_scope]
SELECT (CAST(target_table.`lost` AS SIGNED) - CAST(target_table.`awayLost` AS SIGNED) - CAST(target_table.`neutLoss` AS SIGNED)) AS computed_value, target_table.`homeLost` AS actual_value FROM `teams` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_dreb.csv
# o_dreb = o_reb - o_oreb
# [row_scope]
SELECT (CAST(target_table.o_reb AS SIGNED) - CAST(target_table.o_oreb AS SIGNED)) AS computed_value, target_table.o_dreb AS actual_value FROM teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_fga.csv
# For each team-season (tmID, year), o_fga equals the sum of all players_teams.fgAttempted recorded for that team and season across all player stints: o_fga(tmID, year) = SUM_over_all_players_and_stints(players_teams.fgAttempted WHERE players_teams.tmID = teams.tmID AND players_teams.year = teams.year).
# [across_tables], used_tables: ['players', 'players_teams']
SELECT pt_sum.sum_fga AS computed_value, target_table.o_fga AS actual_value
FROM teams AS target_table
LEFT JOIN (
  SELECT tmID, year, SUM(CAST(fgAttempted AS SIGNED)) AS sum_fga
  FROM players_teams
  GROUP BY tmID, year
) AS pt_sum
  ON pt_sum.tmID = target_table.tmID
 AND pt_sum.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Customer_PostalCode.csv
# For each CustomerId, set Customer.PostalCode to the Invoice.BillingPostalCode that occurs most frequently among that customer?s invoices. In case of a tie on frequency, choose the BillingPostalCode whose associated invoices include the most recent InvoiceDate; if still tied, choose the lexicographically smallest BillingPostalCode.
# [across_tables], used_tables: ['Invoice']
SELECT pc_mode.BillingPostalCode AS computed_value, target_table.PostalCode AS actual_value FROM Customer target_table LEFT JOIN ( SELECT CustomerId, BillingPostalCode FROM ( SELECT CustomerId, BillingPostalCode, cnt, max_dt, ROW_NUMBER() OVER (PARTITION BY CustomerId ORDER BY cnt DESC, max_dt DESC, BillingPostalCode ASC) AS rn FROM ( SELECT i.CustomerId, i.BillingPostalCode, COUNT(*) AS cnt, MAX(i.InvoiceDate) AS max_dt FROM Invoice i WHERE i.BillingPostalCode IS NOT NULL GROUP BY i.CustomerId, i.BillingPostalCode ) agg ) ranked WHERE rn = 1 ) pc_mode ON pc_mode.CustomerId = target_table.CustomerId;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Customer_PostalCode.csv
# For each CustomerId, set Customer.PostalCode to the Invoice.BillingPostalCode from the customer?s chronologically latest invoice by InvoiceDate; if multiple invoices share the same maximum InvoiceDate, break ties by the greatest InvoiceId.
# [across_tables], used_tables: ['Invoice']
SELECT latest_pc.BillingPostalCode AS computed_value, target_table.PostalCode AS actual_value FROM Customer target_table LEFT JOIN ( SELECT CustomerId, BillingPostalCode FROM ( SELECT i.CustomerId, i.BillingPostalCode, ROW_NUMBER() OVER (PARTITION BY i.CustomerId ORDER BY i.InvoiceDate DESC, i.InvoiceId DESC) AS rn FROM Invoice i WHERE i.BillingPostalCode IS NOT NULL ) x WHERE rn = 1 ) latest_pc ON latest_pc.CustomerId = target_table.CustomerId;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Customer_PostalCode.csv
# For each CustomerId, set Customer.PostalCode to the Invoice.BillingPostalCode from the customer?s earliest invoice by InvoiceDate; if multiple invoices share the same minimum InvoiceDate, break ties by the smallest InvoiceId.
# [across_tables], used_tables: ['Invoice']
SELECT first_pc.BillingPostalCode AS computed_value, target_table.PostalCode AS actual_value FROM Customer target_table LEFT JOIN ( SELECT CustomerId, BillingPostalCode FROM ( SELECT i.CustomerId, i.BillingPostalCode, ROW_NUMBER() OVER (PARTITION BY i.CustomerId ORDER BY i.InvoiceDate ASC, i.InvoiceId ASC) AS rn FROM Invoice i WHERE i.BillingPostalCode IS NOT NULL ) x WHERE rn = 1 ) first_pc ON first_pc.CustomerId = target_table.CustomerId;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_constructors_constructorRef.csv
# For each constructor that appears in constructorStandings (i.e., there exists at least one row in constructorStandings with the same constructorId), compute constructorRef as a slug of constructors.name as follows: (1) convert the name to lowercase; (2) replace every character that is not a letter, digit, or hyphen with a single space; (3) collapse consecutive spaces to a single space; (4) trim leading/trailing spaces; (5) replace remaining spaces with underscores; (6) preserve existing hyphens. If a constructor has no matching row in constructorStandings, return NULL.
# [across_tables], used_tables: ['constructorStandings']
SELECT
  CASE WHEN cs.constructorId IS NOT NULL THEN
    LOWER(
      REPLACE(
        TRIM(
          REGEXP_REPLACE(
            REGEXP_REPLACE(target_table.name, '[^[:alnum:]-]+', ' '),
            '[[:space:]]+', ' '
          )
        ),
        ' ', '_'
      )
    )
  ELSE NULL END AS computed_value,
  target_table.constructorRef AS actual_value
FROM constructors AS target_table
LEFT JOIN (
  SELECT DISTINCT constructorId FROM constructorStandings
) AS cs ON cs.constructorId = target_table.constructorId;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_constructors_constructorRef.csv
# Join constructors to constructorResults on constructorId; compute constructorRef by slugifying constructors.name: lowercase, replace spaces with underscores, strip all characters except letters, digits, underscores, and hyphens, then collapse multiple underscores into a single underscore. The join ensures cross-table dependency but does not alter the slug logic.
# [across_tables], used_tables: ['constructorResults']
SELECT
  REGEXP_REPLACE(
    REGEXP_REPLACE(REPLACE(LOWER(target_table.name), ' ', '_'), '[^a-z0-9_-]', ''),
    '_+',
    '_'
  ) AS computed_value,
  target_table.constructorRef AS actual_value
FROM constructors AS target_table
LEFT JOIN (
  SELECT constructorId, COUNT(*) AS appearances, SUM(COALESCE(points, 0)) AS total_points
  FROM constructorResults
  GROUP BY constructorId
) AS cr ON cr.constructorId = target_table.constructorId;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_constructors_constructorRef.csv
# constructorRef = lower(name)
# [row_scope]
SELECT LOWER(`target_table`.`name`) AS `computed_value`, `target_table`.`constructorRef` AS `actual_value` FROM `constructors` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_constructors_constructorRef.csv
# Compute earliest_year(constructorId) = MIN(races.year) via results JOIN races. If earliest_year(constructorId) < 1960 and constructors.url has a Wikipedia title suffix, derive constructorRef from the URL by taking the last path segment, removing the literal '_(constructor)', and lowercasing it; otherwise, set constructorRef to base_slug(name) = lowercased name with spaces replaced by underscores, parentheses removed, hyphens preserved.
# [across_tables], used_tables: ['results', 'races']
SELECT
CASE
  WHEN e.first_year < 1960 AND target_table.url IS NOT NULL
    THEN LOWER(REPLACE(SUBSTRING_INDEX(target_table.url,'/',-1),'_(constructor)',''))
  ELSE LOWER(REPLACE(REPLACE(REPLACE(REPLACE(target_table.name,' ','_'),'?','-'),'(',''),')',''))
END AS computed_value,
target_table.constructorRef AS actual_value
FROM constructors target_table
LEFT JOIN (
  SELECT rs.constructorId, MIN(r.year) AS first_year
  FROM results rs
  JOIN races r ON r.raceId = rs.raceId
  GROUP BY rs.constructorId
) e ON e.constructorId = target_table.constructorId;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_oRebounds.csv
# oRebounds = rebounds - dRebounds
# [row_scope]
SELECT (CAST(target_table.rebounds AS SIGNED) - CAST(target_table.dRebounds AS SIGNED)) AS computed_value, target_table.oRebounds AS actual_value FROM players_teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_series_post_lgIDLoser.csv
# lgIDLoser = lgIDWinner
# [row_scope]
SELECT target_table.lgIDWinner AS computed_value, target_table.lgIDLoser AS actual_value FROM series_post AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesTaxRate_Name.csv
# Join SalesTaxRate -> StateProvince -> CountryRegion and derive Name via a country- and taxtype-specific template: (1) If CountryRegionCode = 'CA' and TaxType = 1 then 'Canadian GST + ' || StateProvince.Name || ' Provincial Tax'; (2) If CountryRegionCode = 'CA' and TaxType in (2,3) then 'Canadian GST'; (3) If CountryRegionCode = 'US' and TaxType = 1 then StateProvince.Name || ' State Sales Tax'; (4) If CountryRegionCode in ('GB','DE','FR') and TaxType = 3 then CountryRegion.Name || ' Output Tax'; (5) If CountryRegionCode = 'AU' and TaxType = 3 then 'Taxable Supply'; otherwise NULL.
# [across_tables], used_tables: ['StateProvince', 'CountryRegion']
SELECT
  CASE
    WHEN cr.CountryRegionCode = 'CA' AND target_table.TaxType = 1 THEN CONCAT('Canadian GST + ', sp.Name, ' Provincial Tax')
    WHEN cr.CountryRegionCode = 'CA' AND target_table.TaxType IN (2,3) THEN 'Canadian GST'
    WHEN cr.CountryRegionCode = 'US' AND target_table.TaxType = 1 THEN CONCAT(sp.Name, ' State Sales Tax')
    WHEN cr.CountryRegionCode IN ('GB','DE','FR') AND target_table.TaxType = 3 THEN CONCAT(cr.Name, ' Output Tax')
    WHEN cr.CountryRegionCode = 'AU' AND target_table.TaxType = 3 THEN 'Taxable Supply'
    ELSE NULL
  END AS computed_value,
  target_table.Name AS actual_value
FROM `SalesTaxRate` AS target_table
JOIN `StateProvince` AS sp ON sp.StateProvinceID = target_table.StateProvinceID
JOIN `CountryRegion` AS cr ON cr.CountryRegionCode = sp.CountryRegionCode;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_JanW.csv
# JanW = (COALESCE(hW, 0) + COALESCE(rW, 0)) - (COALESCE(SepW, 0) + COALESCE(OctW, 0) + COALESCE(NovW, 0) + COALESCE(DecW, 0) + COALESCE(FebW, 0) + COALESCE(MarW, 0) + COALESCE(AprW, 0))
# [row_scope]
SELECT CAST((COALESCE(CAST(target_table.hW AS SIGNED), 0) + COALESCE(CAST(target_table.rW AS SIGNED), 0)) - (COALESCE(CAST(target_table.SepW AS SIGNED), 0) + COALESCE(CAST(target_table.OctW AS SIGNED), 0) + COALESCE(CAST(target_table.NovW AS SIGNED), 0) + COALESCE(CAST(target_table.DecW AS SIGNED), 0) + COALESCE(CAST(target_table.FebW AS SIGNED), 0) + COALESCE(CAST(target_table.MarW AS SIGNED), 0) + COALESCE(CAST(target_table.AprW AS SIGNED), 0)) AS SIGNED) AS computed_value, CAST(target_table.JanW AS SIGNED) AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_lgID.csv
# For each TeamsPost row identified by (year, tmID), derive lgID by joining to Teams on (year, tmID) and taking Teams.lgID.
# [across_tables], used_tables: ['Teams']
SELECT t.lgID AS computed_value, target_table.lgID AS actual_value
FROM TeamsPost AS target_table
LEFT JOIN Teams AS t
  ON t.year = target_table.year
 AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_tags_Count.csv
# nan
# [count_or_exist with data sharing], given_table_name = posts
SELECT COUNT(p.Id) AS computed_value, MAX(target_table.Count) AS actual_value FROM tags AS target_table LEFT JOIN posts p ON p.PostTypeId = 1 AND p.Tags IS NOT NULL AND p.Tags LIKE CONCAT('%<', target_table.TagName, '>%') GROUP BY target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_SafetyStockLevel.csv
# SafetyStockLevel = ReorderPoint / 0.75
# [row_scope]
SELECT CAST(target_table.ReorderPoint AS SIGNED) / 0.75 AS computed_value, target_table.SafetyStockLevel AS actual_value FROM Product AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_SafetyStockLevel.csv
# Compute batch_size(p) = MAX(TransactionHistory.Quantity) over all purchase transactions (TransactionType = 'P') for each Product p. Then SafetyStockLevel = CASE WHEN batch_size = 3 THEN 1000 WHEN batch_size = 60 THEN 60 WHEN batch_size = 550 THEN (500 if Product.FinishedGoodsFlag = 1 else 800) ELSE NULL END.
# [across_tables], used_tables: ['TransactionHistory', 'PurchaseOrderDetail', 'PurchaseOrderHeader']
SELECT
  CASE
    WHEN th_batch.batch_size = 3 THEN 1000
    WHEN th_batch.batch_size = 60 THEN 60
    WHEN th_batch.batch_size = 550 THEN CASE WHEN target_table.FinishedGoodsFlag = 1 THEN 500 ELSE 800 END
    ELSE NULL
  END AS computed_value,
  target_table.SafetyStockLevel AS actual_value
FROM Product AS target_table
LEFT JOIN (
  SELECT ProductID, MAX(Quantity) AS batch_size
  FROM TransactionHistory
  WHERE TransactionType = 'P'
  GROUP BY ProductID
) AS th_batch ON th_batch.ProductID = target_table.ProductID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_SafetyStockLevel.csv
# Let T = SUM of ProductInventory.Quantity over all locations for the product. Map T to the smallest business tier in {60, 100, 500, 800, 1000} that is >= T (capped at 1000). Let R = (4/3) * Product.ReorderPoint. Then SafetyStockLevel = MIN(tier_ceiling(T), R).
# [across_tables], used_tables: ['ProductInventory']
SELECT
  LEAST(
    CASE
      WHEN COALESCE(inv.sum_qty, 0) <= 60 THEN 60
      WHEN COALESCE(inv.sum_qty, 0) <= 100 THEN 100
      WHEN COALESCE(inv.sum_qty, 0) <= 500 THEN 500
      WHEN COALESCE(inv.sum_qty, 0) <= 800 THEN 800
      ELSE 1000
    END,
    (target_table.ReorderPoint * 4) / 3
  ) AS computed_value,
  target_table.SafetyStockLevel AS actual_value
FROM Product AS target_table
LEFT JOIN (
  SELECT ProductID, SUM(CAST(Quantity AS SIGNED)) AS sum_qty
  FROM ProductInventory
  GROUP BY ProductID
) AS inv ON inv.ProductID = target_table.ProductID;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_races_round.csv
# round = row_number within rows partitioned by year ordered by date ASC, COALESCE(time, 00:00:00) ASC
# [row_scope]
SELECT ROW_NUMBER() OVER (PARTITION BY target_table.`year` ORDER BY target_table.`date` ASC, COALESCE(target_table.`time`, CAST('00:00:00' AS TIME)) ASC) AS computed_value, target_table.`round` AS actual_value FROM races AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_races_round.csv
# Within each year, order races by the earliest qualifying record for that race (qmin(r) = MIN(qualifying.qualifyId)). The round equals 1 + the number of races in the same year with a smaller qmin; if a race has no qualifying rows, use raceId as a fallback tie-breaker. Formally: round(r) = 1 + |{ r2 in same year : COALESCE(qmin(r2), r2.raceId) < COALESCE(qmin(r), r.raceId) }|.
# [across_tables], used_tables: ['qualifying']
SELECT (SELECT COUNT(*) + 1 FROM races r2 LEFT JOIN (SELECT raceId, MIN(qualifyId) AS min_qid FROM qualifying GROUP BY raceId) AS q2 ON r2.raceId = q2.raceId WHERE r2.year = target_table.year AND COALESCE(q2.min_qid, r2.raceId) < COALESCE(q1.min_qid, target_table.raceId)) AS computed_value, target_table.round AS actual_value FROM races AS target_table LEFT JOIN (SELECT raceId, MIN(qualifyId) AS min_qid FROM qualifying GROUP BY raceId) AS q1 ON target_table.raceId = q1.raceId
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Customer_Address.csv
# For each customer, set Address to the BillingAddress that appears most frequently on that customer?s invoices; if multiple BillingAddress values tie on frequency, pick the one most recently used (highest InvoiceDate); if still tied, pick the lexicographically smallest BillingAddress.
# [across_tables], used_tables: ['Invoice']
SELECT
  best_addr.computed_address AS computed_value,
  target_table.Address AS actual_value
FROM Customer AS target_table
LEFT JOIN (
  SELECT r.CustomerId, r.BillingAddress AS computed_address
  FROM (
    SELECT
      s.CustomerId,
      s.BillingAddress,
      s.cnt,
      s.last_date,
      ROW_NUMBER() OVER (
        PARTITION BY s.CustomerId
        ORDER BY s.cnt DESC, s.last_date DESC, s.BillingAddress ASC
      ) AS rn
    FROM (
      SELECT
        i.CustomerId,
        i.BillingAddress,
        COUNT(*) AS cnt,
        MAX(i.InvoiceDate) AS last_date
      FROM Invoice AS i
      GROUP BY i.CustomerId, i.BillingAddress
    ) AS s
  ) AS r
  WHERE r.rn = 1
) AS best_addr
ON target_table.CustomerId = best_addr.CustomerId;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Customer_Address.csv
# For each customer, set Address to the BillingAddress from the most recent invoice (max InvoiceDate) for that customer; if multiple invoices share the same latest date, choose the one with the largest InvoiceId.
# [across_tables], used_tables: ['Invoice']
SELECT
  latest_addr.computed_address AS computed_value,
  target_table.Address AS actual_value
FROM Customer AS target_table
LEFT JOIN (
  SELECT li.CustomerId, li.BillingAddress AS computed_address
  FROM (
    SELECT i.CustomerId, i.InvoiceDate, i.InvoiceId, i.BillingAddress,
           ROW_NUMBER() OVER (PARTITION BY i.CustomerId ORDER BY i.InvoiceDate DESC, i.InvoiceId DESC) AS rn
    FROM Invoice AS i
  ) AS li
  WHERE li.rn = 1
) AS latest_addr
ON target_table.CustomerId = latest_addr.CustomerId;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Customer_Address.csv
# For each customer, the Address equals the BillingAddress from that customers invoice that has the greatest number of purchased tracks (max count of InvoiceLine rows per InvoiceId). If there is a tie, choose the lexicographically smallest BillingAddress among the tied invoices.
# [across_tables], used_tables: ['Invoice', 'InvoiceLine']
SELECT densest_addr.computed_value, target_table.Address AS actual_value
FROM Customer AS target_table
LEFT JOIN (
  SELECT i.CustomerId, MIN(i.BillingAddress) AS computed_value
  FROM Invoice i
  JOIN (
    SELECT il.InvoiceId, COUNT(*) AS line_count
    FROM InvoiceLine il
    GROUP BY il.InvoiceId
  ) lc ON lc.InvoiceId = i.InvoiceId
  JOIN (
    SELECT d.CustomerId, MAX(d.line_count) AS max_lines
    FROM (
      SELECT i.CustomerId, il.InvoiceId, COUNT(*) AS line_count
      FROM Invoice i
      JOIN InvoiceLine il ON il.InvoiceId = i.InvoiceId
      GROUP BY i.CustomerId, il.InvoiceId
    ) d
    GROUP BY d.CustomerId
  ) mx ON mx.CustomerId = i.CustomerId AND lc.line_count = mx.max_lines
  GROUP BY i.CustomerId
) densest_addr ON densest_addr.CustomerId = target_table.CustomerId;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsHalf_G.csv
# G = W + L + T
# [row_scope]
SELECT CAST(target_table.`W` AS SIGNED) + CAST(target_table.`L` AS SIGNED) + CAST(target_table.`T` AS SIGNED) AS computed_value, target_table.`G` AS actual_value FROM `TeamsHalf` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Mondial_island_Height.csv
# For each island, compute its Height as the maximum height among all mountains linked to that island via mountainOnIsland. In other words: Height(island) = MAX(mountain.Height) WHERE mountainOnIsland.Island = island.Name AND mountainOnIsland.Mountain = mountain.Name.
# [across_tables], used_tables: ['mountainOnIsland', 'mountain']
SELECT highest_mountain.computed_value, target_table.Height AS actual_value FROM island AS target_table LEFT JOIN ( SELECT moi.Island, MAX(m.Height) AS computed_value FROM mountainOnIsland AS moi INNER JOIN mountain AS m ON m.Name = moi.Mountain GROUP BY moi.Island ) AS highest_mountain ON highest_mountain.Island = target_table.Name;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_confID.csv
# For each team-season (year, lgID, tmID), compute the total number of games played against opponents grouped by the opponents? conference using TeamVsTeam joined to Teams (opponents). Total games vs an opponent conference = SUM(W + L + COALESCE(T,0) + COALESCE(OTL,0)), casting T and OTL to SIGNED when needed. The predicted confID is the conference with the maximum total games; break ties by choosing the lexicographically smallest conference code.
# [across_tables], used_tables: ['TeamVsTeam']
SELECT computed.computed_value AS computed_value, target_table.confID AS actual_value
FROM Teams AS target_table
LEFT JOIN (
  SELECT best.year, best.lgID, best.tmID, MIN(best.opp_confID) AS computed_value
  FROM (
    SELECT oc.year, oc.lgID, oc.tmID, oc.opp_confID, oc.games_vs_conf, mc.max_games
    FROM (
      SELECT tvt.year, tvt.lgID, tvt.tmID, opp.confID AS opp_confID,
             SUM(CAST(tvt.W AS SIGNED) + CAST(tvt.L AS SIGNED) + COALESCE(CAST(tvt.T AS SIGNED), 0) + COALESCE(CAST(tvt.OTL AS SIGNED), 0)) AS games_vs_conf
      FROM TeamVsTeam tvt
      JOIN Teams opp
        ON opp.year = tvt.year
       AND opp.lgID = tvt.lgID
       AND opp.tmID = tvt.oppID
      WHERE opp.confID IS NOT NULL
      GROUP BY tvt.year, tvt.lgID, tvt.tmID, opp.confID
    ) AS oc
    JOIN (
      SELECT year, lgID, tmID, MAX(games_vs_conf) AS max_games
      FROM (
        SELECT tvt.year AS year, tvt.lgID AS lgID, tvt.tmID AS tmID, opp.confID AS opp_confID,
               SUM(CAST(tvt.W AS SIGNED) + CAST(tvt.L AS SIGNED) + COALESCE(CAST(tvt.T AS SIGNED), 0) + COALESCE(CAST(tvt.OTL AS SIGNED), 0)) AS games_vs_conf
        FROM TeamVsTeam tvt
        JOIN Teams opp ON opp.year = tvt.year AND opp.lgID = tvt.lgID AND opp.tmID = tvt.oppID
        WHERE opp.confID IS NOT NULL
        GROUP BY tvt.year, tvt.lgID, tvt.tmID, opp.confID
      ) AS tmp
      GROUP BY year, lgID, tmID
    ) AS mc
      ON mc.year = oc.year AND mc.lgID = oc.lgID AND mc.tmID = oc.tmID AND mc.max_games = oc.games_vs_conf
  ) AS best
  GROUP BY best.year, best.lgID, best.tmID
) AS computed
  ON computed.year = target_table.year AND computed.lgID = target_table.lgID AND computed.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesPersonQuotaHistory_ModifiedDate.csv
# ModifiedDate = DATEADD(hour, CASE WHEN MONTH(QuotaDate) IN (2, 3) THEN 2 ELSE 1 END, DATEADD(day, -45, QuotaDate))
# [row_scope]
SELECT DATE_ADD(DATE_ADD(target_table.QuotaDate, INTERVAL -45 DAY), INTERVAL (CASE WHEN MONTH(target_table.QuotaDate) IN (2, 3) THEN 2 ELSE 1 END) HOUR) AS computed_value, target_table.ModifiedDate AS actual_value FROM SalesPersonQuotaHistory AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesPersonQuotaHistory_ModifiedDate.csv
# For each SalesPersonQuotaHistory row, let base_date = DATE(QuotaDate) ? 45 days. Set ModifiedDate to base_date with its time-of-day taken from the SalesOrderHeader.ModifiedDate of the same salesperson (SalesOrderHeader.SalesPersonID = SalesPersonQuotaHistory.BusinessEntityID) that is temporally closest to base_date (smallest absolute difference in seconds).
# [across_tables], used_tables: ['SalesOrderHeader', 'ShipMethod']
SELECT
  TIMESTAMP(
    DATE_SUB(DATE(target_table.QuotaDate), INTERVAL 45 DAY),
    (
      SELECT TIME(soh1.ModifiedDate)
      FROM SalesOrderHeader AS soh1
      WHERE soh1.SalesPersonID = target_table.BusinessEntityID
      ORDER BY ABS(TIMESTAMPDIFF(SECOND, DATE_SUB(DATE(target_table.QuotaDate), INTERVAL 45 DAY), soh1.ModifiedDate)) ASC
      LIMIT 1
    )
  ) AS computed_value,
  target_table.ModifiedDate AS actual_value
FROM SalesPersonQuotaHistory AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesPersonQuotaHistory_ModifiedDate.csv
# For each SalesPersonQuotaHistory row, set ModifiedDate to QuotaDate minus 45 days, and take the time-of-day (HH:MM:SS) from the SalesPerson.ModifiedDate of the same BusinessEntityID. If SalesPerson has no row (or its time is NULL), fall back to the time-of-day of the SalesTerritoryHistory row active at QuotaDate; if still not available, use '01:00:00'.
# [across_tables], used_tables: ['SalesTerritoryHistory']
SELECT
  TIMESTAMP(
    DATE(DATE_SUB(target_table.QuotaDate, INTERVAL 45 DAY)),
    COALESCE(
      TIME(sp.ModifiedDate),
      TIME(sth_active.ModifiedDate),
      '01:00:00'
    )
  ) AS computed_value,
  target_table.ModifiedDate AS actual_value
FROM SalesPersonQuotaHistory AS target_table
LEFT JOIN SalesPerson AS sp
  ON sp.BusinessEntityID = target_table.BusinessEntityID
LEFT JOIN SalesTerritoryHistory AS sth_active
  ON sth_active.BusinessEntityID = target_table.BusinessEntityID
 AND sth_active.StartDate <= target_table.QuotaDate
 AND (sth_active.EndDate IS NULL OR sth_active.EndDate >= target_table.QuotaDate);
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_ProductPhoto_ThumbnailPhotoFileName.csv
# ThumbnailPhotoFileName = REPLACE(LargePhotoFileName, '_large', '_small')
# [row_scope]
SELECT REPLACE(`target_table`.`LargePhotoFileName`, '_large', '_small') AS computed_value, `target_table`.`ThumbnailPhotoFileName` AS actual_value FROM `ProductPhoto` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Document_Title.csv
# If FolderFlag = 1 and DocumentLevel = 0, Title is CONCAT(first word of Employee.JobTitle, 's'). Else if FolderFlag = 0, Title is FileName with the exact trailing FileExtension removed when it matches; otherwise Title is COALESCE(FileName, CONCAT(Person.FirstName, ' ', Person.LastName)). This uses Document joined to Employee and Person.
# [across_tables], used_tables: ['Employee', 'Person']
SELECT
  CASE
    WHEN target_table.FolderFlag = 1 AND target_table.DocumentLevel = 0 AND e.JobTitle IS NOT NULL
      THEN CONCAT(SUBSTRING_INDEX(e.JobTitle, ' ', 1), 's')
    WHEN target_table.FolderFlag = 0 THEN
      CASE
        WHEN target_table.FileExtension IS NOT NULL AND target_table.FileExtension <> '' AND RIGHT(target_table.FileName, CHAR_LENGTH(target_table.FileExtension)) = target_table.FileExtension
          THEN LEFT(target_table.FileName, CHAR_LENGTH(target_table.FileName) - CHAR_LENGTH(target_table.FileExtension))
        ELSE target_table.FileName
      END
    ELSE COALESCE(target_table.FileName, CONCAT(p.FirstName, ' ', p.LastName))
  END AS computed_value,
  target_table.Title AS actual_value
FROM Document AS target_table
LEFT JOIN Employee AS e ON e.BusinessEntityID = target_table.Owner
LEFT JOIN Person AS p ON p.BusinessEntityID = e.BusinessEntityID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Document_Title.csv
# For document rows (FolderFlag = 0) that are linked to products via ProductDocument, derive a noun phrase from the associated products/models and append the parent folder title: 1) Determine the parent folder Title by joining Document to its parent DocumentNode (the path one level up). 2) From ProductDocument -> Product (and ProductModel if available), extract the last word of ProductModel.Name if not null, else the last word of Product.Name; normalize 'Crankarm' to 'Crank Arm'. 3) Build a noun phrase from up to the first two distinct nouns (alphabetically) joined with ' and '. 4) If the parent folder Title is 'Maintenance', set Title = CONCAT(<noun phrase>, ' ', parent Title). Otherwise leave it null.
# [across_tables], used_tables: ['ProductDocument', 'Product', 'ProductModel']
SELECT
  CASE 
    WHEN target_table.FolderFlag = 0 AND parent_d.Title = 'Maintenance' AND pn.noun_phrase IS NOT NULL AND pn.noun_phrase <> ''
      THEN CONCAT(pn.noun_phrase, ' ', parent_d.Title)
    ELSE NULL
  END AS computed_value,
  target_table.Title AS actual_value
FROM Document AS target_table
LEFT JOIN (
  SELECT y.DocumentNode,
         CASE 
           WHEN INSTR(y.gc, '||') > 0 
             THEN CONCAT(SUBSTRING_INDEX(y.gc, '||', 1), ' and ', SUBSTRING_INDEX(SUBSTRING_INDEX(y.gc, '||', 2), '||', -1))
           ELSE y.gc
         END AS noun_phrase
  FROM (
    SELECT pd.DocumentNode,
           GROUP_CONCAT(
             DISTINCT 
             CASE 
               WHEN TRIM(SUBSTRING_INDEX(COALESCE(pm.Name, p.Name), ' ', -1)) = 'Crankarm' THEN 'Crank Arm'
               ELSE TRIM(SUBSTRING_INDEX(COALESCE(pm.Name, p.Name), ' ', -1))
             END
             ORDER BY 
               CASE 
                 WHEN TRIM(SUBSTRING_INDEX(COALESCE(pm.Name, p.Name), ' ', -1)) = 'Crankarm' THEN 'Crank Arm'
                 ELSE TRIM(SUBSTRING_INDEX(COALESCE(pm.Name, p.Name), ' ', -1))
               END
             SEPARATOR '||'
           ) AS gc
    FROM ProductDocument pd
    LEFT JOIN Product p ON p.ProductID = pd.ProductID
    LEFT JOIN ProductModel pm ON pm.ProductModelID = p.ProductModelID
    WHERE pd.DocumentNode IS NOT NULL
    GROUP BY pd.DocumentNode
  ) y
) pn ON pn.DocumentNode = target_table.DocumentNode
LEFT JOIN Document parent_d
  ON parent_d.DocumentNode = 
     CASE 
       WHEN target_table.DocumentNode = '/' THEN NULL 
       ELSE CONCAT(
              LEFT(TRIM(TRAILING '/' FROM target_table.DocumentNode),
                  CHAR_LENGTH(TRIM(TRAILING '/' FROM target_table.DocumentNode)) 
                  - CHAR_LENGTH(SUBSTRING_INDEX(TRIM(TRAILING '/' FROM target_table.DocumentNode), '/', -1)) - 1
              ),
              '/'
            )
     END
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_JanL.csv
# JanL = COALESCE(hL,0) + COALESCE(rL,0) - (COALESCE(SepL,0) + COALESCE(OctL,0) + COALESCE(NovL,0) + COALESCE(DecL,0) + COALESCE(FebL,0) + COALESCE(MarL,0) + COALESCE(AprL,0))
# [row_scope]
SELECT
  (
    CAST(COALESCE(target_table.hL, 0) AS SIGNED)
    + CAST(COALESCE(target_table.rL, 0) AS SIGNED)
    - (
      CAST(COALESCE(target_table.SepL, 0) AS SIGNED)
      + CAST(COALESCE(target_table.OctL, 0) AS SIGNED)
      + CAST(COALESCE(target_table.NovL, 0) AS SIGNED)
      + CAST(COALESCE(target_table.DecL, 0) AS SIGNED)
      + CAST(COALESCE(target_table.FebL, 0) AS SIGNED)
      + CAST(COALESCE(target_table.MarL, 0) AS SIGNED)
      + CAST(COALESCE(target_table.AprL, 0) AS SIGNED)
    )
  ) AS computed_value,
  target_table.JanL AS actual_value
FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderDetail_UnitPrice.csv
# UnitPrice = LineTotal / OrderQty
# [row_scope]
SELECT target_table.LineTotal / NULLIF(target_table.OrderQty, 0) AS computed_value, target_table.UnitPrice AS actual_value FROM PurchaseOrderDetail AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderDetail_UnitPrice.csv
# For each PurchaseOrderDetail row, UnitPrice equals the LastReceiptCost from ProductVendor for the same ProductID and the vendor listed on its PurchaseOrderHeader: UnitPrice = ProductVendor.LastReceiptCost where ProductVendor.ProductID = PurchaseOrderDetail.ProductID AND ProductVendor.BusinessEntityID = PurchaseOrderHeader.VendorID AND PurchaseOrderHeader.PurchaseOrderID = PurchaseOrderDetail.PurchaseOrderID.
# [across_tables], used_tables: ['ProductVendor', 'PurchaseOrderHeader']
SELECT pv.LastReceiptCost AS computed_value, target_table.UnitPrice AS actual_value FROM PurchaseOrderDetail AS target_table JOIN PurchaseOrderHeader AS poh ON poh.PurchaseOrderID = target_table.PurchaseOrderID JOIN ProductVendor AS pv ON pv.ProductID = target_table.ProductID AND pv.BusinessEntityID = poh.VendorID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_SoW.csv
# For each team-season (year, tmID), SoW (Shootout Wins) equals the sum of goalie shootout wins recorded for that team-season in GoaliesShootout. That is, SoW(year, tmID) = SUM over GoaliesShootout where year = Teams.year AND tmID = Teams.tmID of GoaliesShootout.W.
# [across_tables], used_tables: ['GoaliesShootout', 'ScoringShootout']
SELECT
  gs_total.total_wins AS computed_value,
  target_table.SoW AS actual_value
FROM Teams AS target_table
LEFT JOIN (
  SELECT year, tmID, SUM(CAST(W AS SIGNED)) AS total_wins
  FROM GoaliesShootout
  GROUP BY year, tmID
) AS gs_total
  ON gs_total.year = target_table.year
 AND gs_total.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_lose_score.csv
# lose_score = win_score - margin
# [row_scope]
SELECT CAST(target_table.win_score AS SIGNED) - CAST(target_table.margin AS SIGNED) AS computed_value, target_table.lose_score AS actual_value FROM matches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_LasActivityDate.csv
# LasActivityDate = greatest among posts.CreaionDate, posts.LastEditDate, posts.CommunityOwnedDate, posts.ClosedDate, and the latest postHistory.CreationDate for the same post where PostHistoryTypeId in (2, 5).
# [across_tables], used_tables: ['postHistory']
SELECT
  GREATEST(
    IFNULL(target_table.CreaionDate, '1000-01-01 00:00:00'),
    IFNULL(target_table.LastEditDate, '1000-01-01 00:00:00'),
    IFNULL(target_table.CommunityOwnedDate, '1000-01-01 00:00:00'),
    IFNULL(target_table.ClosedDate, '1000-01-01 00:00:00'),
    IFNULL(last_ph_edit.last_ph_date, '1000-01-01 00:00:00')
  ) AS computed_value,
  target_table.LasActivityDate AS actual_value
FROM posts AS target_table
LEFT JOIN (
  SELECT PostId, MAX(CreationDate) AS last_ph_date
  FROM postHistory
  WHERE PostHistoryTypeId IN (2, 5)
  GROUP BY PostId
) AS last_ph_edit
ON last_ph_edit.PostId = target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_PostoRebounds.csv
# PostoRebounds = PostRebounds - PostdRebounds
# [row_scope]
SELECT (CAST(target_table.PostRebounds AS SIGNED) - CAST(target_table.PostdRebounds AS SIGNED)) AS computed_value, target_table.PostoRebounds AS actual_value FROM players_teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_NovL.csv
# For each (year, tmID), NovL = Teams.L - (SepL + OctL + DecL + JanL + FebL + MarL + AprL), treating any missing monthly values as 0. This uses Teams for the season?s total regulation losses and TeamSplits for the other months? losses.
# [across_tables], used_tables: ['TeamsHalf', 'TeamVsTeam']
SELECT
  CAST(t.L AS SIGNED)
  - (
      COALESCE(CAST(target_table.SepL AS SIGNED), 0)
    + COALESCE(CAST(target_table.OctL AS SIGNED), 0)
    + COALESCE(CAST(target_table.DecL AS SIGNED), 0)
    + COALESCE(CAST(target_table.JanL AS SIGNED), 0)
    + COALESCE(CAST(target_table.FebL AS SIGNED), 0)
    + COALESCE(CAST(target_table.MarL AS SIGNED), 0)
    + COALESCE(CAST(target_table.AprL AS SIGNED), 0)
    ) AS computed_value,
  target_table.NovL AS actual_value
FROM TeamSplits AS target_table
JOIN Teams t
  ON t.year = target_table.year
 AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_GoaliesSC_L.csv
# L = GP - W - T
# [row_scope]
SELECT CAST(`target_table`.`GP` AS SIGNED) - CAST(`target_table`.`W` AS SIGNED) - CAST(`target_table`.`T` AS SIGNED) AS computed_value, `target_table`.`L` AS actual_value FROM `GoaliesSC` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_GoaliesSC_L.csv
# For each row (playerID, year, tmID) in GoaliesSC, the goalies Stanley Cup losses L equal the team?s total game losses across Stanley Cup rounds only. Sum, for that team-year, all SeriesPost records where round in {SCSF, SCF}: add SeriesPost.L when the team is tmIDWinner, and add SeriesPost.W when the team is tmIDLoser. (Teams is used to align team-year context; no league-final rounds like F are counted.)
# [across_tables], used_tables: ['SeriesPost']
SELECT
  COALESCE(series_losses.total_losses, 0) AS computed_value,
  target_table.L AS actual_value
FROM GoaliesSC AS target_table
LEFT JOIN (
  SELECT s.year, s.tmID, SUM(CAST(s.losses AS SIGNED)) AS total_losses
  FROM (
    SELECT CAST(year AS SIGNED) AS year, tmIDWinner AS tmID, CAST(L AS SIGNED) AS losses
    FROM SeriesPost
    WHERE round IN ('SCF','SCSF')
    UNION ALL
    SELECT CAST(year AS SIGNED) AS year, tmIDLoser AS tmID, CAST(W AS SIGNED) AS losses
    FROM SeriesPost
    WHERE round IN ('SCF','SCSF')
  ) AS s
  GROUP BY s.year, s.tmID
) AS series_losses
  ON series_losses.year = target_table.year AND series_losses.tmID = target_table.tmID
LEFT JOIN Teams AS t
  ON t.year = target_table.year AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_a_q4b.csv
# a_q4b = a_score - 6 * (a_q4g + a_etg) - a_etb
# [row_scope]
SELECT (CAST(target_table.a_score AS SIGNED INTEGER) - 6 * (CAST(target_table.a_q4g AS SIGNED INTEGER) + CAST(target_table.a_etg AS SIGNED INTEGER)) - CAST(target_table.a_etb AS SIGNED INTEGER)) AS computed_value, target_table.a_q4b AS actual_value FROM matches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_results_position.csv
# position = CAST(positionText AS INTEGER)
# [row_scope]
SELECT CAST(target_table.`positionText` AS SIGNED) AS computed_value, target_table.`position` AS actual_value FROM `results` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_results_position.csv
# For each race (by raceId), a driver?s position equals the sequential rank among classified results ordered by positionOrder ascending, where classified statuses are those whose status (joined from the status table by statusId) is either 'Finished' or starts with a plus laps indicator (e.g., '+1 Lap', '+2 Laps', matched by status LIKE '+%Lap%'). Non-classified statuses yield NULL position.
# [across_tables], used_tables: ['races', 'status']
SELECT
  CASE WHEN s.status = 'Finished' OR s.status LIKE '+%Lap%'
       THEN ROW_NUMBER() OVER (
              PARTITION BY target_table.raceId
              ORDER BY CASE WHEN s.status = 'Finished' OR s.status LIKE '+%Lap%'
                              THEN 0 ELSE 1 END,
                       target_table.positionOrder ASC
            )
       ELSE NULL END AS computed_value,
  target_table.position AS actual_value
FROM results AS target_table
LEFT JOIN status AS s ON s.statusId = target_table.statusId
LEFT JOIN races AS r ON r.raceId = target_table.raceId;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamVsTeam_OTL.csv
# Primary rule: OTL(team vs opponent) = max(0, W(opponent vs team) - L(team vs opponent)). To ensure season-level consistency and to use Teams table, cap the value by the team-season OTL total: computed OTL = min( max( W(opponent vs team) - L(team vs opponent), 0 ), Teams.OTL(team-season) ).
# [across_tables], used_tables: ['Teams']
SELECT
  LEAST(
    GREATEST(CAST(COALESCE(rev.W, 0) AS SIGNED) - CAST(COALESCE(target_table.L, 0) AS SIGNED), 0),
    CAST(COALESCE(tt.OTL, 0) AS SIGNED)
  ) AS computed_value,
  target_table.OTL AS actual_value
FROM TeamVsTeam AS target_table
LEFT JOIN TeamVsTeam AS rev
  ON rev.year = target_table.year
 AND rev.tmID = target_table.oppID
 AND rev.oppID = target_table.tmID
LEFT JOIN Teams AS tt
  ON tt.year = target_table.year
 AND tt.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Coaches_postg.csv
# postg = postw + postl + postt
# [row_scope]
SELECT CAST(`target_table`.`postw` AS SIGNED) + CAST(`target_table`.`postl` AS SIGNED) + CAST(`target_table`.`postt` AS SIGNED) AS `computed_value`, `target_table`.`postg` AS `actual_value` FROM `Coaches` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_PostPoints.csv
# PostPoints = 2 * PostfgMade + PostftMade + PostthreeMade
# [row_scope]
SELECT (CAST(2 AS SIGNED) * CAST(`target_table`.`PostfgMade` AS SIGNED) + CAST(`target_table`.`PostftMade` AS SIGNED) + CAST(`target_table`.`PostthreeMade` AS SIGNED)) AS `computed_value`, `target_table`.`PostPoints` AS `actual_value` FROM `players_teams` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_series_post_L.csv
# For a given series (year = y, losing team = L), the winner?s losses in that series equal the losing team?s total postseason wins in that season minus the wins that same team collected in earlier series it won in that season. Formally: L = SUM_coaches(post_wins for (y, L)) - SUM_series_post(W for rows with (year = y AND tmIDWinner = L)). Because a team appears as 'loser' only in its final series of that postseason, all of its other series in that season are wins and are captured by the second term.
# [across_tables], used_tables: ['coaches']
SELECT
  CAST(IFNULL(loser_coach_wins.total_post_wins, 0) AS SIGNED) - CAST(IFNULL(loser_prior_series_wins.total_prior_wins, 0) AS SIGNED) AS computed_value,
  target_table.L AS actual_value
FROM series_post AS target_table
LEFT JOIN (
  SELECT year, tmID AS team, SUM(COALESCE(post_wins, 0)) AS total_post_wins
  FROM coaches
  GROUP BY year, tmID
) AS loser_coach_wins
  ON loser_coach_wins.year = target_table.year
 AND loser_coach_wins.team = target_table.tmIDLoser
LEFT JOIN (
  SELECT year, tmIDWinner AS team, SUM(COALESCE(W, 0)) AS total_prior_wins
  FROM series_post
  GROUP BY year, tmIDWinner
) AS loser_prior_series_wins
  ON loser_prior_series_wins.year = target_table.year
 AND loser_prior_series_wins.team = target_table.tmIDLoser;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_driverStandings_points.csv
# For each row in driverStandings (at a given race), points equals the cumulative sum of results.points for that driver over all races in the same season (same races.year) with round less than or equal to the current races round.
# [across_tables], used_tables: ['results', 'races']
SELECT COALESCE(cp.cum_points, 0.0) AS computed_value, target_table.points AS actual_value
FROM driverStandings AS target_table
JOIN races AS r_cur ON r_cur.raceId = target_table.raceId
LEFT JOIN (
  SELECT r_target.year, r_target.round, res.driverId, SUM(res.points) AS cum_points
  FROM results AS res
  JOIN races AS r_res ON r_res.raceId = res.raceId
  JOIN races AS r_target ON r_target.year = r_res.year AND r_target.round >= r_res.round
  GROUP BY r_target.year, r_target.round, res.driverId
) AS cp
  ON cp.year = r_cur.year AND cp.round = r_cur.round AND cp.driverId = target_table.driverId;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Employee_Country.csv
# Country = 'Canada' if State in {'AB','BC','MB','NB','NL','NS','NT','NU','ON','PE','QC','SK','YT'}
# [row_scope]
SELECT CASE WHEN target_table.`State` IN ('AB','BC','MB','NB','NL','NS','NT','NU','ON','PE','QC','SK','YT') THEN 'Canada' ELSE NULL END AS computed_value, target_table.`Country` AS actual_value FROM `Employee` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Employee_Country.csv
# For each employee, take S = Employee.State. Among all Customer rows where State = S, select the Country that appears most frequently (mode); if there is a tie, choose the lexicographically smallest Country. Set Employee.Country = that value.
# [across_tables], used_tables: ['Customer', 'Invoice']
SELECT
  mapping.Country AS computed_value,
  target_table.Country AS actual_value
FROM Employee AS target_table
LEFT JOIN (
  SELECT cs.StateKey, MIN(cs.Country) AS Country
  FROM (
    SELECT State AS StateKey, Country, COUNT(*) AS cnt
    FROM Customer
    WHERE State IS NOT NULL AND Country IS NOT NULL
    GROUP BY State, Country
  ) AS cs
  JOIN (
    SELECT StateKey, MAX(cnt) AS max_cnt
    FROM (
      SELECT State AS StateKey, Country, COUNT(*) AS cnt
      FROM Customer
      WHERE State IS NOT NULL AND Country IS NOT NULL
      GROUP BY State, Country
    ) AS cx
    GROUP BY StateKey
  ) AS cmax
    ON cs.StateKey = cmax.StateKey AND cs.cnt = cmax.max_cnt
  GROUP BY cs.StateKey
) AS mapping
  ON mapping.StateKey = target_table.State;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_fta.csv
# For each team-season (year, tmID), o_fta equals the sum of all players regular-season free throws attempted for that team-season: o_fta(year, tmID) = SUM_{players_teams where year=teams.year AND tmID=teams.tmID} (players_teams.ftAttempted).
# [across_tables], used_tables: ['players_teams']
SELECT
  COALESCE(pt_sum_fta.computed_value, 0) AS computed_value,
  target_table.o_fta AS actual_value
FROM teams AS target_table
LEFT JOIN (
  SELECT year, tmID, SUM(COALESCE(ftAttempted, 0)) AS computed_value
  FROM players_teams
  GROUP BY year, tmID
) AS pt_sum_fta
  ON pt_sum_fta.year = target_table.year
 AND pt_sum_fta.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_points.csv
# points = 2 * fgMade + ftMade + threeMade
# [row_scope]
SELECT (CAST(target_table.fgMade AS SIGNED) * 2 + CAST(target_table.ftMade AS SIGNED) + CAST(target_table.threeMade AS SIGNED)) AS computed_value, target_table.points AS actual_value FROM players_teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_users_UpVotes.csv
# nan
# [count_or_exist with data sharing], given_table_name = votes
SELECT COUNT(v.Id) AS computed_value, target_table.UpVotes AS actual_value FROM users AS target_table LEFT JOIN votes AS v ON v.UserId = target_table.Id AND v.VoteTypeId = 2 GROUP BY target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_pitStops_milliseconds.csv
# milliseconds = to_int(split(duration, ':')[0]) * 60000 + to_int(split(split(duration, ':')[1], '.')[0]) * 1000 + to_int(rpad(split(split(duration, ':')[1], '.')[1], 3, '0'))
# [row_scope]
SELECT (CAST(IF(LOCATE(':', target_table.duration) > 0, SUBSTRING_INDEX(target_table.duration, ':', 1), '0') AS SIGNED) * 60000 + CAST(SUBSTRING_INDEX(IF(LOCATE(':', target_table.duration) > 0, SUBSTRING_INDEX(target_table.duration, ':', -1), target_table.duration), '.', 1) AS SIGNED) * 1000 + CAST(RPAD(IF(LOCATE('.', IF(LOCATE(':', target_table.duration) > 0, SUBSTRING_INDEX(target_table.duration, ':', -1), target_table.duration)) > 0, SUBSTRING_INDEX(IF(LOCATE(':', target_table.duration) > 0, SUBSTRING_INDEX(target_table.duration, ':', -1), target_table.duration), '.', -1), '0'), 3, '0') AS SIGNED)) AS computed_value, target_table.milliseconds AS actual_value FROM pitStops AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_tmRebound.csv
# For each team-season (tmID, year): o_tmRebound = o_reb ? SUM_over_players_on_that_team_and_season(players_teams.rebounds).
# [across_tables], used_tables: ['players_teams']
SELECT (CAST(target_table.o_reb AS SIGNED) - COALESCE(CAST(pt.sum_player_reb AS SIGNED), 0)) AS computed_value, target_table.o_tmRebound AS actual_value FROM teams AS target_table LEFT JOIN (SELECT tmID, year, SUM(rebounds) AS sum_player_reb FROM players_teams GROUP BY tmID, year) AS pt ON pt.tmID = target_table.tmID AND pt.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_SoL.csv
# For each team-season (tmID, year), SoL equals the sum of all goalie shootout losses recorded in GoaliesShootout for that team and year: SoL(tmID, year) = SUM(GoaliesShootout.L WHERE GoaliesShootout.tmID = Teams.tmID AND GoaliesShootout.year = Teams.year).
# [across_tables], used_tables: ['GoaliesShootout']
SELECT gs.total_sol AS computed_value, target_table.SoL AS actual_value
FROM Teams AS target_table
LEFT JOIN (
  SELECT year, tmID, SUM(CAST(L AS SIGNED)) AS total_sol
  FROM GoaliesShootout
  GROUP BY year, tmID
) AS gs
  ON gs.year = target_table.year AND gs.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_h_score.csv
# h_score = CASE WHEN h_tid = win_tid THEN win_score ELSE lose_score END
# [row_scope]
SELECT CASE WHEN target_table.h_tid = target_table.win_tid THEN target_table.win_score ELSE target_table.lose_score END AS computed_value, target_table.h_score AS actual_value FROM matches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_lapTimes_milliseconds.csv
# milliseconds = minutes*60000 + seconds*1000 + millisPart, where minutes = integer before ':' in 'time', seconds = integer between ':' and '.' in 'time', millisPart = integer after '.' in 'time'
# [row_scope]
SELECT (CAST(SUBSTRING_INDEX(target_table.`time`, ':', 1) AS SIGNED) * 60000 + CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(target_table.`time`, '.', 1), ':', -1) AS SIGNED) * 1000 + CAST(SUBSTRING_INDEX(target_table.`time`, '.', -1) AS SIGNED)) AS computed_value, target_table.`milliseconds` AS actual_value FROM `lapTimes` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Dallas_officers_gender.csv
# For each officers row, join incidents by case_number; in incidents.officers, find the exact occurrence of officers.full_name, then extract the single-letter gender immediately after the '/' in the race/gender code that follows that name.
# [across_tables], used_tables: ['incidents']
SELECT
  CASE
    WHEN i.officers IS NOT NULL
         AND LOCATE(target_table.full_name, i.officers) > 0
         AND LOCATE('/', i.officers, LOCATE(target_table.full_name, i.officers)) > 0
    THEN SUBSTRING(
           i.officers,
           LOCATE('/', i.officers, LOCATE(target_table.full_name, i.officers)) + 1,
           1
         )
    ELSE NULL
  END AS computed_value,
  target_table.gender AS actual_value
FROM officers AS target_table
LEFT JOIN incidents AS i
  ON i.case_number = target_table.case_number;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Invoice_BillingCountry.csv
# Group rows by CustomerId. Within each group, order by (InvoiceDate, InvoiceId). For current_row, set BillingCountry = previous_row.BillingCountry; if previous_row does not exist (current_row is the first in its CustomerId chain), set BillingCountry = next_row.BillingCountry.
# [chaining_table], grouping_columns(['CustomerId']), chaining_columns(['InvoiceDate', 'InvoiceId'])
SELECT
  COALESCE(
    (
      SELECT p.BillingCountry
      FROM Invoice AS p
      WHERE p.CustomerId = target_table.CustomerId
        AND (
          p.InvoiceDate < target_table.InvoiceDate
          OR (p.InvoiceDate = target_table.InvoiceDate AND p.InvoiceId < target_table.InvoiceId)
        )
      ORDER BY p.InvoiceDate DESC, p.InvoiceId DESC
      LIMIT 1
    ),
    (
      SELECT n.BillingCountry
      FROM Invoice AS n
      WHERE n.CustomerId = target_table.CustomerId
        AND (
          n.InvoiceDate > target_table.InvoiceDate
          OR (n.InvoiceDate = target_table.InvoiceDate AND n.InvoiceId > target_table.InvoiceId)
        )
      ORDER BY n.InvoiceDate ASC, n.InvoiceId ASC
      LIMIT 1
    )
  ) AS computed_value,
  target_table.BillingCountry AS actual_value
FROM Invoice AS target_table
WHERE
  EXISTS (
    SELECT 1
    FROM Invoice AS p
    WHERE p.CustomerId = target_table.CustomerId
      AND (
        p.InvoiceDate < target_table.InvoiceDate
        OR (p.InvoiceDate = target_table.InvoiceDate AND p.InvoiceId < target_table.InvoiceId)
      )
    LIMIT 1
  )
  OR EXISTS (
    SELECT 1
    FROM Invoice AS n
    WHERE n.CustomerId = target_table.CustomerId
      AND (
        n.InvoiceDate > target_table.InvoiceDate
        OR (n.InvoiceDate = target_table.InvoiceDate AND n.InvoiceId > target_table.InvoiceId)
      )
    LIMIT 1
  );
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Invoice_BillingCountry.csv
# For each invoice i, BillingCountry = the Country of the customer referenced by i.CustomerId (i.e., join Invoice.CustomerId = Customer.CustomerId and take Customer.Country).
# [across_tables], used_tables: ['Customer']
SELECT c.Country AS computed_value, target_table.BillingCountry AS actual_value FROM Invoice AS target_table INNER JOIN Customer AS c ON c.CustomerId = target_table.CustomerId;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_reb.csv
# For each team-season, o_reb = (sum of players_teams.rebounds for all rows with the same (tmID, year)) + teams.o_tmRebound.
# [across_tables], used_tables: ['players_teams']
SELECT
  CAST(COALESCE(plr_reb.total_reb, 0) AS SIGNED) + CAST(COALESCE(target_table.o_tmRebound, 0) AS SIGNED) AS computed_value,
  target_table.o_reb AS actual_value
FROM teams AS target_table
LEFT JOIN (
  SELECT tmID, year, SUM(COALESCE(rebounds, 0)) AS total_reb
  FROM players_teams
  GROUP BY tmID, year
) AS plr_reb
  ON plr_reb.tmID = target_table.tmID
 AND plr_reb.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Coaches_postl.csv
# postl = postg - postw - postt
# [row_scope]
SELECT (CAST(target_table.postg AS SIGNED) - CAST(target_table.postw AS SIGNED) - CAST(target_table.postt AS SIGNED)) AS computed_value, target_table.postl AS actual_value FROM Coaches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_PostfgMade.csv
# PostfgMade = (PostPoints - PostftMade - PostthreeMade) / 2
# [row_scope]
SELECT (CAST(target_table.PostPoints AS SIGNED) - CAST(target_table.PostftMade AS SIGNED) - CAST(target_table.PostthreeMade AS SIGNED)) / 2 AS computed_value, target_table.PostfgMade AS actual_value FROM players_teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_pitStops_lap.csv
# For each (raceId, driverId), anchor on the earliest pit stop in that race for that driver: let T0 be the earliest pit stop time and L0 its recorded lap (if null, use 1). From results, compute the driver?s average lap duration as avg_lap_sec = (milliseconds / 1000) / laps. Then for any pit stop at time Ts for that driver and race, the lap is L0 + floor((Ts - T0) / avg_lap_sec). If avg_lap_sec is null, the computed value is null.
# [across_tables], used_tables: ['races', 'results']
SELECT
  CASE
    WHEN res.avg_lap_sec IS NULL THEN NULL
    ELSE CAST(COALESCE(anch.min_lap, 1) + FLOOR( (TIME_TO_SEC(target_table.time) - TIME_TO_SEC(anch.min_time)) / res.avg_lap_sec ) AS SIGNED)
  END AS computed_value,
  target_table.lap AS actual_value
FROM pitStops AS target_table
LEFT JOIN (
  SELECT p1.raceId, p1.driverId, p1.time AS min_time, p1.lap AS min_lap
  FROM pitStops p1
  INNER JOIN (
    SELECT raceId, driverId, MIN(time) AS min_time
    FROM pitStops
    GROUP BY raceId, driverId
  ) m ON m.raceId = p1.raceId AND m.driverId = p1.driverId AND m.min_time = p1.time
) AS anch
  ON anch.raceId = target_table.raceId AND anch.driverId = target_table.driverId
LEFT JOIN (
  SELECT r.raceId, r.driverId,
         (r.milliseconds / 1000.0) / NULLIF(r.laps, 0) AS avg_lap_sec
  FROM results r
) AS res
  ON res.raceId = target_table.raceId AND res.driverId = target_table.driverId;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Invoice_BillingAddress.csv
# For each Invoice row, set BillingAddress equal to Customer.Address where Customer.CustomerId = Invoice.CustomerId.
# [across_tables], used_tables: ['Customer']
SELECT c.Address AS computed_value, target_table.BillingAddress AS actual_value FROM Invoice AS target_table JOIN Customer AS c ON c.CustomerId = target_table.CustomerId;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Invoice_BillingAddress.csv
# For each Invoice row, set BillingAddress to COALESCE(Customer.Address, the most frequent non-null Invoice.BillingAddress observed for the same CustomerId across all invoices; if multiple addresses tie for most frequent, choose the lexicographically smallest).
# [across_tables], used_tables: ['Customer']
SELECT COALESCE(c.Address, mode_per_customer.mode_address) AS computed_value, target_table.BillingAddress AS actual_value FROM Invoice AS target_table LEFT JOIN Customer AS c ON c.CustomerId = target_table.CustomerId LEFT JOIN ( SELECT t1.CustomerId, MIN(t1.BillingAddress) AS mode_address FROM ( SELECT CustomerId, BillingAddress, COUNT(*) AS cnt FROM Invoice WHERE BillingAddress IS NOT NULL GROUP BY CustomerId, BillingAddress ) AS t1 JOIN ( SELECT CustomerId, MAX(cnt) AS max_cnt FROM ( SELECT CustomerId, BillingAddress, COUNT(*) AS cnt FROM Invoice WHERE BillingAddress IS NOT NULL GROUP BY CustomerId, BillingAddress ) AS t2 GROUP BY CustomerId ) AS tmax ON t1.CustomerId = tmax.CustomerId AND t1.cnt = tmax.max_cnt GROUP BY t1.CustomerId ) AS mode_per_customer ON mode_per_customer.CustomerId = target_table.CustomerId;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Invoice_BillingAddress.csv
# Fallback formula using Employee when Customer.Address is missing: BillingAddress = COALESCE(Customer.Address, Employee.Address) where Employee.EmployeeId = Customer.SupportRepId and Customer.CustomerId = Invoice.CustomerId.
# [across_tables], used_tables: ['Customer', 'Employee']
SELECT COALESCE(c.Address, e.Address) AS computed_value, target_table.BillingAddress AS actual_value
FROM Invoice AS target_table
LEFT JOIN Customer AS c ON c.CustomerId = target_table.CustomerId
LEFT JOIN Employee AS e ON e.EmployeeId = c.SupportRepId;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_PostRebounds.csv
# PostRebounds = PostoRebounds + PostdRebounds
# [row_scope]
SELECT CAST(target_table.PostoRebounds AS SIGNED) + CAST(target_table.PostdRebounds AS SIGNED) AS computed_value, target_table.PostRebounds AS actual_value FROM players_teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_player_allstar_league_id.csv
# nan
# [count_or_exist with data sharing], given_table_name = players_teams
SELECT
  CASE
    WHEN pts.aba_cnt > pts.nba_cnt THEN 'ABA'
    WHEN pts.nba_cnt > pts.aba_cnt THEN 'NBA'
    WHEN (IFNULL(pts.aba_cnt, 0) = IFNULL(pts.nba_cnt, 0)) THEN
      CASE
        WHEN IFNULL(t.aba_team_cnt, 0) > 0 AND IFNULL(t.nba_team_cnt, 0) = 0 THEN 'ABA'
        ELSE 'NBA'
      END
    ELSE 'NBA'
  END AS computed_value,
  target_table.league_id AS actual_value
FROM player_allstar AS target_table
LEFT JOIN (
  SELECT pt.playerID, pt.year,
         COUNT(CASE WHEN pt.lgID LIKE 'ABA' THEN 1 END) AS aba_cnt,
         COUNT(CASE WHEN pt.lgID LIKE 'NBA' THEN 1 END) AS nba_cnt
  FROM players_teams pt
  GROUP BY pt.playerID, pt.year
) AS pts
  ON pts.playerID = target_table.playerID AND pts.year = target_table.season_id
LEFT JOIN (
  SELECT t.year,
         COUNT(CASE WHEN t.lgID LIKE 'ABA' THEN 1 END) AS aba_team_cnt,
         COUNT(CASE WHEN t.lgID LIKE 'NBA' THEN 1 END) AS nba_team_cnt
  FROM teams t
  GROUP BY t.year
) AS t
  ON t.year = target_table.season_id;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_Score.csv
# nan
# [count_or_exist with data sharing], given_table_name = votes
SELECT
  COALESCE(up.cnt_up, 0) - COALESCE(down.cnt_down, 0) AS computed_value,
  target_table.Score AS actual_value
FROM posts AS target_table
LEFT JOIN (
  SELECT PostId, COUNT(*) AS cnt_up
  FROM votes
  WHERE VoteTypeId = 2
  GROUP BY PostId
) AS up ON up.PostId = target_table.Id
LEFT JOIN (
  SELECT PostId, COUNT(*) AS cnt_down
  FROM votes
  WHERE VoteTypeId = 3
  GROUP BY PostId
) AS down ON down.PostId = target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_results_rank.csv
# rank = 1 + count_of_rows r2 in results where (r2.raceId = raceId) AND (r2.fastestLapTime IS NOT NULL) AND (r2.fastestLapTime < fastestLapTime); if fastestLapTime IS NULL then rank = NULL
# [row_scope]
SELECT
  CASE
    WHEN target_table.fastestLapTime IS NULL THEN NULL
    ELSE RANK() OVER (
      PARTITION BY target_table.raceId
      ORDER BY
        CASE WHEN target_table.fastestLapTime IS NULL THEN 1 ELSE 0 END,
        (
          CAST(SUBSTRING_INDEX(target_table.fastestLapTime, ':', 1) AS SIGNED) * 60000
          + CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(target_table.fastestLapTime, ':', -1), '.', 1) AS SIGNED) * 1000
          + CAST(SUBSTRING_INDEX(target_table.fastestLapTime, '.', -1) AS SIGNED)
        ) ASC
    )
  END AS computed_value,
  target_table.rank AS actual_value
FROM results AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Customer_State.csv
# For each customer, set State to the most frequent non-null Invoice.BillingState observed in that customer?s invoices. If multiple states tie on frequency, choose the one whose associated invoices have the most recent InvoiceDate; if still tied, pick the lexicographically smallest BillingState. If the customer has no invoices with a non-null BillingState, fall back to the city+country level: among all invoices with the same BillingCity and BillingCountry as the customer?s City and Country, choose the most frequent non-null BillingState; break ties by most recent InvoiceDate, then by lexicographically smallest BillingState. If still unavailable, return NULL.
# [across_tables], used_tables: ['Invoice']
SELECT COALESCE(cust_mode.BillingState, city_mode.BillingState) AS computed_value, target_table.State AS actual_value FROM Customer target_table LEFT JOIN ( SELECT s.CustomerId, s.BillingState FROM ( SELECT b.CustomerId, MIN(b.BillingState) AS BillingState FROM ( SELECT c.CustomerId, c.BillingState, c.latest_date FROM ( SELECT i.CustomerId, i.BillingState, COUNT(*) AS cnt, MAX(i.InvoiceDate) AS latest_date FROM Invoice i WHERE i.BillingState IS NOT NULL GROUP BY i.CustomerId, i.BillingState ) c JOIN ( SELECT t.CustomerId, MAX(t.cnt) AS max_cnt FROM ( SELECT i.CustomerId, i.BillingState, COUNT(*) AS cnt FROM Invoice i WHERE i.BillingState IS NOT NULL GROUP BY i.CustomerId, i.BillingState ) t GROUP BY t.CustomerId ) mx ON c.CustomerId = mx.CustomerId AND c.cnt = mx.max_cnt JOIN ( SELECT bc.CustomerId, MAX(bc.latest_date) AS max_date FROM ( SELECT c2.CustomerId, c2.BillingState, c2.cnt, c2.latest_date FROM ( SELECT i.CustomerId, i.BillingState, COUNT(*) AS cnt, MAX(i.InvoiceDate) AS latest_date FROM Invoice i WHERE i.BillingState IS NOT NULL GROUP BY i.CustomerId, i.BillingState ) c2 JOIN ( SELECT t2.CustomerId, MAX(t2.cnt) AS max_cnt FROM ( SELECT i.CustomerId, i.BillingState, COUNT(*) AS cnt FROM Invoice i WHERE i.BillingState IS NOT NULL GROUP BY i.CustomerId, i.BillingState ) t2 GROUP BY t2.CustomerId ) mx2 ON c2.CustomerId = mx2.CustomerId AND c2.cnt = mx2.max_cnt ) bc GROUP BY bc.CustomerId ) md ON c.CustomerId = md.CustomerId AND c.latest_date = md.max_date ) b GROUP BY b.CustomerId ) s ) AS cust_mode ON target_table.CustomerId = cust_mode.CustomerId LEFT JOIN ( SELECT s.BillingCity, s.BillingCountry, s.BillingState FROM ( SELECT d.BillingCity, d.BillingCountry, MIN(d.BillingState) AS BillingState FROM ( SELECT c.BillingCity, c.BillingCountry, c.BillingState, c.latest_date FROM ( SELECT i.BillingCity, i.BillingCountry, i.BillingState, COUNT(*) AS cnt, MAX(i.InvoiceDate) AS latest_date FROM Invoice i WHERE i.BillingState IS NOT NULL GROUP BY i.BillingCity, i.BillingCountry, i.BillingState ) c JOIN ( SELECT t.BillingCity, t.BillingCountry, MAX(t.cnt) AS max_cnt FROM ( SELECT i.BillingCity, i.BillingCountry, i.BillingState, COUNT(*) AS cnt FROM Invoice i WHERE i.BillingState IS NOT NULL GROUP BY i.BillingCity, i.BillingCountry, i.BillingState ) t GROUP BY t.BillingCity, t.BillingCountry ) mx ON c.BillingCity = mx.BillingCity AND c.BillingCountry = mx.BillingCountry AND c.cnt = mx.max_cnt JOIN ( SELECT bc.BillingCity, bc.BillingCountry, MAX(bc.latest_date) AS max_date FROM ( SELECT c2.BillingCity, c2.BillingCountry, c2.BillingState, c2.cnt, c2.latest_date FROM ( SELECT i.BillingCity, i.BillingCountry, i.BillingState, COUNT(*) AS cnt, MAX(i.InvoiceDate) AS latest_date FROM Invoice i WHERE i.BillingState IS NOT NULL GROUP BY i.BillingCity, i.BillingCountry, i.BillingState ) c2 JOIN ( SELECT t2.BillingCity, t2.BillingCountry, MAX(t2.cnt) AS max_cnt FROM ( SELECT i.BillingCity, i.BillingCountry, i.BillingState, COUNT(*) AS cnt FROM Invoice i WHERE i.BillingState IS NOT NULL GROUP BY i.BillingCity, i.BillingCountry, i.BillingState ) t2 GROUP BY t2.BillingCity, t2.BillingCountry ) mx2 ON c2.BillingCity = mx2.BillingCity AND c2.BillingCountry = mx2.BillingCountry AND c2.cnt = mx2.max_cnt ) bc GROUP BY bc.BillingCity, bc.BillingCountry ) md ON c.BillingCity = md.BillingCity AND c.BillingCountry = md.BillingCountry AND c.latest_date = md.max_date ) d GROUP BY d.BillingCity, d.BillingCountry ) s ) AS city_mode ON target_table.City = city_mode.BillingCity AND target_table.Country = city_mode.BillingCountry;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Customer_State.csv
# For each customer, set State to the BillingState from that customer?s most recent invoice (by InvoiceDate). If the most recent invoice?s BillingState is NULL or the customer has no such invoices, fall back to the most recent invoice (by InvoiceDate) among all invoices whose BillingCity and BillingCountry match the customer?s City and Country; use its BillingState. If still unavailable, return NULL. When multiple invoices share the same latest date in either step, choose the lexicographically smallest BillingState among those.
# [across_tables], used_tables: ['Invoice']
SELECT COALESCE(cust_latest.BillingState, city_latest.BillingState) AS computed_value, target_table.State AS actual_value FROM Customer target_table LEFT JOIN ( SELECT i.CustomerId, MIN(i.BillingState) AS BillingState FROM Invoice i JOIN ( SELECT CustomerId, MAX(InvoiceDate) AS max_date FROM Invoice WHERE BillingState IS NOT NULL GROUP BY CustomerId ) last_i ON i.CustomerId = last_i.CustomerId AND i.InvoiceDate = last_i.max_date WHERE i.BillingState IS NOT NULL GROUP BY i.CustomerId ) AS cust_latest ON target_table.CustomerId = cust_latest.CustomerId LEFT JOIN ( SELECT i.BillingCity, i.BillingCountry, MIN(i.BillingState) AS BillingState FROM Invoice i JOIN ( SELECT BillingCity, BillingCountry, MAX(InvoiceDate) AS max_date FROM Invoice WHERE BillingState IS NOT NULL GROUP BY BillingCity, BillingCountry ) last_c ON i.BillingCity = last_c.BillingCity AND i.BillingCountry = last_c.BillingCountry AND i.InvoiceDate = last_c.max_date WHERE i.BillingState IS NOT NULL GROUP BY i.BillingCity, i.BillingCountry ) AS city_latest ON target_table.City = city_latest.BillingCity AND target_table.Country = city_latest.BillingCountry;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsHalf_T.csv
# T = G - W - L
# [row_scope]
SELECT (CAST(`target_table`.`G` AS SIGNED) - CAST(`target_table`.`W` AS SIGNED) - CAST(`target_table`.`L` AS SIGNED)) AS computed_value, `target_table`.`T` AS actual_value FROM `TeamsHalf` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsHalf_T.csv
# For each TeamsHalf row (year, lgID, tmID, half), compute ties in that half by proportionally allocating the team?s season ties from Teams to the half by its share of games: T_half = Teams.T * (TeamsHalf.G / Teams.G).
# [across_tables], used_tables: ['Teams', 'TeamVsTeam']
SELECT
  (CAST(season_totals.T AS SIGNED) * CAST(target_table.G AS SIGNED)) / NULLIF(CAST(season_totals.G AS SIGNED), 0) AS computed_value,
  target_table.T AS actual_value
FROM TeamsHalf AS target_table
LEFT JOIN Teams AS season_totals
  ON season_totals.year = target_table.year
 AND season_totals.lgID = target_table.lgID
 AND season_totals.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_win_tid.csv
# win_tid = CASE WHEN lose_tid = tid1 THEN tid2 ELSE tid1 END
# [row_scope]
SELECT CASE WHEN target_table.`lose_tid` = target_table.`tid1` THEN target_table.`tid2` ELSE target_table.`tid1` END AS `computed_value`, target_table.`win_tid` AS `actual_value` FROM `matches` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Dallas_officers_first_name.csv
# first_name = SPLIT_PART(full_name, ', ', 2)
# [row_scope]
SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(target_table.full_name, ', ', 2), ', ', -1) AS computed_value, target_table.first_name AS actual_value FROM officers AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_ScoringSC_Pts.csv
# Pts = G + A
# [row_scope]
SELECT CAST(`target_table`.`G` AS SIGNED) + CAST(`target_table`.`A` AS SIGNED) AS `computed_value`, `target_table`.`Pts` AS `actual_value` FROM `ScoringSC` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_AwardsPlayers_lgID.csv
# For each AwardsPlayers row (playerID, year): 1) If other AwardsPlayers rows for the same (playerID, year) yield a unique league (only NHL or only WHA among non-null lgID), use that league. If both NHL and WHA appear in the same (playerID, year), leave unresolved here. 2) If unresolved, use Master intervals: if the year lies in WHA interval (firstWHA..lastWHA inclusive) then 'WHA'; else if in NHL interval (firstNHL..lastNHL inclusive) then 'NHL'. 3) If still unresolved, and the player has a ScoringSC row in that year with lgID = 'NHL', set lgID = 'NHL'; else NULL.
# [across_tables], used_tables: ['ScoringSC']
SELECT
  CASE
    WHEN ap_unique.unique_lg IS NOT NULL THEN ap_unique.unique_lg
    WHEN m.firstWHA IS NOT NULL
         AND CAST(m.firstWHA AS UNSIGNED) <= target_table.year
         AND (m.lastWHA IS NULL OR CAST(m.lastWHA AS UNSIGNED) >= target_table.year) THEN 'WHA'
    WHEN m.firstNHL IS NOT NULL
         AND CAST(m.firstNHL AS UNSIGNED) <= target_table.year
         AND (m.lastNHL IS NULL OR CAST(m.lastNHL AS UNSIGNED) >= target_table.year) THEN 'NHL'
    WHEN ssc_nhl.has_nhl = 1 THEN 'NHL'
    ELSE NULL
  END AS computed_value,
  target_table.lgID AS actual_value
FROM AwardsPlayers AS target_table
LEFT JOIN (
  SELECT playerID, year,
         CASE
           WHEN SUM(lgID = 'WHA') > 0 AND SUM(lgID = 'NHL') = 0 THEN 'WHA'
           WHEN SUM(lgID = 'NHL') > 0 AND SUM(lgID = 'WHA') = 0 THEN 'NHL'
           ELSE NULL
         END AS unique_lg
  FROM AwardsPlayers
  WHERE lgID IS NOT NULL
  GROUP BY playerID, year
) AS ap_unique
  ON ap_unique.playerID = target_table.playerID
 AND ap_unique.year = target_table.year
LEFT JOIN Master AS m
  ON m.playerID = target_table.playerID
LEFT JOIN (
  SELECT playerID, year, 1 AS has_nhl
  FROM ScoringSC
  WHERE lgID = 'NHL'
  GROUP BY playerID, year
) AS ssc_nhl
  ON ssc_nhl.playerID = target_table.playerID
 AND ssc_nhl.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_AwardsPlayers_lgID.csv
# If award is an All-Star selection (award IN {'First Team All-Star','Second Team All-Star'}), then set lgID = 'WHA' when the award year falls within the players WHA tenure [Master.firstWHA..Master.lastWHA] (inclusive); otherwise set lgID = 'NHL'. For all other award types, set lgID = 'NHL'. Year bounds are compared to Master.firstWHA and Master.lastWHA parsed as integers (ignoring empty values).
# [across_tables], used_tables: ['Master']
SELECT
  CASE
    WHEN target_table.award IN ('First Team All-Star','Second Team All-Star') AND (
         (
           CAST(NULLIF(m.firstWHA,'') AS UNSIGNED) IS NOT NULL AND
           CAST(NULLIF(m.lastWHA,'') AS UNSIGNED) IS NOT NULL AND
           target_table.year BETWEEN CAST(NULLIF(m.firstWHA,'') AS UNSIGNED) AND CAST(NULLIF(m.lastWHA,'') AS UNSIGNED)
         ) OR (
           CAST(NULLIF(m.firstWHA,'') AS UNSIGNED) IS NOT NULL AND
           CAST(NULLIF(m.lastWHA,'') AS UNSIGNED) IS NULL AND
           target_table.year >= CAST(NULLIF(m.firstWHA,'') AS UNSIGNED)
         ) OR (
           CAST(NULLIF(m.firstWHA,'') AS UNSIGNED) IS NULL AND
           CAST(NULLIF(m.lastWHA,'') AS UNSIGNED) IS NOT NULL AND
           target_table.year <= CAST(NULLIF(m.lastWHA,'') AS UNSIGNED)
         )
       ) THEN 'WHA'
    ELSE 'NHL'
  END AS computed_value,
  target_table.lgID AS actual_value
FROM AwardsPlayers AS target_table
LEFT JOIN Master AS m ON m.playerID = target_table.playerID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_G.csv
# G = W + L + T + OTL (treat missing/null values as 0)
# [row_scope]
SELECT COALESCE(CONVERT(target_table.W, SIGNED), 0) + COALESCE(CONVERT(target_table.L, SIGNED), 0) + COALESCE(CONVERT(target_table.T, SIGNED), 0) + COALESCE(CONVERT(target_table.OTL, SIGNED), 0) AS computed_value, target_table.G AS actual_value FROM Teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_DecL.csv
# DecL = (hL + rL) - (COALESCE(SepL, 0) + COALESCE(OctL, 0) + COALESCE(NovL, 0) + COALESCE(JanL, 0) + COALESCE(FebL, 0) + COALESCE(MarL, 0) + COALESCE(AprL, 0))
# [row_scope]
SELECT (CAST(COALESCE(target_table.hL, 0) AS SIGNED) + CAST(COALESCE(target_table.rL, 0) AS SIGNED) - (CAST(COALESCE(target_table.SepL, 0) AS SIGNED) + CAST(COALESCE(target_table.OctL, 0) AS SIGNED) + CAST(COALESCE(target_table.NovL, 0) AS SIGNED) + CAST(COALESCE(target_table.JanL, 0) AS SIGNED) + CAST(COALESCE(target_table.FebL, 0) AS SIGNED) + CAST(COALESCE(target_table.MarL, 0) AS SIGNED) + CAST(COALESCE(target_table.AprL, 0) AS SIGNED))) AS computed_value, target_table.DecL AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Dallas_officers_full_name.csv
# full_name = CONCAT_WS(', ', last_name, first_name)
# [row_scope]
SELECT CONCAT_WS(', ', `target_table`.`last_name`, `target_table`.`first_name`) AS `computed_value`, `target_table`.`full_name` AS `actual_value` FROM `officers` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsSC_L.csv
# L = G - W - T
# [row_scope]
SELECT CAST(target_table.`G` AS SIGNED) - CAST(target_table.`W` AS SIGNED) - CAST(target_table.`T` AS SIGNED) AS computed_value, target_table.`L` AS actual_value FROM `TeamsSC` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_awayLost.csv
# awayLost = lost - homeLost - neutLoss
# [row_scope]
SELECT (CAST(`target_table`.`lost` AS SIGNED) - CAST(`target_table`.`homeLost` AS SIGNED) - CAST(`target_table`.`neutLoss` AS SIGNED)) AS `computed_value`, `target_table`.`awayLost` AS `actual_value` FROM `teams` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_match_stats_HB.csv
# HB = DI - KI
# [row_scope]
SELECT CAST(`target_table`.`DI` AS SIGNED) - CAST(`target_table`.`KI` AS SIGNED) AS computed_value, `target_table`.`HB` AS actual_value FROM `match_stats` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_match_stats_HB.csv
# For each (mid, pid), HB = (CP + UP) ? KI; join to players on pid to align rows across tables.
# [across_tables], used_tables: ['players']
SELECT (CAST(target_table.CP AS SIGNED) + CAST(target_table.UP AS SIGNED) - CAST(target_table.KI AS SIGNED)) AS computed_value, target_table.HB AS actual_value FROM match_stats AS target_table INNER JOIN players AS p ON p.pid = target_table.pid;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_CommentCount.csv
# nan
# [count_or_exist with data sharing], given_table_name = comments
SELECT COUNT(c.Id) AS computed_value, target_table.CommentCount AS actual_value FROM posts AS target_table LEFT JOIN comments AS c ON c.PostId = target_table.Id GROUP BY target_table.Id, target_table.CommentCount;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderHeader_TotalDue.csv
# TotalDue = SubTotal + TaxAmt + Freight
# [row_scope]
SELECT (target_table.SubTotal + target_table.TaxAmt + target_table.Freight) AS computed_value, target_table.TotalDue AS actual_value FROM PurchaseOrderHeader AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Employee_Title.csv
# Derive Title from the sales-support hierarchy by counting customers across reporting levels using Employee and Customer: 1) If an employee has at least one directly assigned Customer (Customer.SupportRepId = Employee.EmployeeId), then Title = 'Sales Support Agent'. 2) Else, if none are directly assigned but at least one direct subordinate has assigned customers, then Title = 'Sales Manager'. 3) Else, if no direct subordinate has assigned customers but at least one second-level subordinate (a subordinate?s subordinate) has assigned customers, then Title = 'General Manager'. 4) Else, if the employee has at least one direct subordinate (regardless of customers), then Title = 'IT Manager'. 5) Else, Title = 'IT Staff'.
# [across_tables], used_tables: ['Customer', 'Invoice']
SELECT CASE WHEN COALESCE(c0.c0, 0) > 0 THEN 'Sales Support Agent' WHEN COALESCE(c1.c1, 0) > 0 THEN 'Sales Manager' WHEN COALESCE(c2.c2, 0) > 0 THEN 'General Manager' WHEN COALESCE(subc.sub_count, 0) > 0 THEN 'IT Manager' ELSE 'IT Staff' END AS computed_value, target_table.Title AS actual_value FROM Employee AS target_table LEFT JOIN ( SELECT c.SupportRepId AS EmployeeId, COUNT(*) AS c0 FROM Customer c WHERE c.SupportRepId IS NOT NULL GROUP BY c.SupportRepId ) AS c0 ON c0.EmployeeId = target_table.EmployeeId LEFT JOIN ( SELECT e.ReportsTo AS EmployeeId, SUM(COALESCE(c0a.c0, 0)) AS c1 FROM Employee e LEFT JOIN ( SELECT c.SupportRepId AS EmployeeId, COUNT(*) AS c0 FROM Customer c WHERE c.SupportRepId IS NOT NULL GROUP BY c.SupportRepId ) AS c0a ON c0a.EmployeeId = e.EmployeeId WHERE e.ReportsTo IS NOT NULL GROUP BY e.ReportsTo ) AS c1 ON c1.EmployeeId = target_table.EmployeeId LEFT JOIN ( SELECT s.ReportsTo AS EmployeeId, SUM(COALESCE(c0b.c0, 0)) AS c2 FROM Employee s JOIN Employee t ON t.ReportsTo = s.EmployeeId LEFT JOIN ( SELECT c.SupportRepId AS EmployeeId, COUNT(*) AS c0 FROM Customer c WHERE c.SupportRepId IS NOT NULL GROUP BY c.SupportRepId ) AS c0b ON c0b.EmployeeId = t.EmployeeId WHERE s.ReportsTo IS NOT NULL GROUP BY s.ReportsTo ) AS c2 ON c2.EmployeeId = target_table.EmployeeId LEFT JOIN ( SELECT e.ReportsTo AS EmployeeId, COUNT(*) AS sub_count FROM Employee e WHERE e.ReportsTo IS NOT NULL GROUP BY e.ReportsTo ) AS subc ON subc.EmployeeId = target_table.EmployeeId;
###########################################################

###########################################################
# filtered_reported_accuracy_Dallas_officers_race.csv
# For each officer row, join incidents on case_number and parse the incidents.officers text to find the substring immediately following the officer's full_name plus a space; the single character before the next '/' (i.e., the 'X' in 'X/G') is the officer's race.
# [across_tables], used_tables: ['incidents']
SELECT CASE WHEN i.officers IS NULL THEN NULL WHEN LOCATE(CONCAT(target_table.full_name, ' '), i.officers) = 0 THEN NULL ELSE LEFT(SUBSTRING_INDEX(SUBSTRING(i.officers, LOCATE(CONCAT(target_table.full_name, ' '), i.officers) + LENGTH(target_table.full_name) + 1), '/', 1), 1) END AS computed_value, target_table.race AS actual_value FROM officers AS target_table LEFT JOIN incidents AS i ON i.case_number = target_table.case_number;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_DueDate.csv
# DueDate = DATEADD(day, 5, CAST(ShipDate AS date))
# [row_scope]
SELECT DATE_ADD(DATE(target_table.`ShipDate`), INTERVAL 5 DAY) AS `computed_value`, target_table.`DueDate` AS `actual_value` FROM `SalesOrderHeader` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_rW.csv
# rW = COALESCE(Teams.W, 0) - COALESCE(TeamSplits.hW, 0) joined on (year, lgID, tmID)
# [across_tables], used_tables: ['Teams']
SELECT CAST(COALESCE(t.W, 0) AS SIGNED) - CAST(COALESCE(target_table.hW, 0) AS SIGNED) AS computed_value, target_table.rW AS actual_value FROM TeamSplits AS target_table JOIN Teams AS t ON t.year = target_table.year AND t.lgID = target_table.lgID AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_postHistory_PostHistoryTypeId.csv
# For a postHistory row ph joined to its post p: (a) if ph.CreationDate equals p.ClosedDate then PostHistoryTypeId = 10 (closed); (b) if ph.CreationDate equals p.CommunityOwnedDate then PostHistoryTypeId = 16 (community owned); (c) if ph.Text equals p.Title, set PostHistoryTypeId = 1 when ph.CreationDate = p.CreaionDate else 4; (d) if ph.Text equals p.Body, set PostHistoryTypeId = 2 when ph.CreationDate = p.CreaionDate else 5; (e) if ph.Text equals p.Tags, set PostHistoryTypeId = 3 when ph.CreationDate = p.CreaionDate else 6. This derives initial vs edit snapshots by comparing the postHistory.Text snapshot to the current fields on posts and uses post timestamps for distinguishing initial from edits, plus post-level state changes (closed, community-owned).
# [across_tables], used_tables: ['posts', 'tags']
SELECT
  CASE
    WHEN p.Id IS NOT NULL AND target_table.CreationDate = p.ClosedDate THEN 10
    WHEN p.Id IS NOT NULL AND target_table.CreationDate = p.CommunityOwnedDate THEN 16
    WHEN p.Id IS NOT NULL AND target_table.Text IS NOT NULL AND p.Title IS NOT NULL AND target_table.Text = p.Title AND target_table.CreationDate = p.CreaionDate THEN 1
    WHEN p.Id IS NOT NULL AND target_table.Text IS NOT NULL AND p.Body IS NOT NULL AND target_table.Text = p.Body AND target_table.CreationDate = p.CreaionDate THEN 2
    WHEN p.Id IS NOT NULL AND target_table.Text IS NOT NULL AND p.Tags IS NOT NULL AND target_table.Text = p.Tags AND target_table.CreationDate = p.CreaionDate THEN 3
    WHEN p.Id IS NOT NULL AND target_table.Text IS NOT NULL AND p.Title IS NOT NULL AND target_table.Text = p.Title AND target_table.CreationDate <> p.CreaionDate THEN 4
    WHEN p.Id IS NOT NULL AND target_table.Text IS NOT NULL AND p.Body IS NOT NULL AND target_table.Text = p.Body AND target_table.CreationDate <> p.CreaionDate THEN 5
    WHEN p.Id IS NOT NULL AND target_table.Text IS NOT NULL AND p.Tags IS NOT NULL AND target_table.Text = p.Tags AND target_table.CreationDate <> p.CreaionDate THEN 6
    ELSE NULL
  END AS computed_value,
  target_table.PostHistoryTypeId AS actual_value
FROM postHistory AS target_table
LEFT JOIN posts p ON p.Id = target_table.PostId;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_postHistory_PostHistoryTypeId.csv
# For a postHistory row ph joined to its post p: (a) if ph.CreationDate equals p.ClosedDate then PostHistoryTypeId = 10 (closed); (b) if ph.CreationDate equals p.CommunityOwnedDate then PostHistoryTypeId = 16 (community owned); (c) if ph.CreationDate equals p.CreaionDate and p.PostTypeId = 2 then PostHistoryTypeId = 2 (initial body for answers); (d) if p.PostTypeId = 1 and p.AcceptedAnswerId is not null and ph.CreationDate equals p.LasActivityDate then PostHistoryTypeId = 21 (answer accepted on the question).
# [across_tables], used_tables: ['posts', 'tags']
SELECT
  CASE
    WHEN p.Id IS NOT NULL AND target_table.CreationDate = p.ClosedDate THEN 10
    WHEN p.Id IS NOT NULL AND target_table.CreationDate = p.CommunityOwnedDate THEN 16
    WHEN p.Id IS NOT NULL AND target_table.CreationDate = p.CreaionDate AND p.PostTypeId = 2 THEN 2
    WHEN p.Id IS NOT NULL AND p.PostTypeId = 1 AND p.AcceptedAnswerId IS NOT NULL AND target_table.CreationDate = p.LasActivityDate THEN 21
    ELSE NULL
  END AS computed_value,
  target_table.PostHistoryTypeId AS actual_value
FROM postHistory AS target_table
LEFT JOIN posts p ON p.Id = target_table.PostId;
###########################################################

###########################################################
# filtered_reported_accuracy_Elti_target_is_elti.csv
# nan
# [count_or_exist with data sharing], given_table_name = elti
SELECT CASE WHEN (COALESCE(COUNT(e1.name1), 0) + COALESCE(COUNT(e2.name1), 0)) > 0 THEN 1 ELSE 0 END AS computed_value, target_table.is_elti AS actual_value FROM target AS target_table LEFT JOIN elti AS e1 ON e1.name1 LIKE target_table.name1 AND e1.name2 LIKE target_table.name2 LEFT JOIN elti AS e2 ON e2.name1 LIKE target_table.name2 AND e2.name2 LIKE target_table.name1 GROUP BY target_table.name1, target_table.name2, target_table.is_elti;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_h_tid.csv
# h_tid = CASE WHEN tid1_loc = 'h' THEN tid1 ELSE tid2 END
# [row_scope]
SELECT CASE WHEN target_table.tid1_loc = 'h' THEN target_table.tid1 ELSE target_table.tid2 END AS computed_value, target_table.h_tid AS actual_value FROM matches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsHalf_W.csv
# W = G - L - T
# [row_scope]
SELECT CAST(target_table.G AS SIGNED) - CAST(target_table.L AS SIGNED) - CAST(target_table.T AS SIGNED) AS computed_value, target_table.W AS actual_value FROM TeamsHalf AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsHalf_W.csv
# Map halves to calendar-month splits in TeamSplits: if half = 1, sum December and January wins; if half = 2, sum February, March, and April wins. That is, W_half = (DecW + JanW) for half=1, and W_half = (FebW + MarW + AprW) for half=2.
# [across_tables], used_tables: ['TeamSplits']
SELECT
  CASE
    WHEN target_table.half = 1 THEN
      COALESCE(CAST(ts.DecW AS SIGNED), 0) + COALESCE(CAST(ts.JanW AS SIGNED), 0)
    WHEN target_table.half = 2 THEN
      COALESCE(CAST(ts.FebW AS SIGNED), 0) + COALESCE(CAST(ts.MarW AS SIGNED), 0) + COALESCE(CAST(ts.AprW AS SIGNED), 0)
    ELSE NULL
  END AS computed_value,
  target_table.W AS actual_value
FROM TeamsHalf AS target_table
LEFT JOIN TeamSplits AS ts
  ON ts.year = target_table.year AND ts.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Dunur_target_is_dunur.csv
# nan
# [count_or_exist with data sharing], given_table_name = dunur
SELECT CASE WHEN (COUNT(d1.name1) + COUNT(d2.name1)) > 0 THEN 1 ELSE 0 END AS computed_value, target_table.is_dunur AS actual_value FROM target AS target_table LEFT JOIN dunur AS d1 ON d1.name1 = target_table.name1 AND d1.name2 = target_table.name2 LEFT JOIN dunur AS d2 ON d2.name1 = target_table.name2 AND d2.name2 = target_table.name1 GROUP BY target_table.name1, target_table.name2, target_table.is_dunur;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_ScoringSC_G.csv
# G = Pts - A
# [row_scope]
SELECT CAST(`target_table`.`Pts` AS SIGNED) - CAST(`target_table`.`A` AS SIGNED) AS computed_value, `target_table`.`G` AS actual_value FROM `ScoringSC` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_coaches_lgID.csv
# For each coaches row, derive lgID by joining to teams on the same (tmID, year) and using teams.lgID.
# [across_tables], used_tables: ['players_teams']
SELECT t.lgID AS computed_value, target_table.lgID AS actual_value
FROM coaches AS target_table
JOIN teams AS t
  ON t.tmID = target_table.tmID
 AND t.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsHalf_GF.csv
# TeamsHalf.GF for a given team-year-half equals the season total goals from Teams (Teams.GF) minus the GF recorded in TeamsHalf for the other half of the same team-year. Formally: GF(year, tmID, lgID, half=h) = Teams.GF(year, tmID, lgID) - COALESCE(TeamsHalf.GF(year, tmID, lgID, half<>h), 0).
# [across_tables], used_tables: ['Scoring', 'Teams']
SELECT
  CAST(t.GF AS SIGNED) - COALESCE(CAST(other.GF AS SIGNED), 0) AS computed_value,
  target_table.GF AS actual_value
FROM TeamsHalf AS target_table
LEFT JOIN Teams AS t
  ON t.year = target_table.year
 AND t.tmID = target_table.tmID
 AND t.lgID = target_table.lgID
LEFT JOIN TeamsHalf AS other
  ON other.year = target_table.year
 AND other.tmID = target_table.tmID
 AND other.lgID = target_table.lgID
 AND other.half <> target_table.half;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_OrderDate.csv
# For each SalesOrderID, OrderDate equals the earliest (minimum) ModifiedDate among its SalesOrderDetail rows: OrderDate = MIN(SalesOrderDetail.ModifiedDate) grouped by SalesOrderID.
# [across_tables], used_tables: ['SalesOrderDetail']
SELECT d.min_detail_modified_date AS computed_value, target_table.OrderDate AS actual_value
FROM SalesOrderHeader AS target_table
LEFT JOIN (
    SELECT SalesOrderID, MIN(ModifiedDate) AS min_detail_modified_date
    FROM SalesOrderDetail
    GROUP BY SalesOrderID
) AS d ON d.SalesOrderID = target_table.SalesOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_OrderDate.csv
# OrderDate = DATEADD(hour, CASE WHEN MONTH(DATEADD(day, -7, ShipDate)) BETWEEN 4 AND 10 THEN 1 ELSE 2 END, CAST(DATEADD(day, -7, ShipDate) AS date))
# [row_scope]
SELECT
  DATE_ADD(
    CAST(DATE_SUB(target_table.`ShipDate`, INTERVAL 7 DAY) AS DATE),
    INTERVAL (CASE WHEN MONTH(DATE_SUB(target_table.`ShipDate`, INTERVAL 7 DAY)) BETWEEN 4 AND 10 THEN 1 ELSE 2 END) HOUR
  ) AS `computed_value`,
  target_table.`OrderDate` AS `actual_value`
FROM `SalesOrderHeader` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_SubTotal.csv
# SubTotal = TotalDue - TaxAmt - Freight
# [row_scope]
SELECT (CAST(`target_table`.`TotalDue` AS DECIMAL(38,10)) - CAST(`target_table`.`TaxAmt` AS DECIMAL(38,10)) - CAST(`target_table`.`Freight` AS DECIMAL(38,10))) AS computed_value, `target_table`.`SubTotal` AS actual_value FROM `SalesOrderHeader` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_SubTotal.csv
# if OnlineOrderFlag = 1 then SubTotal = (TotalDue - Freight) / (1 + 0.08)
# [row_scope]
SELECT CASE WHEN target_table.OnlineOrderFlag = 1 THEN (CAST(target_table.TotalDue AS DECIMAL(38,10)) - CAST(target_table.Freight AS DECIMAL(38,10))) / (CAST(1 AS DECIMAL(38,10)) + CAST(0.08 AS DECIMAL(38,10))) ELSE NULL END AS computed_value, target_table.SubTotal AS actual_value FROM SalesOrderHeader AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderHeader_Freight.csv
# Freight = TotalDue - SubTotal - TaxAmt
# [row_scope]
SELECT (CAST(target_table.TotalDue AS DECIMAL(65,30)) - CAST(target_table.SubTotal AS DECIMAL(65,30)) - CAST(target_table.TaxAmt AS DECIMAL(65,30))) AS computed_value, target_table.Freight AS actual_value FROM PurchaseOrderHeader AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderHeader_Freight.csv
# Freight = round(SubTotal * CASE WHEN ShipMethodID = 3 THEN 0.02 WHEN ShipMethodID IN (1, 4, 5) THEN 0.025 END, 4)
# [row_scope]
SELECT
  target_table.SubTotal * CASE
    WHEN target_table.ShipMethodID = 3 THEN 0.02
    WHEN target_table.ShipMethodID IN (1, 4, 5) THEN 0.025
  END AS computed_value,
  target_table.Freight AS actual_value
FROM PurchaseOrderHeader AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_d_pts.csv
# For each (year, lgID, tmID), d_pts(team) = [sum of points scored by all players in that league-season from players_teams] ? [sum of d_pts of every other team in the same league-season from teams]. In symbols: d_pts(y, l, t) = SUM_{p in players_teams where year=y and lgID=l}(points) ? SUM_{t' in teams where year=y and lgID=l and t'<>t}(d_pts).
# [across_tables], used_tables: ['players_teams', 'coaches']
SELECT 
  CAST(COALESCE(lp.league_player_pts, 0) AS SIGNED) - CAST(COALESCE(od.other_d_pts, 0) AS SIGNED) AS computed_value,
  target_table.d_pts AS actual_value
FROM teams AS target_table
LEFT JOIN (
  SELECT pt.year, pt.lgID, SUM(pt.points) AS league_player_pts
  FROM players_teams pt
  GROUP BY pt.year, pt.lgID
) AS lp
  ON lp.year = target_table.year AND lp.lgID = target_table.lgID
LEFT JOIN (
  SELECT t1.year, t1.lgID, t1.tmID, SUM(t2.d_pts) AS other_d_pts
  FROM teams t1
  JOIN teams t2
    ON t2.year = t1.year AND t2.lgID = t1.lgID AND t2.tmID <> t1.tmID
  GROUP BY t1.year, t1.lgID, t1.tmID
) AS od
  ON od.year = target_table.year AND od.lgID = target_table.lgID AND od.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_pf.csv
# For each team-season (tmID, year), o_pf equals the sum of all players? regular-season personal fouls (PF) from players_teams where players_teams.tmID = teams.tmID and players_teams.year = teams.year.
# [across_tables], used_tables: ['players_teams']
SELECT pt_sum_pf.sum_pf AS computed_value, target_table.o_pf AS actual_value FROM teams AS target_table LEFT JOIN ( SELECT tmID, year, SUM(CAST(PF AS SIGNED)) AS sum_pf FROM players_teams GROUP BY tmID, year ) AS pt_sum_pf ON pt_sum_pf.tmID = target_table.tmID AND pt_sum_pf.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Coaches_postt.csv
# postt = postg - postw - postl
# [row_scope]
SELECT CAST(target_table.postg AS SIGNED) - CAST(target_table.postw AS SIGNED) - CAST(target_table.postl AS SIGNED) AS computed_value, target_table.postt AS actual_value FROM Coaches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Invoice_BillingCity.csv
# For each invoice row, compute BillingCity as the city stored for its billed customer: BillingCity := Customer.City where Invoice.CustomerId = Customer.CustomerId.
# [across_tables], used_tables: ['Customer']
SELECT c.City AS computed_value, target_table.BillingCity AS actual_value FROM Invoice AS target_table LEFT JOIN Customer AS c ON c.CustomerId = target_table.CustomerId;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_season.csv
# season = YEAR(start_dt)
# [row_scope]
SELECT YEAR(target_table.start_dt) AS computed_value, target_table.season AS actual_value FROM matches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_races_name.csv
# name = replace_underscores_with_spaces(remove_leading_year_and_underscore(last_path_segment(url))) where the leading pattern is '^\d{4}_'
# [row_scope]
SELECT REPLACE(CASE WHEN SUBSTRING_INDEX(target_table.url, '/', -1) REGEXP '^[0-9]{4}_' THEN SUBSTRING(SUBSTRING_INDEX(target_table.url, '/', -1), 6) ELSE SUBSTRING_INDEX(target_table.url, '/', -1) END, '_', ' ') AS computed_value, target_table.`name` AS actual_value FROM `races` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_playoff.csv
# Compute Teams.playoff from inter-table postseason outcomes using SeriesPost as follows (highest-precedence rule first): 1) If the team participated in a Stanley Cup Final (SCF) series in that year with note = 'ND' (No Decision), return 'ND'. 2) Else if the team won an SCF series, return 'SC'. 3) Else if the team lost an SCF series, return 'F'. 4) Else if the team won the WHA Avco Cup Final (ACF), return 'AVC'. 5) Else if the team lost the WHA ACF, return 'AVF'. 6) Else if the team lost a Stanley Cup Semifinal (SCSF), return 'SCSF'. 7) Else if the team lost a Conference Final (CF), return 'CF'. 8) Else if the team lost a Semifinal (SF), return 'AVSF' if lgID='WHA' (WHA semifinal exit), otherwise 'SF'. 9) Else if the team lost a Division Final (DF), return 'DF'. 10) Else if the team lost a Division Semifinal (DSF), return 'DSF'. 11) Else if the team lost a Quarterfinal (QF), return 'QF'. 12) Else if the team lost a Preliminary round ('Pre' or 'Prelim'), return 'Pre'. Otherwise NULL.
# [across_tables], used_tables: ['SeriesPost']
SELECT
  CASE
    WHEN sc_nd.flag = 1 THEN 'ND'
    WHEN sc_win.flag = 1 THEN 'SC'
    WHEN sc_lose.flag = 1 THEN 'F'
    WHEN avc_win.flag = 1 THEN 'AVC'
    WHEN avc_lose.flag = 1 THEN 'AVF'
    WHEN scsf_lose.flag = 1 THEN 'SCSF'
    WHEN cf_lose.flag = 1 THEN 'CF'
    WHEN (sf_lose.flag = 1 AND target_table.lgID = 'WHA') THEN 'AVSF'
    WHEN sf_lose.flag = 1 THEN 'SF'
    WHEN df_lose.flag = 1 THEN 'DF'
    WHEN dsf_lose.flag = 1 THEN 'DSF'
    WHEN qf_lose.flag = 1 THEN 'QF'
    WHEN pre_lose.flag = 1 THEN 'Pre'
    ELSE NULL
  END AS computed_value,
  target_table.playoff AS actual_value
FROM Teams target_table
LEFT JOIN (
  SELECT year, tmID, lgID, 1 AS flag
  FROM (
    SELECT year, tmIDWinner AS tmID, lgIDWinner AS lgID FROM SeriesPost WHERE round = 'SCF' AND note = 'ND'
    UNION ALL
    SELECT year, tmIDLoser  AS tmID, lgIDLoser  AS lgID FROM SeriesPost WHERE round = 'SCF' AND note = 'ND'
  ) s
  GROUP BY year, tmID, lgID
) sc_nd ON sc_nd.year = target_table.year AND sc_nd.tmID = target_table.tmID AND sc_nd.lgID = target_table.lgID
LEFT JOIN (
  SELECT year, tmID, lgID, 1 AS flag
  FROM (
    SELECT year, tmIDWinner AS tmID, lgIDWinner AS lgID FROM SeriesPost WHERE round = 'SCF' AND (note IS NULL OR note <> 'ND')
  ) s
  GROUP BY year, tmID, lgID
) sc_win ON sc_win.year = target_table.year AND sc_win.tmID = target_table.tmID AND sc_win.lgID = target_table.lgID
LEFT JOIN (
  SELECT year, tmID, lgID, 1 AS flag
  FROM (
    SELECT year, tmIDLoser AS tmID, lgIDLoser AS lgID FROM SeriesPost WHERE round = 'SCF' AND (note IS NULL OR note <> 'ND')
  ) s
  GROUP BY year, tmID, lgID
) sc_lose ON sc_lose.year = target_table.year AND sc_lose.tmID = target_table.tmID AND sc_lose.lgID = target_table.lgID
LEFT JOIN (
  SELECT year, tmID, lgID, 1 AS flag
  FROM (
    SELECT year, tmIDWinner AS tmID, lgIDWinner AS lgID FROM SeriesPost WHERE round = 'ACF'
  ) s
  GROUP BY year, tmID, lgID
) avc_win ON avc_win.year = target_table.year AND avc_win.tmID = target_table.tmID AND avc_win.lgID = target_table.lgID
LEFT JOIN (
  SELECT year, tmID, lgID, 1 AS flag
  FROM (
    SELECT year, tmIDLoser AS tmID, lgIDLoser AS lgID FROM SeriesPost WHERE round = 'ACF'
  ) s
  GROUP BY year, tmID, lgID
) avc_lose ON avc_lose.year = target_table.year AND avc_lose.tmID = target_table.tmID AND avc_lose.lgID = target_table.lgID
LEFT JOIN (
  SELECT year, tmID, lgID, 1 AS flag
  FROM (
    SELECT year, tmIDLoser AS tmID, lgIDLoser AS lgID FROM SeriesPost WHERE round = 'SCSF'
  ) s
  GROUP BY year, tmID, lgID
) scsf_lose ON scsf_lose.year = target_table.year AND scsf_lose.tmID = target_table.tmID AND scsf_lose.lgID = target_table.lgID
LEFT JOIN (
  SELECT year, tmID, lgID, 1 AS flag
  FROM (
    SELECT year, tmIDLoser AS tmID, lgIDLoser AS lgID FROM SeriesPost WHERE round = 'CF'
  ) s
  GROUP BY year, tmID, lgID
) cf_lose ON cf_lose.year = target_table.year AND cf_lose.tmID = target_table.tmID AND cf_lose.lgID = target_table.lgID
LEFT JOIN (
  SELECT year, tmID, lgID, 1 AS flag
  FROM (
    SELECT year, tmIDLoser AS tmID, lgIDLoser AS lgID FROM SeriesPost WHERE round = 'SF'
  ) s
  GROUP BY year, tmID, lgID
) sf_lose ON sf_lose.year = target_table.year AND sf_lose.tmID = target_table.tmID AND sf_lose.lgID = target_table.lgID
LEFT JOIN (
  SELECT year, tmID, lgID, 1 AS flag
  FROM (
    SELECT year, tmIDLoser AS tmID, lgIDLoser AS lgID FROM SeriesPost WHERE round = 'DF'
  ) s
  GROUP BY year, tmID, lgID
) df_lose ON df_lose.year = target_table.year AND df_lose.tmID = target_table.tmID AND df_lose.lgID = target_table.lgID
LEFT JOIN (
  SELECT year, tmID, lgID, 1 AS flag
  FROM (
    SELECT year, tmIDLoser AS tmID, lgIDLoser AS lgID FROM SeriesPost WHERE round = 'DSF'
  ) s
  GROUP BY year, tmID, lgID
) dsf_lose ON dsf_lose.year = target_table.year AND dsf_lose.tmID = target_table.tmID AND dsf_lose.lgID = target_table.lgID
LEFT JOIN (
  SELECT year, tmID, lgID, 1 AS flag
  FROM (
    SELECT year, tmIDLoser AS tmID, lgIDLoser AS lgID FROM SeriesPost WHERE round = 'QF'
  ) s
  GROUP BY year, tmID, lgID
) qf_lose ON qf_lose.year = target_table.year AND qf_lose.tmID = target_table.tmID AND qf_lose.lgID = target_table.lgID
LEFT JOIN (
  SELECT year, tmID, lgID, 1 AS flag
  FROM (
    SELECT year, tmIDLoser AS tmID, lgIDLoser AS lgID FROM SeriesPost WHERE round IN ('Pre','Prelim')
  ) s
  GROUP BY year, tmID, lgID
) pre_lose ON pre_lose.year = target_table.year AND pre_lose.tmID = target_table.tmID AND pre_lose.lgID = target_table.lgID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_playoff.csv
# For each team-season, derive the playoff stage from the team?s maximum player playoff games (max_postgp) observed across Scoring.PostGP and Goalies.PostGP, combined with league- and era-specific labels observed in samples: max_postgp := max(MAX(Scoring.PostGP), MAX(Goalies.PostGP)) per (year, tmID). Then map: (1) WHA: if max_postgp >= 13 => 'AVC'. (2) NHL (>= 1974): if 1 <= max_postgp <= 3 => 'PRE'. (3) NHA (1910?1917): if max_postgp >= 2 => 'NHAF'. (4) NHL (1918): if max_postgp >= 5 => 'NHLF'. (5) NHL (1919): if rank = 1 and GF > GA => 'SC'. (6) PCHA (1921): if max_postgp = 4 => 'F'. (7) PCHA (1922): if max_postgp = 2 => 'SCSF'. (8) WCHL (1922): if max_postgp = 2 => 'WF'. (9) NHL (1925): if max_postgp = 2 => 'SF'. (10) NHL (1926): if max_postgp = 2 => 'QF'. Otherwise NULL.
# [across_tables], used_tables: ['Scoring', 'Goalies']
SELECT
  CASE
    WHEN target_table.lgID = 'WHA' AND GREATEST(COALESCE(sc.max_postgp, 0), COALESCE(gl.max_postgp, 0)) >= 13 THEN 'AVC'
    WHEN target_table.lgID = 'NHL' AND target_table.year >= 1974 AND GREATEST(COALESCE(sc.max_postgp, 0), COALESCE(gl.max_postgp, 0)) BETWEEN 1 AND 3 THEN 'PRE'
    WHEN target_table.lgID = 'NHA' AND target_table.year BETWEEN 1910 AND 1917 AND GREATEST(COALESCE(sc.max_postgp, 0), COALESCE(gl.max_postgp, 0)) >= 2 THEN 'NHAF'
    WHEN target_table.lgID = 'NHL' AND target_table.year = 1918 AND GREATEST(COALESCE(sc.max_postgp, 0), COALESCE(gl.max_postgp, 0)) >= 5 THEN 'NHLF'
    WHEN target_table.lgID = 'NHL' AND target_table.year = 1919 AND target_table.rank = 1 AND (CAST(target_table.GF AS SIGNED) - CAST(target_table.GA AS SIGNED)) > 0 THEN 'SC'
    WHEN target_table.lgID = 'PCHA' AND target_table.year = 1921 AND GREATEST(COALESCE(sc.max_postgp, 0), COALESCE(gl.max_postgp, 0)) = 4 THEN 'F'
    WHEN target_table.lgID = 'PCHA' AND target_table.year = 1922 AND GREATEST(COALESCE(sc.max_postgp, 0), COALESCE(gl.max_postgp, 0)) = 2 THEN 'SCSF'
    WHEN target_table.lgID = 'WCHL' AND target_table.year = 1922 AND GREATEST(COALESCE(sc.max_postgp, 0), COALESCE(gl.max_postgp, 0)) = 2 THEN 'WF'
    WHEN target_table.lgID = 'NHL' AND target_table.year = 1925 AND GREATEST(COALESCE(sc.max_postgp, 0), COALESCE(gl.max_postgp, 0)) = 2 THEN 'SF'
    WHEN target_table.lgID = 'NHL' AND target_table.year = 1926 AND GREATEST(COALESCE(sc.max_postgp, 0), COALESCE(gl.max_postgp, 0)) = 2 THEN 'QF'
    ELSE NULL
  END AS computed_value,
  target_table.playoff AS actual_value
FROM Teams target_table
LEFT JOIN (
  SELECT year, tmID, MAX(CAST(PostGP AS SIGNED)) AS max_postgp
  FROM Scoring
  WHERE PostGP IS NOT NULL
  GROUP BY year, tmID
) sc ON sc.year = target_table.year AND sc.tmID = target_table.tmID
LEFT JOIN (
  SELECT year, tmID, MAX(CAST(PostGP AS SIGNED)) AS max_postgp
  FROM Goalies
  WHERE PostGP IS NOT NULL
  GROUP BY year, tmID
) gl ON gl.year = target_table.year AND gl.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderDetail_ModifiedDate.csv
# For each SalesOrderDetail row, ModifiedDate equals the OrderDate of its parent SalesOrderHeader: SalesOrderDetail.ModifiedDate = SalesOrderHeader.OrderDate where SalesOrderHeader.SalesOrderID = SalesOrderDetail.SalesOrderID.
# [across_tables], used_tables: ['SalesOrderHeader']
SELECT h.OrderDate AS computed_value, target_table.ModifiedDate AS actual_value
FROM SalesOrderDetail AS target_table
JOIN SalesOrderHeader AS h ON h.SalesOrderID = target_table.SalesOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderDetail_ModifiedDate.csv
# ModifiedDate in SalesOrderDetail equals the parent SalesOrderHeader.ModifiedDate minus 7 days: SalesOrderDetail.ModifiedDate = DATE_SUB(SalesOrderHeader.ModifiedDate, INTERVAL 7 DAY).
# [across_tables], used_tables: ['SalesOrderHeader']
SELECT DATE_SUB(h.ModifiedDate, INTERVAL 7 DAY) AS computed_value, target_table.ModifiedDate AS actual_value
FROM SalesOrderDetail AS target_table
JOIN SalesOrderHeader AS h ON h.SalesOrderID = target_table.SalesOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderDetail_ModifiedDate.csv
# ModifiedDate in SalesOrderDetail equals the parent SalesOrderHeader.ShipDate minus 7 days plus 1 hour: SalesOrderDetail.ModifiedDate = DATE_ADD(DATE_SUB(SalesOrderHeader.ShipDate, INTERVAL 7 DAY), INTERVAL 1 HOUR).
# [across_tables], used_tables: ['SalesOrderHeader']
SELECT DATE_ADD(DATE_SUB(h.ShipDate, INTERVAL 7 DAY), INTERVAL 1 HOUR) AS computed_value, target_table.ModifiedDate AS actual_value
FROM SalesOrderDetail AS target_table
JOIN SalesOrderHeader AS h ON h.SalesOrderID = target_table.SalesOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_match_stats_KI.csv
# KI = DI - HB
# [row_scope]
SELECT CAST(target_table.`DI` AS SIGNED) - CAST(target_table.`HB` AS SIGNED) AS computed_value, target_table.`KI` AS actual_value FROM `match_stats` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_DecW.csv
# DecW = (hW + rW) - (COALESCE(SepW, 0) + COALESCE(OctW, 0) + COALESCE(NovW, 0) + COALESCE(JanW, 0) + COALESCE(FebW, 0) + COALESCE(MarW, 0) + COALESCE(AprW, 0))
# [row_scope]
SELECT (CAST(target_table.hW AS SIGNED) + CAST(target_table.rW AS SIGNED)) - (COALESCE(CAST(target_table.SepW AS SIGNED), 0) + COALESCE(CAST(target_table.OctW AS SIGNED), 0) + COALESCE(CAST(target_table.NovW AS SIGNED), 0) + COALESCE(CAST(target_table.JanW AS SIGNED), 0) + COALESCE(CAST(target_table.FebW AS SIGNED), 0) + COALESCE(CAST(target_table.MarW AS SIGNED), 0) + COALESCE(CAST(target_table.AprW AS SIGNED), 0)) AS computed_value, target_table.DecW AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_ShipDate.csv
# ShipDate = DATEADD(day, -5, CAST(DueDate AS date))
# [row_scope]
SELECT DATE_SUB(DATE(target_table.DueDate), INTERVAL 5 DAY) AS computed_value, target_table.ShipDate AS actual_value FROM SalesOrderHeader AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_ShipDate.csv
# ShipDate = DATE(MAX(SalesOrderHeaderSalesReason.ModifiedDate)) + INTERVAL 7 DAY (i.e., take the latest SalesOrderHeaderSalesReason.ModifiedDate per order, add 7 days, and truncate to date).
# [across_tables], used_tables: ['SalesOrderHeaderSalesReason']
SELECT CAST(DATE(DATE_ADD(sr_max.max_modified_date, INTERVAL 7 DAY)) AS DATETIME) AS computed_value, target_table.ShipDate AS actual_value FROM SalesOrderHeader AS target_table LEFT JOIN ( SELECT SalesOrderID, MAX(ModifiedDate) AS max_modified_date FROM SalesOrderHeaderSalesReason GROUP BY SalesOrderID ) AS sr_max ON sr_max.SalesOrderID = target_table.SalesOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_ShipDate.csv
# ShipDate = DATEADD(day, 7, CAST(OrderDate AS date))
# [row_scope]
SELECT DATE_ADD(CAST(target_table.OrderDate AS DATE), INTERVAL 7 DAY) AS computed_value, target_table.ShipDate AS actual_value FROM SalesOrderHeader AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_ShipDate.csv
# ShipDate = DATE(MAX(SalesOrderDetail.ModifiedDate) per SalesOrderID) plus 7 days.
# [across_tables], used_tables: ['SalesOrderDetail', 'ShipMethod']
SELECT
  DATE_ADD(DATE(sod_max.max_modified), INTERVAL 7 DAY) AS computed_value,
  target_table.ShipDate AS actual_value
FROM SalesOrderHeader AS target_table
LEFT JOIN (
  SELECT SalesOrderID, MAX(ModifiedDate) AS max_modified
  FROM SalesOrderDetail
  GROUP BY SalesOrderID
) AS sod_max
  ON sod_max.SalesOrderID = target_table.SalesOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_ShipDate.csv
# ShipDate = DueDate minus ROUND(ShipMethod.ShipBase + ShipMethod.ShipRate) days, where ShipMethod comes from SalesOrderHeader.ShipMethodID.
# [across_tables], used_tables: ['SalesOrderDetail', 'ShipMethod']
SELECT
  DATE_SUB(target_table.DueDate, INTERVAL CAST(ROUND(sm.ShipBase + sm.ShipRate) AS SIGNED) DAY) AS computed_value,
  target_table.ShipDate AS actual_value
FROM SalesOrderHeader AS target_table
JOIN ShipMethod AS sm
  ON sm.ShipMethodID = target_table.ShipMethodID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_OctL.csv
# OctL = (COALESCE(hL, 0) + COALESCE(rL, 0)) - (COALESCE(SepL, 0) + COALESCE(NovL, 0) + COALESCE(DecL, 0) + COALESCE(JanL, 0) + COALESCE(FebL, 0) + COALESCE(MarL, 0) + COALESCE(AprL, 0))
# [row_scope]
SELECT (CAST(COALESCE(`target_table`.`hL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`rL`, 0) AS SIGNED)) - (CAST(COALESCE(`target_table`.`SepL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`NovL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`DecL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`JanL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`FebL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`MarL`, 0) AS SIGNED) + CAST(COALESCE(`target_table`.`AprL`, 0) AS SIGNED)) AS computed_value, `target_table`.`OctL` AS actual_value FROM `TeamSplits` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_users_DownVotes.csv
# nan
# [count_or_exist with data sharing], given_table_name = votes
SELECT COUNT(v.Id) AS computed_value, MAX(target_table.DownVotes) AS actual_value FROM users AS target_table LEFT JOIN votes AS v ON v.UserId = target_table.Id AND v.VoteTypeId = 3 GROUP BY target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_win_score.csv
# win_score = margin + lose_score
# [row_scope]
SELECT CAST(`target_table`.`margin` AS SIGNED) + CAST(`target_table`.`lose_score` AS SIGNED) AS `computed_value`, `target_table`.`win_score` AS `actual_value` FROM `matches` AS `target_table`
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_win_score.csv
# win_score = GREATEST(h_score, a_score)
# [row_scope]
SELECT GREATEST(target_table.h_score, target_table.a_score) AS computed_value, target_table.win_score AS actual_value FROM matches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Goalies_PostT.csv
# PostT = PostGP - PostW - PostL
# [row_scope]
SELECT CAST(`target_table`.`PostGP` AS SIGNED) - CAST(`target_table`.`PostW` AS SIGNED) - CAST(`target_table`.`PostL` AS SIGNED) AS `computed_value`, `target_table`.`PostT` AS `actual_value` FROM `Goalies` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Document_DocumentLevel.csv
# DocumentLevel = (count of '/' characters in DocumentNode) - 1
# [row_scope]
SELECT CAST((CAST(CHAR_LENGTH(target_table.DocumentNode) AS SIGNED) - CAST(CHAR_LENGTH(REPLACE(target_table.DocumentNode, '/', '')) AS SIGNED) - 1) AS SIGNED) AS computed_value, target_table.DocumentLevel AS actual_value FROM `Document` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Document_DocumentLevel.csv
# DocumentLevel = CASE WHEN Document.DocumentNode = '/' THEN 0 ELSE Employee.OrganizationLevel - 2 END, where Employee is joined by Document.Owner = Employee.BusinessEntityID.
# [across_tables], used_tables: ['Employee']
SELECT
  CASE
    WHEN target_table.DocumentNode = '/' THEN 0
    WHEN e.OrganizationLevel IS NOT NULL THEN e.OrganizationLevel - 2
    ELSE NULL
  END AS computed_value,
  target_table.DocumentLevel AS actual_value
FROM Document AS target_table
LEFT JOIN Employee AS e
  ON e.BusinessEntityID = target_table.Owner;
###########################################################

###########################################################
# filtered_reported_accuracy_uni_Student_gpa.csv
# GPA for a student = (sum over all that student?s enrollments of (Enrollment.grade * Course.credit_hours)) divided by (sum over all that student?s enrollments of Course.credit_hours). All enrollments are included regardless of pass/fail.
# [across_tables], used_tables: ['Enrollment', 'Course']
SELECT CASE WHEN agg_w.credits IS NOT NULL AND agg_w.credits <> 0 THEN agg_w.weighted_sum / agg_w.credits ELSE NULL END AS computed_value, target_table.gpa AS actual_value FROM Student AS target_table LEFT JOIN ( SELECT e.std_id, SUM(e.grade * c.credit_hours) AS weighted_sum, SUM(c.credit_hours) AS credits FROM Enrollment e JOIN Course c ON c.course_id = e.course_id GROUP BY e.std_id ) AS agg_w ON target_table.std_id = agg_w.std_id;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Master_lastWHA.csv
# For each player, lastWHA equals the maximum year among all their WHA entries across Scoring, Goalies, and AwardsPlayers: lastWHA = max( max_year_from_Scoring_where_lgID='WHA', max_year_from_Goalies_where_lgID='WHA', max_year_from_AwardsPlayers_where_lgID='WHA' ).
# [across_tables], used_tables: ['Scoring', 'Goalies', 'AwardsPlayers']
SELECT
  CASE
    WHEN GREATEST(
           COALESCE(sc.max_wha_year, -1),
           COALESCE(go.max_wha_year, -1),
           COALESCE(ap.max_wha_year, -1)
         ) < 0 THEN NULL
    ELSE GREATEST(
           COALESCE(sc.max_wha_year, -1),
           COALESCE(go.max_wha_year, -1),
           COALESCE(ap.max_wha_year, -1)
         )
  END AS computed_value,
  target_table.lastWHA AS actual_value
FROM Master AS target_table
LEFT JOIN (
  SELECT playerID, MAX(year) AS max_wha_year
  FROM Scoring
  WHERE lgID = 'WHA'
  GROUP BY playerID
) sc ON sc.playerID = target_table.playerID
LEFT JOIN (
  SELECT playerID, MAX(year) AS max_wha_year
  FROM Goalies
  WHERE lgID = 'WHA'
  GROUP BY playerID
) go ON go.playerID = target_table.playerID
LEFT JOIN (
  SELECT playerID, MAX(year) AS max_wha_year
  FROM AwardsPlayers
  WHERE lgID = 'WHA'
  GROUP BY playerID
) ap ON ap.playerID = target_table.playerID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_d_dreb.csv
# d_dreb = d_reb - d_oreb
# [row_scope]
SELECT CAST(target_table.d_reb AS SIGNED INTEGER) - CAST(target_table.d_oreb AS SIGNED INTEGER) AS computed_value, target_table.d_dreb AS actual_value FROM teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_3pm.csv
# o_3pm = o_pts - 2 * o_fgm - o_ftm
# [row_scope]
SELECT (CAST(target_table.o_pts AS SIGNED) - 2 * CAST(target_table.o_fgm AS SIGNED) - CAST(target_table.o_ftm AS SIGNED)) AS computed_value, target_table.o_3pm AS actual_value FROM teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsHalf_GA.csv
# For a given team-season half, GA_half = Teams_total_GA(year, tmID) ? (Sum of GA across all halves for that team-season ? GA_current_half). Equivalently, GA_half = Teams_total_GA ? Sum_of_other_halves_GA.
# [across_tables], used_tables: ['Teams']
SELECT
  CAST(t.GA AS SIGNED) - CAST(COALESCE(ga_total.total_ga_across_halves, 0) - COALESCE(target_table.GA, 0) AS SIGNED) AS computed_value,
  CAST(target_table.GA AS SIGNED) AS actual_value
FROM TeamsHalf AS target_table
JOIN Teams AS t
  ON t.year = target_table.year AND t.tmID = target_table.tmID
LEFT JOIN (
  SELECT year, lgID, tmID, SUM(CAST(GA AS SIGNED)) AS total_ga_across_halves
  FROM TeamsHalf
  GROUP BY year, lgID, tmID
) AS ga_total
  ON ga_total.year = target_table.year AND ga_total.lgID = target_table.lgID AND ga_total.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Shift_Name.csv
# Name = CASE WHEN StartTime = '07:00:00' THEN 'Day' WHEN StartTime = '15:00:00' THEN 'Evening' WHEN StartTime = '23:00:00' THEN 'Night' END
# [row_scope]
SELECT CASE WHEN target_table.`StartTime` = '07:00:00' THEN 'Day' WHEN target_table.`StartTime` = '15:00:00' THEN 'Evening' WHEN target_table.`StartTime` = '23:00:00' THEN 'Night' END AS computed_value, target_table.`Name` AS actual_value FROM `Shift` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_match_stats_DI.csv
# DI = KI + HB
# [row_scope]
SELECT CAST(`target_table`.`KI` AS SIGNED) + CAST(`target_table`.`HB` AS SIGNED) AS `computed_value`, `target_table`.`DI` AS `actual_value` FROM `match_stats` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_match_stats_DI.csv
# For a player stat line linked to its match via matches.mid, and validated that the player?s team/location aligns with the match?s home/away team (loc = 'h' -> tid = matches.h_tid, loc = 'a' -> tid = matches.a_tid), approximate DI as the sum of contested and uncontested possessions: DI ? CP + UP.
# [across_tables], used_tables: ['matches']
SELECT (CAST(target_table.CP AS SIGNED) + CAST(target_table.UP AS SIGNED)) AS computed_value, target_table.DI AS actual_value FROM match_stats AS target_table INNER JOIN matches AS m ON m.mid = target_table.mid AND ((target_table.loc = 'h' AND target_table.tid = m.h_tid) OR (target_table.loc = 'a' AND target_table.tid = m.a_tid));
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_awards_players_lgID.csv
# For each awards_players row (playerID, year), set lgID to the league recorded for that player in players_teams for the same year. If multiple stints exist in that year, choose the lgID whose summed minutes across stints is maximal; if still tied, pick the lexicographically smallest lgID.
# [across_tables], used_tables: ['players_teams']
SELECT
  pt_best.lgID AS computed_value,
  target_table.lgID AS actual_value
FROM awards_players AS target_table
LEFT JOIN (
  SELECT t1.playerID, t1.year, MIN(t1.lgID) AS lgID
  FROM (
    SELECT pt.playerID, pt.year, pt.lgID, SUM(CAST(pt.minutes AS SIGNED)) AS total_minutes
    FROM players_teams pt
    GROUP BY pt.playerID, pt.year, pt.lgID
  ) AS t1
  JOIN (
    SELECT playerID, year, MAX(total_minutes) AS max_total_minutes
    FROM (
      SELECT pt.playerID, pt.year, pt.lgID, SUM(CAST(pt.minutes AS SIGNED)) AS total_minutes
      FROM players_teams pt
      GROUP BY pt.playerID, pt.year, pt.lgID
    ) AS s
    GROUP BY playerID, year
  ) AS t2
  ON t1.playerID = t2.playerID AND t1.year = t2.year AND t1.total_minutes = t2.max_total_minutes
  GROUP BY t1.playerID, t1.year
) AS pt_best
ON pt_best.playerID = target_table.playerID AND pt_best.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Scoring_G.csv
# G = Pts - A
# [row_scope]
SELECT CAST(`target_table`.`Pts` AS SIGNED) - CAST(`target_table`.`A` AS SIGNED) AS `computed_value`, `target_table`.`G` AS `actual_value` FROM `Scoring` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Scoring_G.csv
# For a given Scoring row (playerID, year, tmID, stint), the players regular-season goals G equal the teams total regular-season goals for that season and team (Teams.GF) minus the sum of goals by all other Scoring rows for the same team-season. Formally, G(player,year,tm,stint) = Teams.GF(year,tm) ? ?_{all Scoring rows r with r.year=year AND r.tmID=tm AND r?this row} r.G. Implementationally, compute ?_team G across all Scoring rows for (year, tmID), then subtract that total minus this rows G.
# [across_tables], used_tables: ['ScoringSC', 'Teams']
SELECT 
  CAST(t.GF AS SIGNED) - (CAST(team_sum.total_goals AS SIGNED) - CAST(COALESCE(target_table.G, 0) AS SIGNED)) AS computed_value,
  target_table.G AS actual_value
FROM Scoring AS target_table
LEFT JOIN Teams AS t
  ON t.year = target_table.year AND t.tmID = target_table.tmID
LEFT JOIN (
  SELECT s.year, s.tmID, SUM(COALESCE(s.G, 0)) AS total_goals
  FROM Scoring s
  GROUP BY s.year, s.tmID
) AS team_sum
  ON team_sum.year = target_table.year AND team_sum.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_Pts.csv
# Pts = (2 * W) + COALESCE(T, 0) + COALESCE(OTL, 0)
# [row_scope]
SELECT (2 * CAST(target_table.W AS SIGNED)) + COALESCE(CAST(target_table.T AS SIGNED), 0) + COALESCE(CAST(target_table.OTL AS SIGNED), 0) AS computed_value, target_table.Pts AS actual_value FROM Teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_Pts.csv
# For each team-season (Teams.year, Teams.tmID), Points equals two times the sum of all coaches? wins plus the sum of all coaches? ties recorded in Coaches for that team-season: Pts = 2 * ?_Coaches(w) + ?_Coaches(t).
# [across_tables], used_tables: ['Coaches', 'TeamVsTeam']
SELECT
  CAST(COALESCE(coach_totals.sum_w, 0) AS SIGNED) * 2
  + CAST(COALESCE(coach_totals.sum_t, 0) AS SIGNED) AS computed_value,
  target_table.Pts AS actual_value
FROM Teams AS target_table
LEFT JOIN (
  SELECT
    year,
    tmID,
    SUM(COALESCE(w, 0)) AS sum_w,
    SUM(COALESCE(t, 0)) AS sum_t
  FROM Coaches
  GROUP BY year, tmID
) AS coach_totals
  ON coach_totals.year = target_table.year
 AND coach_totals.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeaderSalesReason_ModifiedDate.csv
# For each row in SalesOrderHeaderSalesReason, ModifiedDate equals the OrderDate of the corresponding SalesOrderHeader identified by the same SalesOrderID.
# [across_tables], used_tables: ['SalesOrderHeader']
SELECT so.OrderDate AS computed_value, target_table.ModifiedDate AS actual_value FROM SalesOrderHeaderSalesReason AS target_table INNER JOIN SalesOrderHeader AS so ON so.SalesOrderID = target_table.SalesOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeaderSalesReason_ModifiedDate.csv
# For a given SalesOrderID, SalesOrderHeaderSalesReason.ModifiedDate equals the minimum SalesOrderDetail.ModifiedDate across all detail rows of that order.
# [across_tables], used_tables: ['SalesOrderHeader', 'SalesOrderDetail']
SELECT sod_min.computed_value AS computed_value, target_table.ModifiedDate AS actual_value
FROM SalesOrderHeaderSalesReason AS target_table
LEFT JOIN (
  SELECT SalesOrderID, MIN(ModifiedDate) AS computed_value
  FROM SalesOrderDetail
  GROUP BY SalesOrderID
) AS sod_min
  ON sod_min.SalesOrderID = target_table.SalesOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeaderSalesReason_ModifiedDate.csv
# For each row in SalesOrderHeaderSalesReason, ModifiedDate = ShipDate of the corresponding SalesOrderHeader row minus 7 days, plus 1 hour.
# [across_tables], used_tables: ['SalesOrderHeader', 'CurrencyRate']
SELECT DATE_ADD(DATE_ADD(soh.ShipDate, INTERVAL -7 DAY), INTERVAL 1 HOUR) AS computed_value, target_table.ModifiedDate AS actual_value
FROM SalesOrderHeaderSalesReason AS target_table
JOIN SalesOrderHeader AS soh ON soh.SalesOrderID = target_table.SalesOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_stl.csv
# For each team-season, teams.o_stl equals the sum of steals recorded by all players for that team and year in players_teams. Formally: o_stl(year, tmID) = SUM_{rows in players_teams where year = team.year and tmID = team.tmID}(players_teams.steals). If no matching player rows exist, treat the sum as 0.
# [across_tables], used_tables: ['players_teams', 'players']
SELECT
  COALESCE(pt_agg.value, 0) AS computed_value,
  target_table.o_stl AS actual_value
FROM teams AS target_table
LEFT JOIN (
  SELECT year, tmID, SUM(COALESCE(steals, 0)) AS value
  FROM players_teams
  GROUP BY year, tmID
) AS pt_agg
  ON pt_agg.year = target_table.year
 AND pt_agg.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrderRouting_ActualCost.csv
# ActualCost = PlannedCost
# [row_scope]
SELECT `target_table`.`PlannedCost` AS computed_value, `target_table`.`ActualCost` AS actual_value FROM `WorkOrderRouting` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrderRouting_ActualCost.csv
# ActualCost = Location.CostRate ? WorkOrderRouting.ActualResourceHrs
# [across_tables], used_tables: ['Location', 'WorkOrder']
SELECT
  (l.CostRate * target_table.ActualResourceHrs) AS computed_value,
  target_table.ActualCost AS actual_value
FROM WorkOrderRouting AS target_table
JOIN Location AS l ON l.LocationID = target_table.LocationID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_3pa.csv
# For each team-season (year, tmID), o_3pa equals the sum of players_teams.threeAttempted over all player rows for that same (year, tmID).
# [across_tables], used_tables: ['players_teams']
SELECT
  COALESCE(pt_3pa.value, 0) AS computed_value,
  target_table.o_3pa AS actual_value
FROM teams AS target_table
LEFT JOIN (
  SELECT tmID, year, SUM(CAST(threeAttempted AS SIGNED)) AS value
  FROM players_teams
  GROUP BY tmID, year
) AS pt_3pa
  ON target_table.tmID = pt_3pa.tmID
 AND target_table.year = pt_3pa.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_GoaliesSC_W.csv
# W = GP - L - T
# [row_scope]
SELECT (CAST(target_table.`GP` AS SIGNED) - CAST(target_table.`L` AS SIGNED) - CAST(target_table.`T` AS SIGNED)) AS computed_value, target_table.`W` AS actual_value FROM `GoaliesSC` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_GoaliesSC_W.csv
# For any goalie-season entry in GoaliesSC, the number of wins W equals the team?s Stanley Cup game wins recorded in TeamsSC for the same (year, lgID, tmID): GoaliesSC.W = TeamsSC.W.
# [across_tables], used_tables: ['TeamsSC', 'SeriesPost']
SELECT
  ts_w.value AS computed_value,
  target_table.W AS actual_value
FROM GoaliesSC AS target_table
LEFT JOIN (
  SELECT year, lgID, tmID, W AS value
  FROM TeamsSC
) AS ts_w
  ON ts_w.year = target_table.year
 AND ts_w.lgID = target_table.lgID
 AND ts_w.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_CreaionDate.csv
# For each post, derive CreaionDate as the minimum CreationDate among postHistory rows for that PostId where PostHistoryTypeId = 2 (initial body creation).
# [across_tables], used_tables: ['postHistory']
SELECT ph_init_body.value AS computed_value, target_table.CreaionDate AS actual_value
FROM posts AS target_table
LEFT JOIN (
  SELECT PostId, MIN(CreationDate) AS value
  FROM postHistory
  WHERE PostHistoryTypeId = 2
  GROUP BY PostId
) AS ph_init_body
  ON ph_init_body.PostId = target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_LastEditDate.csv
# For each post (posts.Id), LastEditDate equals the maximum postHistory.CreationDate among postHistory rows for that post where PostHistoryTypeId indicates an edit event (PostHistoryTypeId IN (5,6,7)). If no such postHistory row exists, the computed value is NULL.
# [across_tables], used_tables: ['postHistory']
SELECT
  any_edits.last_edit_date AS computed_value,
  target_table.LastEditDate AS actual_value
FROM posts AS target_table
LEFT JOIN (
  SELECT
    ph.PostId AS PostId,
    MAX(ph.CreationDate) AS last_edit_date
  FROM postHistory ph
  WHERE ph.PostHistoryTypeId IN (5,6,7)
  GROUP BY ph.PostId
) AS any_edits
  ON any_edits.PostId = target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_awards_coaches_lgID.csv
# lgID = substring of award up to the first space character
# [row_scope]
SELECT SUBSTRING_INDEX(target_table.award, ' ', 1) AS computed_value, target_table.lgID AS actual_value FROM awards_coaches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_awards_coaches_lgID.csv
# For each awards_coaches row identified by (coachID, year), set lgID to the unique league code recorded for that coach in the coaches table for the same (coachID, year). If the coach has multiple stints in that season, all stints share the same league; collapse via MIN(coaches.lgID) grouped by (coachID, year).
# [across_tables], used_tables: ['teams', 'coaches']
SELECT coach_lg.lgID AS computed_value, target_table.lgID AS actual_value FROM awards_coaches AS target_table LEFT JOIN ( SELECT c.coachID, c.year, MIN(c.lgID) AS lgID FROM coaches c GROUP BY c.coachID, c.year ) AS coach_lg ON coach_lg.coachID = target_table.coachID AND coach_lg.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_TransactionHistory_ModifiedDate.csv
# ModifiedDate = TransactionDate
# [row_scope]
SELECT target_table.TransactionDate AS computed_value, target_table.ModifiedDate AS actual_value FROM `TransactionHistory` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_tid1_loc.csv
# tid1_loc = CASE WHEN tid1 = h_tid THEN 'h' ELSE 'a' END
# [row_scope]
SELECT CASE WHEN `target_table`.`tid1` = `target_table`.`h_tid` THEN 'h' ELSE 'a' END AS `computed_value`, `target_table`.`tid1_loc` AS `actual_value` FROM `matches` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderDetail_UnitPrice.csv
# UnitPrice = LineTotal / (OrderQty * (1 - UnitPriceDiscount))
# [row_scope]
SELECT (target_table.LineTotal / (CAST(target_table.OrderQty AS DECIMAL(38,6)) * (CAST(1 AS DECIMAL(38,6)) - CAST(target_table.UnitPriceDiscount AS DECIMAL(38,6))))) AS computed_value, target_table.UnitPrice AS actual_value FROM SalesOrderDetail AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_margin.csv
# margin = win_score - lose_score
# [row_scope]
SELECT CAST(`target_table`.`win_score` AS SIGNED) - CAST(`target_table`.`lose_score` AS SIGNED) AS `computed_value`, `target_table`.`margin` AS `actual_value` FROM `matches` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_SHF.csv
# For a given playoff team (year, lgID, tmID), SHF (team shorthanded goals in playoffs) equals the sum of players PostSHG (playoff shorthanded goals) from the Scoring table for that same (year, lgID, tmID). SHF_post(team,year) = SUM_over_players_on_team(Scoring.PostSHG).
# [across_tables], used_tables: ['Scoring']
SELECT
  COALESCE(sc_shg.value, 0) AS computed_value,
  CAST(target_table.SHF AS SIGNED) AS actual_value
FROM TeamsPost AS target_table
LEFT JOIN (
  SELECT year, lgID, tmID, SUM(CAST(PostSHG AS UNSIGNED)) AS value
  FROM Scoring
  WHERE PostSHG IS NOT NULL
  GROUP BY year, lgID, tmID
) AS sc_shg
  ON sc_shg.year = target_table.year
  AND sc_shg.lgID = target_table.lgID
  AND sc_shg.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_TransactionHistoryArchive_TransactionDate.csv
# TransactionDate = ModifiedDate
# [row_scope]
SELECT target_table.ModifiedDate AS computed_value, target_table.TransactionDate AS actual_value FROM TransactionHistoryArchive AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderDetail_ReceivedQty.csv
# ReceivedQty = StockedQty + RejectedQty
# [row_scope]
SELECT (CAST(target_table.StockedQty AS DECIMAL(38,10)) + CAST(target_table.RejectedQty AS DECIMAL(38,10))) AS computed_value, target_table.ReceivedQty AS actual_value FROM PurchaseOrderDetail AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderDetail_ReceivedQty.csv
# ReceivedQty for a purchase order line equals the full ordered quantity if the parent purchase order has ShipDate IS NOT NULL and Status IN (2,4); otherwise, ReceivedQty equals the sum of TransactionHistory.Quantity for that line where TransactionType = 'P' (matching ReferenceOrderID and ReferenceOrderLineID).
# [across_tables], used_tables: ['TransactionHistory', 'PurchaseOrderHeader']
SELECT
  CASE 
    WHEN poh.ShipDate IS NOT NULL AND poh.Status IN (2,4) 
      THEN CAST(target_table.OrderQty AS DECIMAL(19,2))
    ELSE COALESCE(p_trx.total_p_qty, 0)
  END AS computed_value,
  target_table.ReceivedQty AS actual_value
FROM PurchaseOrderDetail AS target_table
LEFT JOIN PurchaseOrderHeader AS poh
  ON poh.PurchaseOrderID = target_table.PurchaseOrderID
LEFT JOIN (
  SELECT 
    ReferenceOrderID, 
    ReferenceOrderLineID, 
    SUM(CAST(Quantity AS SIGNED)) AS total_p_qty
  FROM TransactionHistory
  WHERE TransactionType = 'P'
  GROUP BY ReferenceOrderID, ReferenceOrderLineID
) AS p_trx
  ON p_trx.ReferenceOrderID = target_table.PurchaseOrderID
 AND p_trx.ReferenceOrderLineID = target_table.PurchaseOrderDetailID;
###########################################################

###########################################################
# filtered_reported_accuracy_uni_Course_pass_rate.csv
# nan
# [count_or_exist with data sharing], given_table_name = Enrollment
SELECT
  CASE WHEN target_table.total_enrollments IS NOT NULL AND target_table.total_enrollments > 0
       THEN COUNT(CASE WHEN e.passed = 1 THEN 1 END) / target_table.total_enrollments
       ELSE NULL
  END AS computed_value,
  target_table.pass_rate AS actual_value
FROM Course AS target_table
LEFT JOIN Enrollment AS e
  ON e.course_id = target_table.course_id
GROUP BY target_table.course_id, target_table.pass_rate, target_table.total_enrollments;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_JanT.csv
# JanT (January ties) for a given team-season equals the season total ties from Teams.T minus the sum of ties recorded in all other months in TeamSplits (SepT + OctT + NovT + DecT + FebT + MarT + AprT). In symbols per (year, tmID): JanT = Teams.T - (COALESCE(SepT,0) + COALESCE(OctT,0) + COALESCE(NovT,0) + COALESCE(DecT,0) + COALESCE(FebT,0) + COALESCE(MarT,0) + COALESCE(AprT,0)).
# [across_tables], used_tables: ['Teams']
SELECT
  (COALESCE(CAST(season.`T` AS SIGNED), 0)
   - COALESCE(CAST(target_table.`SepT` AS SIGNED), 0)
   - COALESCE(CAST(target_table.`OctT` AS SIGNED), 0)
   - COALESCE(CAST(target_table.`NovT` AS SIGNED), 0)
   - COALESCE(CAST(target_table.`DecT` AS SIGNED), 0)
   - COALESCE(CAST(target_table.`FebT` AS SIGNED), 0)
   - COALESCE(CAST(target_table.`MarT` AS SIGNED), 0)
   - COALESCE(CAST(target_table.`AprT` AS SIGNED), 0)
  ) AS computed_value,
  target_table.`JanT` AS actual_value
FROM `TeamSplits` AS target_table
JOIN `Teams` AS season
  ON season.`year` = target_table.`year`
 AND season.`tmID` = target_table.`tmID`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_AprW.csv
# AprW = (hW + rW) - COALESCE(SepW, 0) - COALESCE(OctW, 0) - COALESCE(NovW, 0) - COALESCE(DecW, 0) - COALESCE(JanW, 0) - COALESCE(FebW, 0) - COALESCE(MarW, 0)
# [row_scope]
SELECT
  (
    CAST(target_table.hW AS SIGNED)
    + CAST(target_table.rW AS SIGNED)
    - CAST(COALESCE(target_table.SepW, 0) AS SIGNED)
    - CAST(COALESCE(target_table.OctW, 0) AS SIGNED)
    - CAST(COALESCE(target_table.NovW, 0) AS SIGNED)
    - CAST(COALESCE(target_table.DecW, 0) AS SIGNED)
    - CAST(COALESCE(target_table.JanW, 0) AS SIGNED)
    - CAST(COALESCE(target_table.FebW, 0) AS SIGNED)
    - CAST(COALESCE(target_table.MarW, 0) AS SIGNED)
  ) AS computed_value,
  target_table.AprW AS actual_value
FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_uni_Course_total_enrollments.csv
# nan
# [count_or_exist without data sharing], given_table_name = Enrollment
select Course.course_id, Course.total_enrollments actual_value, Count(*) computed_value from  `Course` 
LEFT JOIN Enrollment ON `Enrollment`.`course_id` = `Course`.`course_id` group by Course.course_id, Course.total_enrollments
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_lgID.csv
# For each TeamSplits row, set lgID to the lgID from Teams where Teams.year = TeamSplits.year and Teams.tmID = TeamSplits.tmID.
# [across_tables], used_tables: ['Teams']
SELECT t2.lgID AS computed_value, target_table.lgID AS actual_value
FROM TeamSplits AS target_table
LEFT JOIN Teams AS t2
  ON t2.year = target_table.year AND t2.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_lgID.csv
# For each TeamSplits row (year, tmID), derive lgID as the most frequent lgID found in Scoring for the same (year, tmID) (mode by count). In case of ties for maximum frequency, choose the lexicographically smallest lgID.
# [across_tables], used_tables: ['Scoring']
SELECT
  scoring_map.lgID AS computed_value,
  target_table.lgID AS actual_value
FROM TeamSplits AS target_table
LEFT JOIN (
  SELECT c.year, c.tmID, MIN(c.lgID) AS lgID
  FROM (
    SELECT s.year, s.tmID, s.lgID, COUNT(*) AS cnt
    FROM Scoring AS s
    GROUP BY s.year, s.tmID, s.lgID
  ) AS c
  JOIN (
    SELECT year, tmID, MAX(cnt) AS max_cnt
    FROM (
      SELECT s.year, s.tmID, s.lgID, COUNT(*) AS cnt
      FROM Scoring AS s
      GROUP BY s.year, s.tmID, s.lgID
    ) AS cx
    GROUP BY year, tmID
  ) AS m
    ON m.year = c.year AND m.tmID = c.tmID AND c.cnt = m.max_cnt
  GROUP BY c.year, c.tmID
) AS scoring_map
  ON scoring_map.year = target_table.year
 AND scoring_map.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_lgID.csv
# Compute lgID solely from Coaches: for each (year, tmID) in TeamSplits, if all Coaches rows for that pair have the same lgID, use that lgID; otherwise leave it NULL.
# [across_tables], used_tables: ['Coaches']
SELECT
  c.lgID_single AS computed_value,
  target_table.lgID AS actual_value
FROM TeamSplits AS target_table
LEFT JOIN (
  SELECT year, tmID,
         CASE WHEN COUNT(DISTINCT lgID) = 1 THEN MIN(lgID) ELSE NULL END AS lgID_single
  FROM Coaches
  GROUP BY year, tmID
) AS c
  ON c.year = target_table.year AND c.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_lgID.csv
# For each TeamSplits row (year, tmID), derive lgID purely from SeriesPost by taking the unique league ID that the team carried in that season across all its postseason series appearances: union (year, tmIDWinner, lgIDWinner) and (year, tmIDLoser, lgIDLoser) and, when multiple rows exist, select a single value (e.g., MIN, which is valid because the team?s league is consistent within a season).
# [across_tables], used_tables: ['SeriesPost']
SELECT
  sp.lgID AS computed_value,
  target_table.lgID AS actual_value
FROM TeamSplits AS target_table
LEFT JOIN (
  SELECT s.year, s.tmID, MIN(s.lgID) AS lgID
  FROM (
    SELECT year, tmIDWinner AS tmID, lgIDWinner AS lgID FROM SeriesPost
    UNION ALL
    SELECT year, tmIDLoser  AS tmID, lgIDLoser  AS lgID FROM SeriesPost
  ) AS s
  GROUP BY s.year, s.tmID
) AS sp
  ON sp.year = target_table.year
 AND sp.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Master_lastNHL.csv
# For each player in Master, lastNHL equals the maximum season year in Scoring where that players rows have lgID = 'NHL'. In other words: lastNHL(player) = MAX(Scoring.year) filtered by Scoring.playerID = Master.playerID and Scoring.lgID = 'NHL'.
# [across_tables], used_tables: ['Scoring', 'Teams']
SELECT s_last.last_year AS computed_value, target_table.lastNHL AS actual_value
FROM Master AS target_table
LEFT JOIN (
  SELECT playerID, MAX(year) AS last_year
  FROM Scoring
  WHERE lgID = 'NHL'
  GROUP BY playerID
) AS s_last
  ON target_table.playerID = s_last.playerID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Scoring_PostG.csv
# PostG = PostPts - PostA
# [row_scope]
SELECT (CAST(target_table.PostPts AS SIGNED) - CAST(target_table.PostA AS SIGNED)) AS computed_value, target_table.PostG AS actual_value FROM Scoring AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Scoring_PostG.csv
# For each Scoring row (playerID, year, tmID), estimate PostG as the player?s regular-season goal share of his team scaled by the team?s total playoff goals that year: PostG_est = G(player, year, tmID) * (TeamPlayoffGoals(year, tmID) / Teams.GF(year, tmID)). Here, TeamPlayoffGoals(year, tmID) = SUM(GoalsWinner) over SeriesPost rows where (year, tmIDWinner = tmID) + SUM(GoalsLoser) over SeriesPost rows where (year, tmIDLoser = tmID).
# [across_tables], used_tables: ['SeriesPost']
SELECT 
  CASE 
    WHEN t.GF IS NULL OR t.GF = 0 OR pg.playoff_goals IS NULL OR target_table.G IS NULL THEN NULL 
    ELSE CAST((CAST(target_table.G AS SIGNED) * CAST(pg.playoff_goals AS SIGNED)) / CAST(t.GF AS SIGNED) AS SIGNED) 
  END AS computed_value,
  target_table.PostG AS actual_value
FROM Scoring AS target_table
LEFT JOIN Teams AS t
  ON t.year = target_table.year AND t.tmID = target_table.tmID
LEFT JOIN (
  SELECT year, tmID, SUM(goals) AS playoff_goals
  FROM (
    SELECT sp.year AS year, sp.tmIDWinner AS tmID, SUM(sp.GoalsWinner) AS goals
    FROM SeriesPost sp
    GROUP BY sp.year, sp.tmIDWinner
    UNION ALL
    SELECT sp.year AS year, sp.tmIDLoser AS tmID, SUM(sp.GoalsLoser) AS goals
    FROM SeriesPost sp
    GROUP BY sp.year, sp.tmIDLoser
  ) AS u
  GROUP BY year, tmID
) AS pg
  ON pg.year = target_table.year AND pg.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_TaxAmt.csv
# TaxAmt = (TotalDue - SubTotal) - Freight
# [row_scope]
SELECT (CAST(target_table.TotalDue AS DECIMAL(65,10)) - CAST(target_table.SubTotal AS DECIMAL(65,10)) - CAST(target_table.Freight AS DECIMAL(65,10))) AS computed_value, target_table.TaxAmt AS actual_value FROM SalesOrderHeader AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_TaxAmt.csv
# TaxAmt = SubTotal * default_country_rate, where default_country_rate = 0.08 (8%) for orders whose BillToAddress joins to a StateProvince with CountryRegionCode in {'US','CA','GB','AU'}. The BillToAddressID in SalesOrderHeader links to Address.AddressID, then Address.StateProvinceID links to StateProvince.StateProvinceID to obtain CountryRegionCode.
# [across_tables], used_tables: ['Address', 'SalesTaxRate']
SELECT
  (target_table.SubTotal * CASE WHEN sp.CountryRegionCode IN ('US','CA','GB','AU') THEN 0.08 ELSE NULL END) AS computed_value,
  target_table.TaxAmt AS actual_value
FROM SalesOrderHeader AS target_table
LEFT JOIN Address AS a ON a.AddressID = target_table.BillToAddressID
LEFT JOIN StateProvince AS sp ON sp.StateProvinceID = a.StateProvinceID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_ScoringSC_pos.csv
# For each ScoringSC row (playerID, year), compute pos as: (1) the Scoring.pos for the same playerID and year that occurs most frequently across that player?s Scoring rows in that year (tie-breaker: largest total GP), (2) if none exists, fall back to Master.pos.
# [across_tables], used_tables: ['Scoring']
SELECT
  COALESCE(year_pos_mode.pos, m.pos) AS computed_value,
  target_table.pos AS actual_value
FROM ScoringSC AS target_table
LEFT JOIN (
  SELECT u.playerID, u.year,
         SUBSTRING_INDEX(GROUP_CONCAT(u.pos ORDER BY u.cnt DESC, u.gp_sum DESC SEPARATOR ','), ',', 1) AS pos
  FROM (
    SELECT s.playerID, s.year, s.pos,
           COUNT(*) AS cnt,
           SUM(CAST(s.GP AS SIGNED)) AS gp_sum
    FROM Scoring s
    WHERE s.pos IS NOT NULL
    GROUP BY s.playerID, s.year, s.pos
  ) AS u
  GROUP BY u.playerID, u.year
) AS year_pos_mode
  ON target_table.playerID = year_pos_mode.playerID
  AND target_table.year = year_pos_mode.year
LEFT JOIN Master AS m
  ON target_table.playerID = m.playerID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_ScoringSC_pos.csv
# For each ScoringSC row (playerID, year,...), compute pos as COALESCE(Master.pos, the most frequent non-null pos for that player in AwardsPlayers, the most frequent non-null pos for that player in ScoringSC).
# [across_tables], used_tables: ['AwardsPlayers']
SELECT
  COALESCE(m.pos, ap_mode.pos, sc_mode.pos) AS computed_value,
  target_table.pos AS actual_value
FROM ScoringSC AS target_table
LEFT JOIN Master AS m
  ON m.playerID = target_table.playerID
LEFT JOIN (
  SELECT playerID, pos
  FROM (
    SELECT playerID, pos, cnt,
           ROW_NUMBER() OVER (PARTITION BY playerID ORDER BY cnt DESC, pos) AS rn
    FROM (
      SELECT playerID, pos, COUNT(*) AS cnt
      FROM AwardsPlayers
      WHERE pos IS NOT NULL
      GROUP BY playerID, pos
    ) ap
  ) ranked_ap
  WHERE rn = 1
) AS ap_mode
  ON ap_mode.playerID = target_table.playerID
LEFT JOIN (
  SELECT playerID, pos
  FROM (
    SELECT playerID, pos, cnt,
           ROW_NUMBER() OVER (PARTITION BY playerID ORDER BY cnt DESC, pos) AS rn
    FROM (
      SELECT playerID, pos, COUNT(*) AS cnt
      FROM ScoringSC
      WHERE pos IS NOT NULL
      GROUP BY playerID, pos
    ) sc
  ) ranked_sc
  WHERE rn = 1
) AS sc_mode
  ON sc_mode.playerID = target_table.playerID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_ScoringSC_pos.csv
# For each ScoringSC row, set pos to the player?s primary position from Master.pos when available; if Master.pos is NULL, set pos to 'G' if the player appears as a goalie (IDgoalie1 or IDgoalie2) in CombinedShutouts for the same year; otherwise leave pos as NULL.
# [across_tables], used_tables: ['CombinedShutouts']
SELECT
  CASE
    WHEN ms.pos IS NOT NULL THEN ms.pos
    WHEN EXISTS (
      SELECT 1
      FROM CombinedShutouts cs
      WHERE cs.year = target_table.year
        AND (cs.IDgoalie1 = target_table.playerID OR cs.IDgoalie2 = target_table.playerID)
    ) THEN 'G'
    ELSE NULL
  END AS computed_value,
  target_table.pos AS actual_value
FROM ScoringSC AS target_table
LEFT JOIN Master AS ms
  ON ms.playerID = target_table.playerID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_CombinedShutouts_tmID.csv
# For each CombinedShutouts row r, let Y = r.year, P1 = r.IDgoalie1, and P2 = r.IDgoalie2. Derive tmID as the unique team T that appears in Goalies for both (P1, Y) and (P2, Y) ? i.e., T is in the intersection of the sets of teams those two goalies are recorded with in that season. Join to Master only to anchor player identities; computation is driven by Goalies.
# [across_tables], used_tables: ['Goalies']
SELECT CASE WHEN g2.tmID IS NOT NULL THEN g1.tmID ELSE NULL END AS computed_value, target_table.tmID AS actual_value FROM CombinedShutouts AS target_table LEFT JOIN Master AS m1 ON m1.playerID = target_table.IDgoalie1 LEFT JOIN Master AS m2 ON m2.playerID = target_table.IDgoalie2 LEFT JOIN (SELECT DISTINCT playerID, year, tmID FROM Goalies) AS g1 ON g1.playerID = target_table.IDgoalie1 AND g1.year = target_table.year LEFT JOIN (SELECT DISTINCT playerID, year, tmID FROM Goalies) AS g2 ON g2.playerID = target_table.IDgoalie2 AND g2.year = target_table.year AND g2.tmID = g1.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_LastEditorDisplayName.csv
# If posts.LastEditorUserId is NULL or <= 0, then LastEditorDisplayName = COALESCE(NULLIF(postHistory.UserDisplayName, ''), users.DisplayName, posts.OwnerDisplayName) taken from the postHistory row where postHistory.PostId = posts.Id and postHistory.CreationDate = posts.LastEditDate. Otherwise (LastEditorUserId > 0), computed LastEditorDisplayName = NULL.
# [across_tables], used_tables: ['users', 'postHistory']
SELECT
  CASE
    WHEN target_table.LastEditorUserId IS NULL OR target_table.LastEditorUserId <= 0 THEN
      COALESCE(NULLIF(ph.UserDisplayName, ''), u.DisplayName, target_table.OwnerDisplayName)
    ELSE NULL
  END AS computed_value,
  target_table.LastEditorDisplayName AS actual_value
FROM posts AS target_table
LEFT JOIN postHistory AS ph
  ON ph.PostId = target_table.Id
 AND ph.CreationDate = target_table.LastEditDate
LEFT JOIN users AS u
  ON u.Id = ph.UserId;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_LastEditorDisplayName.csv
# If LastEditorUserId is a valid linked account (> 0), use users.DisplayName for LastEditorUserId. Otherwise, prefer the most recent comment?s non-null UserDisplayName on the post (regardless of LastEditDate). If none, use posts.OwnerDisplayName; if still null, use users.DisplayName of OwnerUserId.
# [across_tables], used_tables: ['comments', 'users']
SELECT
  CASE
    WHEN target_table.LastEditorUserId IS NOT NULL AND target_table.LastEditorUserId <> -1 THEN le_user.DisplayName
    ELSE COALESCE(lc.UserDisplayName, target_table.OwnerDisplayName, owner_user.DisplayName)
  END AS computed_value,
  target_table.LastEditorDisplayName AS actual_value
FROM posts AS target_table
LEFT JOIN users AS le_user
  ON le_user.Id = target_table.LastEditorUserId
LEFT JOIN users AS owner_user
  ON owner_user.Id = target_table.OwnerUserId
LEFT JOIN (
  SELECT c.PostId, c.UserDisplayName
  FROM comments c
  JOIN (
    SELECT PostId, MAX(CreationDate) AS max_dt
    FROM comments
    WHERE UserDisplayName IS NOT NULL
    GROUP BY PostId
  ) m ON m.PostId = c.PostId AND m.max_dt = c.CreationDate
) AS lc ON lc.PostId = target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_qualifying_number.csv
# For each qualifying row, the car number equals the number recorded for the same driver in the race results of the same event: qualifying.number = results.number where results.raceId = qualifying.raceId and results.driverId = qualifying.driverId.
# [across_tables], used_tables: ['results', 'races']
SELECT rmap.number_value AS computed_value, target_table.number AS actual_value FROM qualifying AS target_table LEFT JOIN (  SELECT r.raceId, r.driverId, MAX(r.number) AS number_value  FROM results AS r  GROUP BY r.raceId, r.driverId) AS rmap  ON rmap.raceId = target_table.raceId AND rmap.driverId = target_table.driverId;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_rOTL.csv
# For each (year, tmID), rOTL = Teams.OTL (team?s total overtime/shootout losses for the season) ? TeamSplits.hOTL (home overtime/shootout losses). In symbols: rOTL(year, tmID) = CAST(Teams.OTL AS SIGNED) ? CAST(TeamSplits.hOTL AS SIGNED).
# [across_tables], used_tables: ['Teams', 'GoaliesShootout']
SELECT
  (CAST(t.OTL AS SIGNED) - CAST(target_table.hOTL AS SIGNED)) AS computed_value,
  target_table.rOTL AS actual_value
FROM TeamSplits AS target_table
LEFT JOIN Teams AS t
  ON t.year = target_table.year
 AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_JanOL.csv
# JanOL = (hOTL + rOTL) - (OctOL + NovOL + DecOL + FebOL + MarOL + AprOL)
# [row_scope]
SELECT (CAST(target_table.hOTL AS SIGNED) + CAST(target_table.rOTL AS SIGNED) - (CAST(target_table.OctOL AS SIGNED) + CAST(target_table.NovOL AS SIGNED) + CAST(target_table.DecOL AS SIGNED) + CAST(target_table.FebOL AS SIGNED) + CAST(target_table.MarOL AS SIGNED) + CAST(target_table.AprOL AS SIGNED))) AS computed_value, target_table.JanOL AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsSC_W.csv
# W = G - L - T
# [row_scope]
SELECT CAST(target_table.G AS SIGNED) - CAST(target_table.L AS SIGNED) - CAST(target_table.T AS SIGNED) AS computed_value, target_table.W AS actual_value FROM TeamsSC AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsSC_W.csv
# For each TeamsSC row (year, tmID, lgID), W equals the sum of the Wins credited to all goalies for that same (year, tmID, lgID) in GoaliesSC: W(team,year,league) = SUM_{GoaliesSC where year, tmID, lgID match}(GoaliesSC.W).
# [across_tables], used_tables: ['GoaliesSC', 'Teams']
SELECT gs.total_goalie_wins AS computed_value, target_table.W AS actual_value
FROM TeamsSC AS target_table
LEFT JOIN (
  SELECT year, tmID, lgID, SUM(CAST(W AS SIGNED)) AS total_goalie_wins
  FROM GoaliesSC
  GROUP BY year, tmID, lgID
) AS gs
  ON target_table.year = gs.year
  AND target_table.tmID = gs.tmID
  AND target_table.lgID = gs.lgID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsSC_W.csv
# For each TeamsSC row (year, lgID, tmID), W equals the sum of games won by that team in all Stanley Cup rounds labeled SCF and SCSF in SeriesPost. Count wins directly from SeriesPost.W when the team is the series winner (match on year, tmIDWinner, lgIDWinner), and count wins as SeriesPost.L when the team is the series loser (match on year, tmIDLoser, lgIDLoser). Thus: W = SUM_over_round?{SCF,SCSF}[ (team as winner) W + (team as loser) L ].
# [across_tables], used_tables: ['SeriesPost']
SELECT CAST(COALESCE(winner_tot.total_wins, 0) + COALESCE(loser_tot.total_wins, 0) AS SIGNED) AS computed_value, target_table.W AS actual_value FROM TeamsSC AS target_table LEFT JOIN ( SELECT sp.year, sp.tmIDWinner AS tmID, sp.lgIDWinner AS lgID, SUM(CAST(sp.W AS SIGNED)) AS total_wins FROM SeriesPost sp WHERE sp.round IN ('SCF', 'SCSF') GROUP BY sp.year, sp.tmIDWinner, sp.lgIDWinner ) AS winner_tot ON target_table.year = winner_tot.year AND target_table.tmID = winner_tot.tmID AND target_table.lgID = winner_tot.lgID LEFT JOIN ( SELECT sp.year, sp.tmIDLoser AS tmID, sp.lgIDLoser AS lgID, SUM(CAST(sp.L AS SIGNED)) AS total_wins FROM SeriesPost sp WHERE sp.round IN ('SCF', 'SCSF') GROUP BY sp.year, sp.tmIDLoser, sp.lgIDLoser ) AS loser_tot ON target_table.year = loser_tot.year AND target_table.tmID = loser_tot.tmID AND target_table.lgID = loser_tot.lgID;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Customer_City.csv
# For each customer c, compute City as the BillingCity that appears most frequently among all invoices where Invoice.CustomerId = c.CustomerId and BillingCity is not null. If multiple cities tie for highest frequency, pick the one with the most recent InvoiceDate; if still tied, pick the lexicographically smallest BillingCity.
# [across_tables], used_tables: ['Invoice']
WITH city_stats AS (
  SELECT i.CustomerId, i.BillingCity, COUNT(*) AS cnt, MAX(i.InvoiceDate) AS max_date
  FROM Invoice i
  WHERE i.BillingCity IS NOT NULL
  GROUP BY i.CustomerId, i.BillingCity
),
best_city AS (
  SELECT CustomerId, BillingCity,
         ROW_NUMBER() OVER (
           PARTITION BY CustomerId
           ORDER BY cnt DESC, max_date DESC, BillingCity ASC
         ) AS rn
  FROM city_stats
)
SELECT best_city.BillingCity AS computed_value, target_table.City AS actual_value
FROM Customer AS target_table
LEFT JOIN best_city
  ON best_city.CustomerId = target_table.CustomerId AND best_city.rn = 1
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Customer_City.csv
# For each customer c, compute City as the BillingCity from the customer?s most recent invoice by InvoiceDate among invoices with Invoice.CustomerId = c.CustomerId and BillingCity not null. If multiple invoices share that maximum date, choose the one with the greatest InvoiceId.
# [across_tables], used_tables: ['Invoice']
WITH ranked_invoices AS (
  SELECT i.CustomerId, i.BillingCity,
         ROW_NUMBER() OVER (
           PARTITION BY i.CustomerId
           ORDER BY i.InvoiceDate DESC, i.InvoiceId DESC
         ) AS rn
  FROM Invoice i
  WHERE i.BillingCity IS NOT NULL
)
SELECT ranked_invoices.BillingCity AS computed_value, target_table.City AS actual_value
FROM Customer AS target_table
LEFT JOIN ranked_invoices
  ON ranked_invoices.CustomerId = target_table.CustomerId AND ranked_invoices.rn = 1
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_PostthreeMade.csv
# PostthreeMade = PostPoints - 2 * PostfgMade - PostftMade
# [row_scope]
SELECT CAST(target_table.PostPoints AS SIGNED) - 2 * CAST(target_table.PostfgMade AS SIGNED) - CAST(target_table.PostftMade AS SIGNED) AS computed_value, target_table.PostthreeMade AS actual_value FROM players_teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_PostthreeMade.csv
# Estimate PostthreeMade from a player?s regular-season three-point tendency, gated by the league?s three-point era as learned from player_allstar. Define L3_start[league] as in Candidate 1. For players_teams row (playerID, year, lgID): if year < L3_start[lgID], then PostthreeMade = 0. Otherwise, if fgMade, threeMade, and PostfgMade are known, compute PostthreeMade ? PostfgMade ? (threeMade / fgMade). If PostthreeAttempted is known, cap the estimate at PostthreeAttempted. If PostthreeAttempted = 0, set PostthreeMade = 0. If inputs are missing in the three-point era, return NULL.
# [across_tables], used_tables: ['player_allstar']
SELECT
  CASE
    WHEN l3.min_season_with_3pt IS NOT NULL AND target_table.year >= l3.min_season_with_3pt
         AND target_table.fgMade IS NOT NULL
         AND target_table.threeMade IS NOT NULL
         AND target_table.PostfgMade IS NOT NULL
      THEN
        CASE
          WHEN target_table.PostthreeAttempted IS NOT NULL
            THEN LEAST(
                   CAST(target_table.PostthreeAttempted AS SIGNED),
                   CAST(
                     CAST(target_table.PostfgMade AS DECIMAL(18,6))
                     * (CAST(target_table.threeMade AS DECIMAL(18,6)) / NULLIF(CAST(target_table.fgMade AS DECIMAL(18,6)),0))
                   AS SIGNED)
                 )
          ELSE CAST(
                 CAST(target_table.PostfgMade AS DECIMAL(18,6))
                 * (CAST(target_table.threeMade AS DECIMAL(18,6)) / NULLIF(CAST(target_table.fgMade AS DECIMAL(18,6)),0))
               AS SIGNED)
        END
    WHEN l3.min_season_with_3pt IS NOT NULL AND target_table.year < l3.min_season_with_3pt
      THEN 0
    WHEN target_table.PostthreeAttempted = 0
      THEN 0
    ELSE NULL
  END AS computed_value,
  target_table.PostthreeMade AS actual_value
FROM players_teams AS target_table
LEFT JOIN (
  SELECT league_id AS lgID, MIN(season_id) AS min_season_with_3pt
  FROM player_allstar
  WHERE three_attempted IS NOT NULL OR three_made IS NOT NULL
  GROUP BY league_id
) AS l3
  ON l3.lgID = target_table.lgID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_GF.csv
# For each TeamsPost row (year, lgID, tmID), GF equals the sum of goals this team scored across all playoff series that season regardless of opponent league: sum over SeriesPost where year matches of (GoalsWinner when tmID = tmIDWinner) plus (GoalsLoser when tmID = tmIDLoser).
# [across_tables], used_tables: ['SeriesPost', 'Goalies']
SELECT CAST(COALESCE(w.sum_goals,0) AS SIGNED) + CAST(COALESCE(l.sum_goals,0) AS SIGNED) AS computed_value, target_table.GF AS actual_value FROM TeamsPost target_table LEFT JOIN (SELECT year, tmIDWinner AS tmID, SUM(GoalsWinner) AS sum_goals FROM SeriesPost GROUP BY year, tmIDWinner) AS w ON w.year = target_table.year AND w.tmID = target_table.tmID LEFT JOIN (SELECT year, tmIDLoser AS tmID, SUM(GoalsLoser) AS sum_goals FROM SeriesPost GROUP BY year, tmIDLoser) AS l ON l.year = target_table.year AND l.tmID = target_table.tmID
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_tid2_loc.csv
# tid2_loc = CASE WHEN tid2 = h_tid THEN 'h' ELSE 'a' END
# [row_scope]
SELECT CASE WHEN target_table.tid2 = target_table.h_tid THEN 'h' ELSE 'a' END AS computed_value, target_table.tid2_loc AS actual_value FROM matches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_races_url.csv
# url = (CASE WHEN year >= 2016 THEN 'https' ELSE 'http' END) || '://en.wikipedia.org/wiki/' || CAST(year AS TEXT) || '_' || REPLACE(name, ' ', '_')
# [row_scope]
SELECT CONCAT(CASE WHEN target_table.`year` >= 2016 THEN 'https' ELSE 'http' END, '://en.wikipedia.org/wiki/', CAST(target_table.`year` AS CHAR), '_', REPLACE(target_table.`name`, ' ', '_')) AS computed_value, target_table.`url` AS actual_value FROM races AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_OctW.csv
# OctW = (hW + rW) - (COALESCE(SepW,0) + COALESCE(NovW,0) + COALESCE(DecW,0) + COALESCE(JanW,0) + COALESCE(FebW,0) + COALESCE(MarW,0) + COALESCE(AprW,0))
# [row_scope]
SELECT (CAST(target_table.hW AS SIGNED) + CAST(target_table.rW AS SIGNED)) - (COALESCE(CAST(target_table.SepW AS SIGNED), 0) + COALESCE(CAST(target_table.NovW AS SIGNED), 0) + COALESCE(CAST(target_table.DecW AS SIGNED), 0) + COALESCE(CAST(target_table.JanW AS SIGNED), 0) + COALESCE(CAST(target_table.FebW AS SIGNED), 0) + COALESCE(CAST(target_table.MarW AS SIGNED), 0) + COALESCE(CAST(target_table.AprW AS SIGNED), 0)) AS computed_value, target_table.OctW AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_constructorStandings_points.csv
# For each constructorStandings row (race R, constructor C), points equals the cumulative sum of constructorResults.points for constructor C over all races in the same season (same races.year as R) whose round is less than or equal to R.round. Formally: points(C, R) = SUM over r where r.year = R.year and r.round <= R.round of constructorResults(C, r).points.
# [across_tables], used_tables: ['constructorResults', 'races']
SELECT
  cum.total_points AS computed_value,
  target_table.points AS actual_value
FROM constructorStandings AS target_table
LEFT JOIN (
  SELECT
    r0.raceId AS raceId,
    cr.constructorId AS constructorId,
    SUM(cr.points) AS total_points
  FROM races AS r0
  JOIN races AS r2
    ON r2.year = r0.year
   AND r2.round <= r0.round
  JOIN constructorResults AS cr
    ON cr.raceId = r2.raceId
  GROUP BY r0.raceId, cr.constructorId
) AS cum
  ON cum.raceId = target_table.raceId
 AND cum.constructorId = target_table.constructorId;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_constructorStandings_points.csv
# For each constructorStandings row (constructorId C, raceId R), points equals the cumulative sum, across all races in the same season up to and including the round of R, of the single best (maximum) points scored by any driver of constructor C in each race. Formally: points(C, R) = SUM over races r in season_of(R) with round(r) <= round(R) of (MAX over drivers d of constructor C in race r of results.points).
# [across_tables], used_tables: ['results', 'races']
SELECT
  computed.cum_points AS computed_value,
  target_table.points AS actual_value
FROM constructorStandings AS target_table
JOIN races AS rt
  ON rt.raceId = target_table.raceId
LEFT JOIN (
  SELECT
    per_race_max.constructorId,
    r2.year AS target_year,
    r2.round AS target_round,
    SUM(per_race_max.max_pts) AS cum_points
  FROM (
    SELECT
      r.constructorId,
      r.raceId,
      MAX(r.points) AS max_pts
    FROM results r
    GROUP BY r.constructorId, r.raceId
  ) AS per_race_max
  JOIN races r1
    ON r1.raceId = per_race_max.raceId
  JOIN races r2
    ON r2.year = r1.year
   AND r1.round <= r2.round
  GROUP BY per_race_max.constructorId, r2.year, r2.round
) AS computed
  ON computed.constructorId = target_table.constructorId
 AND computed.target_year = rt.year
 AND computed.target_round = rt.round;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_series_post_lgIDWinner.csv
# lgIDWinner = lgIDLoser
# [row_scope]
SELECT `target_table`.`lgIDLoser` AS `computed_value`, `target_table`.`lgIDWinner` AS `actual_value` FROM `series_post` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_series_post_lgIDWinner.csv
# lgIDWinner = CASE WHEN year < 1977 THEN 'ABA' ELSE 'NBA' END
# [row_scope]
SELECT CASE WHEN target_table.`year` < 1977 THEN 'ABA' ELSE 'NBA' END AS computed_value, target_table.`lgIDWinner` AS actual_value FROM `series_post` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_uni_Enrollment_passed.csv
# Within each course, compute K = floor(pass_rate * number_of_enrollments_in_that_course). Order all enrollments for that course by grade descending (tie-breaker: std_id descending). Set passed = 1 for the top K enrollments in that order; set passed = 0 for the remaining enrollments.
# [across_tables], used_tables: ['Course']
SELECT CASE WHEN ranked.rn <= ktab.k THEN 1 ELSE 0 END AS computed_value, target_table.passed AS actual_value FROM Enrollment AS target_table JOIN ( SELECT e.std_id, e.course_id, ROW_NUMBER() OVER (PARTITION BY e.course_id ORDER BY e.grade DESC, e.std_id DESC) AS rn FROM Enrollment e ) AS ranked ON ranked.std_id = target_table.std_id AND ranked.course_id = target_table.course_id JOIN ( SELECT ec.course_id, FLOOR(CAST(ec.n_enr AS DECIMAL(20,6)) * CAST(c.pass_rate AS DECIMAL(20,6))) AS k FROM ( SELECT course_id, COUNT(*) AS n_enr FROM Enrollment GROUP BY course_id ) ec JOIN Course c ON c.course_id = ec.course_id ) AS ktab ON ktab.course_id = target_table.course_id;
###########################################################

###########################################################
# filtered_reported_accuracy_uni_Enrollment_passed.csv
# passed = CAST(grade >= 3.0 AS INT)
# [row_scope]
SELECT CAST((target_table.grade >= 3.0) AS SIGNED) AS computed_value,
       target_table.passed AS actual_value
FROM Enrollment AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_uni_Enrollment_passed.csv
# passed = CAST(grade >= AVG(grade) OVER (PARTITION BY course_id) AS INT)
# [row_scope]
SELECT CAST(target_table.grade >= AVG(target_table.grade) OVER (PARTITION BY target_table.course_id) AS UNSIGNED) AS computed_value, target_table.passed AS actual_value FROM Enrollment AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_W.csv
# W = G - L - T
# [row_scope]
SELECT (CAST(target_table.G AS SIGNED) - CAST(target_table.L AS SIGNED) - CAST(target_table.T AS SIGNED)) AS computed_value, target_table.W AS actual_value FROM TeamsPost AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_W.csv
# For a given TeamsPost row (year, tmID), W equals the sum of all goaltender playoff wins credited to that team and season in Goalies: sum of Goalies.PostW where (year, tmID) match the team-season.
# [across_tables], used_tables: ['SeriesPost', 'Goalies']
SELECT COALESCE(`goalie_wins`.`value`,0) AS `computed_value`, `target_table`.`W` AS `actual_value` FROM `TeamsPost` AS `target_table` LEFT JOIN (SELECT `year`, `tmID`, SUM(CAST(`PostW` AS SIGNED)) AS `value` FROM `Goalies` GROUP BY `year`, `tmID`) AS `goalie_wins` ON `goalie_wins`.`year` = `target_table`.`year` AND `goalie_wins`.`tmID` = `target_table`.`tmID`;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_constructorResults_points.csv
# For a given constructor and race, constructorResults.points equals the difference between constructorStandings points at the current round and the points at the immediately preceding round (round ? 1) in the same season year; if no prior round exists, use 0.
# [across_tables], used_tables: ['constructorStandings', 'races']
SELECT
  (curr.curr_points - COALESCE(prev.prev_points, 0)) AS computed_value,
  target_table.points AS actual_value
FROM constructorResults AS target_table
JOIN (
  SELECT cs.constructorId, cs.raceId, r.year, r.round, cs.points AS curr_points
  FROM constructorStandings cs
  JOIN races r ON r.raceId = cs.raceId
) AS curr
  ON curr.constructorId = target_table.constructorId
 AND curr.raceId = target_table.raceId
LEFT JOIN (
  SELECT cs.constructorId, r.year, r.round, cs.points AS prev_points
  FROM constructorStandings cs
  JOIN races r ON r.raceId = cs.raceId
) AS prev
  ON prev.constructorId = curr.constructorId
 AND prev.year = curr.year
 AND prev.round = curr.round - 1;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_constructorResults_points.csv
# For each row in constructorResults (by raceId, constructorId), the constructor?s points equal the sum of points scored by all drivers of that constructor in that race, i.e., SUM(results.points) grouped by (raceId, constructorId).
# [across_tables], used_tables: ['results', 'status']
SELECT COALESCE(r_sum.value, 0) AS computed_value, target_table.points AS actual_value
FROM constructorResults AS target_table
LEFT JOIN (
  SELECT raceId, constructorId, SUM(points) AS value
  FROM results
  GROUP BY raceId, constructorId
) AS r_sum
  ON r_sum.raceId = target_table.raceId AND r_sum.constructorId = target_table.constructorId;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_player_allstar_last_name.csv
# For each row in player_allstar, set last_name to players.lastName by joining players on player_allstar.playerID = players.playerID.
# [across_tables], used_tables: ['players', 'awards_players']
SELECT p.lastName AS computed_value, target_table.last_name AS actual_value
FROM player_allstar AS target_table
LEFT JOIN players AS p ON p.playerID = target_table.playerID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_ftMade.csv
# ftMade = points - (2 * fgMade) - threeMade
# [row_scope]
SELECT (CAST(target_table.points AS SIGNED) - (CAST(target_table.fgMade AS SIGNED) * 2) - CAST(target_table.threeMade AS SIGNED)) AS computed_value, target_table.ftMade AS actual_value FROM players_teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_target.csv
# target = 1 if win_tid == tid1 else 0
# [row_scope]
SELECT CASE WHEN target_table.`win_tid` = target_table.`tid1` THEN 1 ELSE 0 END AS `computed_value`, target_table.`target` AS `actual_value` FROM `matches` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_target.csv
# For each match mid, compute each team?s total points from match_stats as sum(6*GL + BH) grouped by (mid, tid). Then target = 1 if tid1?s computed points > tid2?s computed points; otherwise target = 0.
# [across_tables], used_tables: ['match_stats']
SELECT CASE WHEN COALESCE(tid1_scores.score, 0) > COALESCE(tid2_scores.score, 0) THEN 1 ELSE 0 END AS computed_value, target_table.target AS actual_value FROM matches AS target_table LEFT JOIN ( SELECT ms.mid, ms.tid, SUM(CAST(ms.GL AS SIGNED) * 6 + CAST(ms.BH AS SIGNED)) AS score FROM match_stats AS ms GROUP BY ms.mid, ms.tid ) AS tid1_scores ON tid1_scores.mid = target_table.mid AND tid1_scores.tid = target_table.tid1 LEFT JOIN ( SELECT ms.mid, ms.tid, SUM(CAST(ms.GL AS SIGNED) * 6 + CAST(ms.BH AS SIGNED)) AS score FROM match_stats AS ms GROUP BY ms.mid, ms.tid ) AS tid2_scores ON tid2_scores.mid = target_table.mid AND tid2_scores.tid = target_table.tid2;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_SHF.csv
# For each team-season (Teams.year, Teams.lgID, Teams.tmID), SHF equals the sum of all players? regular-season shorthanded goals (Scoring.SHG) recorded for that same team-season. In other words: SHF(Teams) = SUM_{Scoring where year=Teams.year AND lgID=Teams.lgID AND tmID=Teams.tmID} (SHG).
# [across_tables], used_tables: ['TeamsPost', 'Scoring']
SELECT COALESCE(reg_shg.value, 0) AS computed_value, target_table.SHF AS actual_value FROM Teams AS target_table LEFT JOIN (  SELECT year, lgID, tmID, SUM(CAST(SHG AS SIGNED)) AS value  FROM Scoring  WHERE SHG IS NOT NULL  GROUP BY year, lgID, tmID ) AS reg_shg  ON reg_shg.year = target_table.year AND reg_shg.lgID = target_table.lgID AND reg_shg.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_FebT.csv
# FebT = COALESCE(hT, 0) + COALESCE(rT, 0) - (COALESCE(SepT, 0) + COALESCE(OctT, 0) + COALESCE(NovT, 0) + COALESCE(DecT, 0) + COALESCE(JanT, 0) + COALESCE(MarT, 0) + COALESCE(AprT, 0))
# [row_scope]
SELECT COALESCE(CAST(target_table.hT AS SIGNED), 0) + COALESCE(CAST(target_table.rT AS SIGNED), 0) - (COALESCE(CAST(target_table.SepT AS SIGNED), 0) + COALESCE(CAST(target_table.OctT AS SIGNED), 0) + COALESCE(CAST(target_table.NovT AS SIGNED), 0) + COALESCE(CAST(target_table.DecT AS SIGNED), 0) + COALESCE(CAST(target_table.JanT AS SIGNED), 0) + COALESCE(CAST(target_table.MarT AS SIGNED), 0) + COALESCE(CAST(target_table.AprT AS SIGNED), 0)) AS computed_value, target_table.FebT AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_coaches_post_losses.csv
# For a coach?s team-year (tmID, lgID, year), playoff losses equal the sum of: (a) the number of games the team lost in all series it won, which is SUM(series_post.L) where tmIDWinner = team, plus (b) the number of games the team lost in all series it lost, which is SUM(series_post.W) where tmIDLoser = team. Formally: post_losses(tmID, lgID, year) = SUM_L_as_winner(tmIDWinner = tmID, lgIDWinner = lgID, year) + SUM_W_as_loser(tmIDLoser = tmID, lgIDLoser = lgID, year).
# [across_tables], used_tables: ['series_post', 'teams']
SELECT CAST(COALESCE(s_win.sum_losses_as_winner, 0) + COALESCE(s_lose.sum_losses_as_loser, 0) AS SIGNED) AS computed_value, target_table.post_losses AS actual_value FROM coaches AS target_table LEFT JOIN ( SELECT tmIDWinner AS tmID, lgIDWinner AS lgID, year, CAST(SUM(L) AS SIGNED) AS sum_losses_as_winner FROM series_post WHERE year IS NOT NULL GROUP BY tmIDWinner, lgIDWinner, year ) AS s_win ON s_win.tmID = target_table.tmID AND s_win.lgID = target_table.lgID AND s_win.year = target_table.year LEFT JOIN ( SELECT tmIDLoser AS tmID, lgIDLoser AS lgID, year, CAST(SUM(W) AS SIGNED) AS sum_losses_as_loser FROM series_post WHERE year IS NOT NULL GROUP BY tmIDLoser, lgIDLoser, year ) AS s_lose ON s_lose.tmID = target_table.tmID AND s_lose.lgID = target_table.lgID AND s_lose.year = target_table.year
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_player_allstar_fg_made.csv
# fg_made = (points - COALESCE(ft_made, 0) - COALESCE(three_made, 0)) / 2
# [row_scope]
SELECT (CAST(target_table.points AS SIGNED) - CAST(COALESCE(target_table.ft_made, 0) AS SIGNED) - CAST(COALESCE(target_table.three_made, 0) AS SIGNED)) / 2 AS computed_value, target_table.fg_made AS actual_value FROM player_allstar AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Employee_FirstName.csv
# FirstName = ProperCase(local_part(Email)) where local_part(Email) = substring of Email before the first '@'
# [row_scope]
SELECT CONCAT(UPPER(LEFT(SUBSTRING_INDEX(target_table.Email, '@', 1), 1)), LOWER(SUBSTRING(SUBSTRING_INDEX(target_table.Email, '@', 1), 2))) AS computed_value, target_table.FirstName AS actual_value FROM Employee AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrder_DueDate.csv
# DueDate(work_order_id, product_id) = MAX(WorkOrderRouting.ScheduledEndDate) for all routing steps where WorkOrderRouting.WorkOrderID = work_order_id and WorkOrderRouting.ProductID = product_id.
# [across_tables], used_tables: ['WorkOrderRouting']
SELECT
  planned_end.computed_value AS computed_value,
  target_table.DueDate AS actual_value
FROM WorkOrder AS target_table
LEFT JOIN (
  SELECT
    WorkOrderID,
    ProductID,
    MAX(ScheduledEndDate) AS computed_value
  FROM WorkOrderRouting
  GROUP BY WorkOrderID, ProductID
) AS planned_end
  ON planned_end.WorkOrderID = target_table.WorkOrderID
 AND planned_end.ProductID = target_table.ProductID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrder_DueDate.csv
# DueDate = DATE(WorkOrder.StartDate) + INTERVAL L DAY, where L is the average lead time in days computed as AVG(DATEDIFF(WorkOrder.DueDate, WorkOrder.StartDate)) over all WorkOrder rows for products sharing the same ProductModelID (via WorkOrder JOIN Product). If the ProductModelID is NULL or has no history, fall back to the overall average lead time across all WorkOrders.
# [across_tables], used_tables: ['Product']
SELECT
  DATE_ADD(DATE(target_table.StartDate), INTERVAL CAST(COALESCE(pm_lead.avg_days, global_lead.avg_days) AS SIGNED) DAY) AS computed_value,
  target_table.DueDate AS actual_value
FROM WorkOrder AS target_table
LEFT JOIN Product p ON p.ProductID = target_table.ProductID
LEFT JOIN (
  SELECT
    p2.ProductModelID,
    AVG(DATEDIFF(w2.DueDate, w2.StartDate)) AS avg_days
  FROM WorkOrder w2
  JOIN Product p2 ON p2.ProductID = w2.ProductID
  WHERE w2.DueDate IS NOT NULL
  GROUP BY p2.ProductModelID
) AS pm_lead
  ON pm_lead.ProductModelID = p.ProductModelID
LEFT JOIN (
  SELECT AVG(DATEDIFF(w3.DueDate, w3.StartDate)) AS avg_days
  FROM WorkOrder w3
  WHERE w3.DueDate IS NOT NULL
) AS global_lead ON 1=1;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_constructorStandings_wins.csv
# nan
# [count_or_exist with data sharing], given_table_name = results
SELECT
  COALESCE(COUNT(DISTINCT res_wins.raceId), 0) AS computed_value,
  target_table.wins AS actual_value
FROM constructorStandings AS target_table
LEFT JOIN races AS r_cur
  ON r_cur.raceId = target_table.raceId
LEFT JOIN races AS r2
  ON r2.year = r_cur.year
 AND r2.round <= r_cur.round
LEFT JOIN results AS res_wins
  ON res_wins.raceId = r2.raceId
 AND res_wins.constructorId = target_table.constructorId
 AND res_wins.positionOrder = 1
GROUP BY target_table.constructorStandingsId, target_table.wins
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrderRouting_ScheduledEndDate.csv
# ScheduledEndDate = DATEADD(day, 11, ScheduledStartDate)
# [row_scope]
SELECT DATE_ADD(target_table.ScheduledStartDate, INTERVAL 11 DAY) AS computed_value, target_table.ScheduledEndDate AS actual_value FROM WorkOrderRouting AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrderRouting_ScheduledEndDate.csv
# For each WorkOrderRouting row, ScheduledEndDate equals the DueDate of its parent work order: ScheduledEndDate = WorkOrder.DueDate where WorkOrder.WorkOrderID = WorkOrderRouting.WorkOrderID.
# [across_tables], used_tables: ['WorkOrder']
SELECT w.DueDate AS computed_value, target_table.ScheduledEndDate AS actual_value FROM WorkOrderRouting AS target_table INNER JOIN WorkOrder AS w ON w.WorkOrderID = target_table.WorkOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_NovW.csv
# NovW = (hW + rW) - (OctW + DecW + JanW + FebW + MarW + AprW)
# [row_scope]
SELECT (CAST(COALESCE(target_table.hW, 0) AS SIGNED) + CAST(COALESCE(target_table.rW, 0) AS SIGNED)) - (CAST(COALESCE(target_table.OctW, 0) AS SIGNED) + CAST(COALESCE(target_table.DecW, 0) AS SIGNED) + CAST(COALESCE(target_table.JanW, 0) AS SIGNED) + CAST(COALESCE(target_table.FebW, 0) AS SIGNED) + CAST(COALESCE(target_table.MarW, 0) AS SIGNED) + CAST(COALESCE(target_table.AprW, 0) AS SIGNED)) AS computed_value, target_table.NovW AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_hOTL.csv
# hOTL = COALESCE(SepOL, 0) + COALESCE(OctOL, 0) + COALESCE(NovOL, 0) + COALESCE(DecOL, 0) + COALESCE(JanOL, 0) + COALESCE(FebOL, 0) + COALESCE(MarOL, 0) + COALESCE(AprOL, 0) - COALESCE(rOTL, 0)
# [row_scope]
SELECT (CAST(COALESCE(target_table.SepOL, 0) AS SIGNED) + CAST(COALESCE(target_table.OctOL, 0) AS SIGNED) + CAST(COALESCE(target_table.NovOL, 0) AS SIGNED) + CAST(COALESCE(target_table.DecOL, 0) AS SIGNED) + CAST(COALESCE(target_table.JanOL, 0) AS SIGNED) + CAST(COALESCE(target_table.FebOL, 0) AS SIGNED) + CAST(COALESCE(target_table.MarOL, 0) AS SIGNED) + CAST(COALESCE(target_table.AprOL, 0) AS SIGNED) - CAST(COALESCE(target_table.rOTL, 0) AS SIGNED)) AS computed_value, target_table.hOTL AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_hOTL.csv
# hOTL = (COALESCE(rW, 0) + COALESCE(rL, 0) + COALESCE(rT, 0) + COALESCE(rOTL, 0)) - (COALESCE(hW, 0) + COALESCE(hL, 0) + COALESCE(hT, 0))
# [row_scope]
SELECT CAST((COALESCE(CAST(target_table.rW AS SIGNED), 0) + COALESCE(CAST(target_table.rL AS SIGNED), 0) + COALESCE(CAST(target_table.rT AS SIGNED), 0) + COALESCE(CAST(target_table.rOTL AS SIGNED), 0)) - (COALESCE(CAST(target_table.hW AS SIGNED), 0) + COALESCE(CAST(target_table.hL AS SIGNED), 0) + COALESCE(CAST(target_table.hT AS SIGNED), 0)) AS SIGNED) AS computed_value, target_table.hOTL AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderDetail_RejectedQty.csv
# RejectedQty = ReceivedQty - StockedQty
# [row_scope]
SELECT CAST(target_table.ReceivedQty AS DECIMAL(65,30)) - CAST(target_table.StockedQty AS DECIMAL(65,30)) AS computed_value, target_table.RejectedQty AS actual_value FROM PurchaseOrderDetail AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_PTE_pte_atm_count_Cnt.csv
# nan
# [count_or_exist without data sharing], given_table_name = pte_atm
select pte_atm_count.Arg0, pte_atm_count.Cnt actual_value, Count(*) computed_value from  `pte_atm_count` 
LEFT JOIN pte_drug ON `pte_drug`.`drug_id` = `pte_atm_count`.`Arg0`
LEFT JOIN pte_atm ON `pte_atm`.`drug_id` = `pte_drug`.`drug_id` group by pte_atm_count.Arg0, pte_atm_count.Cnt
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderDetail_LineTotal.csv
# LineTotal = OrderQty * UnitPrice * (1 - UnitPriceDiscount)
# [row_scope]
SELECT (CAST(target_table.OrderQty AS DECIMAL(38,6)) * CAST(target_table.UnitPrice AS DECIMAL(38,6)) * (CAST(1 AS DECIMAL(38,6)) - CAST(target_table.UnitPriceDiscount AS DECIMAL(38,6)))) AS computed_value, target_table.LineTotal AS actual_value FROM SalesOrderDetail AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Scoring_Pts.csv
# Pts = G + A
# [row_scope]
SELECT (CAST(target_table.G AS SIGNED) + CAST(target_table.A AS SIGNED)) AS computed_value, target_table.Pts AS actual_value FROM Scoring AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrderRouting_ActualResourceHrs.csv
# ActualResourceHrs = ActualCost / Location.CostRate, joined by WorkOrderRouting.LocationID = Location.LocationID
# [across_tables], used_tables: ['Location']
SELECT (target_table.ActualCost / loc.CostRate) AS computed_value, target_table.ActualResourceHrs AS actual_value FROM WorkOrderRouting AS target_table INNER JOIN Location AS loc ON loc.LocationID = target_table.LocationID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrderRouting_ActualResourceHrs.csv
# For a given WorkOrderRouting row, compute ActualResourceHrs as the historical average ActualResourceHrs over all WorkOrderRouting rows that share the same OperationSequence and the same Product.DaysToManufacture (joined via Product.ProductID).
# [across_tables], used_tables: ['Product', 'WorkOrder']
SELECT std.computed_value AS computed_value, target_table.ActualResourceHrs AS actual_value FROM WorkOrderRouting AS target_table JOIN Product AS p ON p.ProductID = target_table.ProductID LEFT JOIN ( SELECT wr2.OperationSequence, p2.DaysToManufacture, AVG(wr2.ActualResourceHrs) AS computed_value FROM WorkOrderRouting wr2 JOIN Product p2 ON p2.ProductID = wr2.ProductID WHERE wr2.ActualResourceHrs IS NOT NULL GROUP BY wr2.OperationSequence, p2.DaysToManufacture ) AS std ON std.OperationSequence = target_table.OperationSequence AND std.DaysToManufacture = p.DaysToManufacture;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_WorkOrderRouting_ActualResourceHrs.csv
# For each routing row: If it is the final operation step in its work order (OperationSequence = MAX(OperationSequence) for that WorkOrderID), then ActualResourceHrs = Product.DaysToManufacture + (1 if the product appears as a component in BillOfMaterials with a non-null ProductAssemblyID, else 0). Otherwise, derive ActualResourceHrs by dividing ActualCost by the learned per-hour rate for that (LocationID, OperationSequence), where the rate is AVG(PlannedCost / ActualResourceHrs) computed over WorkOrderRouting rows with non-null ActualResourceHrs.
# [across_tables], used_tables: ['WorkOrder', 'BillOfMaterials']
SELECT
  CASE
    WHEN target_table.OperationSequence = max_seq.max_seq THEN CAST(p.DaysToManufacture AS DECIMAL(19,4)) + CAST(CASE WHEN bom.ComponentID IS NOT NULL THEN 1 ELSE 0 END AS DECIMAL(19,4))
    ELSE target_table.ActualCost / rate.rate_per_hour
  END AS computed_value,
  target_table.ActualResourceHrs AS actual_value
FROM WorkOrderRouting AS target_table
LEFT JOIN (
  SELECT WorkOrderID, MAX(OperationSequence) AS max_seq
  FROM WorkOrderRouting
  GROUP BY WorkOrderID
) AS max_seq ON max_seq.WorkOrderID = target_table.WorkOrderID
LEFT JOIN Product AS p ON p.ProductID = target_table.ProductID
LEFT JOIN (
  SELECT ComponentID
  FROM BillOfMaterials
  WHERE ProductAssemblyID IS NOT NULL
  GROUP BY ComponentID
) AS bom ON bom.ComponentID = target_table.ProductID
LEFT JOIN (
  SELECT LocationID, OperationSequence, AVG(PlannedCost / ActualResourceHrs) AS rate_per_hour
  FROM WorkOrderRouting
  WHERE ActualResourceHrs IS NOT NULL AND PlannedCost IS NOT NULL
  GROUP BY LocationID, OperationSequence
) AS rate ON rate.LocationID = target_table.LocationID AND rate.OperationSequence = target_table.OperationSequence;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_SellEndDate.csv
# For each product p, SellEndDate = MAX(EndDate) over all rows in ProductCostHistory where ProductCostHistory.ProductID = p.ProductID. If no such row exists or all EndDate values are NULL, the computed SellEndDate is NULL.
# [across_tables], used_tables: ['ProductCostHistory']
SELECT
  pch_max.max_end_date AS computed_value,
  target_table.SellEndDate AS actual_value
FROM Product AS target_table
LEFT JOIN (
  SELECT ProductID, MAX(EndDate) AS max_end_date
  FROM ProductCostHistory
  GROUP BY ProductID
) AS pch_max
  ON pch_max.ProductID = target_table.ProductID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_SellEndDate.csv
# SellEndDate = DATEADD(day, -2, EOMONTH(DATEADD(month, 12, SellStartDate)))
# [row_scope]
SELECT CAST(DATE_SUB(LAST_DAY(DATE_ADD(target_table.SellStartDate, INTERVAL 12 MONTH)), INTERVAL 2 DAY) AS DATETIME) AS computed_value, target_table.SellEndDate AS actual_value FROM Product AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_SellEndDate.csv
# For each product p, compute first_sale_date = MIN(SalesOrderDetail.ModifiedDate) over all sales lines where SalesOrderDetail.ProductID = p and (SalesOrderDetail.SpecialOfferID, SalesOrderDetail.ProductID) matches a row in SpecialOfferProduct. Then derive SellEndDate as first_sale_date plus 364 days: SellEndDate(p) = DATE_ADD(DATE(first_sale_date), INTERVAL 364 DAY).
# [across_tables], used_tables: ['SalesOrderDetail']
SELECT
  DATE_ADD(DATE(esd.first_sale_dt), INTERVAL 364 DAY) AS computed_value,
  target_table.SellEndDate AS actual_value
FROM Product AS target_table
LEFT JOIN (
  SELECT sod.ProductID, MIN(sod.ModifiedDate) AS first_sale_dt
  FROM SalesOrderDetail AS sod
  INNER JOIN SpecialOfferProduct AS sop
    ON sop.ProductID = sod.ProductID AND sop.SpecialOfferID = sod.SpecialOfferID
  GROUP BY sod.ProductID
) AS esd
  ON esd.ProductID = target_table.ProductID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_SellEndDate.csv
# If the product is linked (via SpecialOfferProduct) to any SpecialOffer whose Type = 'Discontinued Product', set SellEndDate to the latest (MAX) of those SpecialOffer.EndDate values for that product. Otherwise, set SellEndDate to one day before the first anniversary of Product.SellStartDate: SellEndDate = DATE(Product.SellStartDate) + 1 year - 1 day.
# [across_tables], used_tables: ['SpecialOfferProduct', 'SpecialOffer']
SELECT
  COALESCE(
    disc_end.disc_end,
    DATE_SUB(DATE_ADD(DATE(target_table.SellStartDate), INTERVAL 1 YEAR), INTERVAL 1 DAY)
  ) AS computed_value,
  target_table.SellEndDate AS actual_value
FROM Product AS target_table
LEFT JOIN (
  SELECT sop.ProductID, MAX(so.EndDate) AS disc_end
  FROM SpecialOfferProduct AS sop
  JOIN SpecialOffer AS so ON so.SpecialOfferID = sop.SpecialOfferID
  WHERE so.Type = 'Discontinued Product'
  GROUP BY sop.ProductID
) AS disc_end ON disc_end.ProductID = target_table.ProductID;
###########################################################

###########################################################
# filtered_reported_accuracy_employee_salaries_to_date.csv
# Within each group identified by emp_no, order rows by from_date ascending. For each current_row: if a next_row exists in the same emp_no group (the row with the smallest from_date greater than current_row.from_date), set current_row.to_date = next_row.from_date; otherwise set current_row.to_date = 9999-12-12.
# [chaining_table], grouping_columns(['emp_no']), chaining_columns(['from_date', 'to_date'])
SELECT (SELECT MIN(s2.`from_date`) FROM `salaries` AS s2 WHERE s2.`emp_no` = target_table.`emp_no` AND s2.`from_date` > target_table.`from_date`) AS `computed_value`, target_table.`to_date` AS `actual_value` FROM `salaries` AS target_table WHERE EXISTS (SELECT 1 FROM `salaries` AS s3 WHERE s3.`emp_no` = target_table.`emp_no` AND s3.`from_date` > target_table.`from_date`);
###########################################################

###########################################################
# filtered_reported_accuracy_employee_salaries_to_date.csv
# to_date = from_date + 365 days
# [row_scope]
SELECT DATE_ADD(target_table.from_date, INTERVAL 365 DAY) AS computed_value, target_table.to_date AS actual_value FROM salaries AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_StandardCost.csv
# For each ProductID, StandardCost equals the StandardCost from the ProductCostHistory row with the maximum StartDate for that ProductID (i.e., the most recent cost change).
# [across_tables], used_tables: ['ProductCostHistory']
SELECT
  pch_latest.StandardCost AS computed_value,
  target_table.StandardCost AS actual_value
FROM Product AS target_table
LEFT JOIN (
  SELECT ProductID, MAX(StartDate) AS max_startdate
  FROM ProductCostHistory
  GROUP BY ProductID
) AS last_start
  ON last_start.ProductID = target_table.ProductID
LEFT JOIN ProductCostHistory AS pch_latest
  ON pch_latest.ProductID = last_start.ProductID
 AND pch_latest.StartDate = last_start.max_startdate;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_StandardCost.csv
# For each ProductID, StandardCost equals the StandardCost from the ProductCostHistory row effective at the product?s SellEndDate if present; otherwise use the current open-ended row. Formally, let effective_date = COALESCE(Product.SellEndDate, '9999-12-31 00:00:00'); pick the ProductCostHistory row where StartDate <= effective_date and (EndDate IS NULL OR EndDate >= effective_date) with the greatest StartDate, and use its StandardCost.
# [across_tables], used_tables: ['ProductCostHistory']
SELECT
  pch2.StandardCost AS computed_value,
  target_table.StandardCost AS actual_value
FROM Product AS target_table
LEFT JOIN (
  SELECT p.ProductID, MAX(pch.StartDate) AS max_startdate
  FROM Product p
  JOIN ProductCostHistory pch
    ON pch.ProductID = p.ProductID
   AND pch.StartDate <= COALESCE(p.SellEndDate, '9999-12-31 00:00:00')
   AND (pch.EndDate IS NULL OR pch.EndDate >= COALESCE(p.SellEndDate, '9999-12-31 00:00:00'))
  GROUP BY p.ProductID
) AS eff
  ON eff.ProductID = target_table.ProductID
LEFT JOIN ProductCostHistory AS pch2
  ON pch2.ProductID = eff.ProductID
 AND pch2.StartDate = eff.max_startdate;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_rebounds.csv
# rebounds = oRebounds + dRebounds
# [row_scope]
SELECT CAST(target_table.oRebounds AS SIGNED) + CAST(target_table.dRebounds AS SIGNED) AS computed_value, target_table.rebounds AS actual_value FROM players_teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_tags_WikiPostId.csv
# WikiPostId = ExcerptPostId - 1
# [row_scope]
SELECT CAST(`target_table`.`ExcerptPostId` AS SIGNED) - 1 AS computed_value, `target_table`.`WikiPostId` AS actual_value FROM `tags` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_ScoringSC_A.csv
# A = Pts - G
# [row_scope]
SELECT (CAST(target_table.Pts AS SIGNED) - CAST(target_table.G AS SIGNED)) AS computed_value, target_table.A AS actual_value FROM ScoringSC AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_ScoringSC_A.csv
# For each (playerID, year), derive A solely from playoff assists recorded in Scoring: A(playerID,year) = SUM_over_Scoring(PostA for same playerID & year).
# [across_tables], used_tables: ['Scoring', 'Master']
SELECT
  pa.post_a AS computed_value,
  target_table.A AS actual_value
FROM ScoringSC AS target_table
LEFT JOIN (
  SELECT s.playerID, s.year,
         SUM(CAST(s.PostA AS SIGNED)) AS post_a
  FROM Scoring s
  GROUP BY s.playerID, s.year
) AS pa
  ON pa.playerID = target_table.playerID
 AND pa.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsSC_GF.csv
# GF(year, lgID, tmID) = SUM of player goals G from ScoringSC for the same (year, lgID, tmID).
# [across_tables], used_tables: ['ScoringSC']
SELECT goals_sum.value AS computed_value, target_table.GF AS actual_value
FROM TeamsSC AS target_table
LEFT JOIN Teams AS t
  ON t.year = target_table.year AND t.tmID = target_table.tmID AND t.lgID = target_table.lgID
LEFT JOIN (
  SELECT year, lgID, tmID, SUM(COALESCE(G, 0)) AS value
  FROM ScoringSC
  GROUP BY year, lgID, tmID
) AS goals_sum
  ON goals_sum.year = target_table.year AND goals_sum.lgID = target_table.lgID AND goals_sum.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderHeader_TaxAmt.csv
# TaxAmt = ROUND(SubTotal * 0.08, 4)
# [row_scope]
SELECT ROUND(target_table.SubTotal * 0.08, 4) AS computed_value, target_table.TaxAmt AS actual_value FROM PurchaseOrderHeader AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_OwnerDisplayName.csv
# For a post P, set OwnerDisplayName to the first non-empty display name recorded at creation in postHistory, using the Initial Body event (PostHistoryTypeId = 1) at the earliest CreationDate for P. If none exists, fall back to the most recent non-empty UserDisplayName observed in postHistory for the same OwnerUserId as P (across any posts). If still none, fall back to the OwnerDisplayName from any other post by the same OwnerUserId (choose the one with the most recent LasActivityDate). If still none, fall back to the OwnerDisplayName of the post linked as a duplicate of P via postLinks (LinkTypeId = 3, most recent link). If still none, fall back to the OwnerDisplayName of the most recent related post via postLinks (LinkTypeId = 1).
# [across_tables], used_tables: ['postLinks', 'postHistory']
SELECT
  COALESCE(ph_init.UserDisplayName,
           ph_user.UserDisplayName,
           pp_name.OwnerDisplayName,
           rp3_name.OwnerDisplayName,
           rp1_name.OwnerDisplayName) AS computed_value,
  target_table.OwnerDisplayName AS actual_value
FROM posts AS target_table
LEFT JOIN (
  SELECT ph.PostId, ph.UserDisplayName
  FROM postHistory ph
  INNER JOIN (
    SELECT PostId, MIN(CreationDate) AS min_cd
    FROM postHistory
    WHERE PostHistoryTypeId = 1
      AND UserDisplayName IS NOT NULL AND UserDisplayName <> ''
    GROUP BY PostId
  ) s ON s.PostId = ph.PostId AND s.min_cd = ph.CreationDate
  WHERE ph.PostHistoryTypeId = 1
    AND ph.UserDisplayName IS NOT NULL AND ph.UserDisplayName <> ''
) AS ph_init ON ph_init.PostId = target_table.Id
LEFT JOIN (
  SELECT phu.UserId, phu.UserDisplayName
  FROM postHistory phu
  INNER JOIN (
    SELECT UserId, MAX(CreationDate) AS max_cd
    FROM postHistory
    WHERE UserId IS NOT NULL AND UserDisplayName IS NOT NULL AND UserDisplayName <> ''
    GROUP BY UserId
  ) su ON su.UserId = phu.UserId AND su.max_cd = phu.CreationDate
  WHERE phu.UserId IS NOT NULL AND phu.UserDisplayName IS NOT NULL AND phu.UserDisplayName <> ''
) AS ph_user ON ph_user.UserId = target_table.OwnerUserId
LEFT JOIN (
  SELECT p.OwnerUserId AS uid, p.OwnerDisplayName
  FROM posts p
  INNER JOIN (
    SELECT OwnerUserId AS uid, MAX(LasActivityDate) AS max_act
    FROM posts
    WHERE OwnerUserId IS NOT NULL AND OwnerDisplayName IS NOT NULL
    GROUP BY OwnerUserId
  ) sp ON sp.uid = p.OwnerUserId AND sp.max_act = p.LasActivityDate
  WHERE p.OwnerUserId IS NOT NULL AND p.OwnerDisplayName IS NOT NULL
) AS pp_name ON pp_name.uid = target_table.OwnerUserId
LEFT JOIN (
  SELECT pl.PostId, rp.OwnerDisplayName
  FROM postLinks pl
  INNER JOIN (
    SELECT PostId, MAX(CreationDate) AS max_cd
    FROM postLinks
    WHERE LinkTypeId = 3
    GROUP BY PostId
  ) spl ON spl.PostId = pl.PostId AND spl.max_cd = pl.CreationDate
  INNER JOIN posts rp ON rp.Id = pl.RelatedPostId
  WHERE pl.LinkTypeId = 3
) AS rp3_name ON rp3_name.PostId = target_table.Id
LEFT JOIN (
  SELECT pl.PostId, rp.OwnerDisplayName
  FROM postLinks pl
  INNER JOIN (
    SELECT PostId, MAX(CreationDate) AS max_cd
    FROM postLinks
    WHERE LinkTypeId = 1
    GROUP BY PostId
  ) spl ON spl.PostId = pl.PostId AND spl.max_cd = pl.CreationDate
  INNER JOIN posts rp ON rp.Id = pl.RelatedPostId
  WHERE pl.LinkTypeId = 1
) AS rp1_name ON rp1_name.PostId = target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_OwnerDisplayName.csv
# For each post: if OwnerUserId is not NULL, set OwnerDisplayName to users.DisplayName where users.Id = posts.OwnerUserId (this includes OwnerUserId = -1 mapping to 'Community'); otherwise, keep the existing posts.OwnerDisplayName.
# [across_tables], used_tables: ['users']
SELECT COALESCE(owner_u.DisplayName, target_table.OwnerDisplayName) AS computed_value, target_table.OwnerDisplayName AS actual_value FROM posts AS target_table LEFT JOIN users AS owner_u ON owner_u.Id = target_table.OwnerUserId;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_OwnerDisplayName.csv
# For each post, if OwnerUserId is NULL or equals -1, set OwnerDisplayName to the UserDisplayName of the earliest comment (by CreationDate) on that post where the commenter also has no linked account (comments.UserId IS NULL) and UserDisplayName IS NOT NULL; otherwise leave computed_value as NULL.
# [across_tables], used_tables: ['comments']
SELECT CASE WHEN target_table.OwnerUserId IS NULL OR target_table.OwnerUserId = -1 THEN earliest_anon_named.UserDisplayName ELSE NULL END AS computed_value, target_table.OwnerDisplayName AS actual_value FROM posts AS target_table LEFT JOIN (  SELECT c.PostId, c.UserDisplayName  FROM comments c  INNER JOIN (    SELECT PostId, MIN(CreationDate) AS min_created    FROM comments    WHERE UserId IS NULL AND UserDisplayName IS NOT NULL    GROUP BY PostId  ) AS first_anon_named    ON c.PostId = first_anon_named.PostId AND c.CreationDate = first_anon_named.min_created  WHERE c.UserId IS NULL AND c.UserDisplayName IS NOT NULL) AS earliest_anon_named ON earliest_anon_named.PostId = target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_hW.csv
# For each (year, tmID), hW = Teams.W - TeamSplits.rW.
# [across_tables], used_tables: ['Teams']
SELECT CAST(t.W AS SIGNED) - CAST(target_table.rW AS SIGNED) AS computed_value, target_table.hW AS actual_value FROM TeamSplits AS target_table INNER JOIN Teams AS t ON t.year = target_table.year AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Dallas_incidents_officer_count.csv
# nan
# [count_or_exist without data sharing], given_table_name = officers
select incidents.case_number, incidents.officer_count actual_value, Count(*) computed_value from  `incidents` 
LEFT JOIN officers ON `officers`.`case_number` = `incidents`.`case_number` group by incidents.case_number, incidents.officer_count
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_TotalDue.csv
# TotalDue = ROUND(SubTotal + TaxAmt + Freight, 4)
# [row_scope]
SELECT (target_table.SubTotal + target_table.TaxAmt + target_table.Freight) AS computed_value, target_table.TotalDue AS actual_value FROM SalesOrderHeader AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_T.csv
# T = Pts - (2 * W) - (OTL if present, else 0)
# [row_scope]
SELECT (CAST(`target_table`.`Pts` AS SIGNED) - (2 * CAST(`target_table`.`W` AS SIGNED)) - COALESCE(CAST(`target_table`.`OTL` AS SIGNED), 0)) AS `computed_value`, `target_table`.`T` AS `actual_value` FROM `Teams` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_T.csv
# nan
# [count_or_exist with data sharing], given_table_name = TeamVsTeam
SELECT
  COALESCE(SUM(COALESCE(tv.T, 0)), 0) + 0*COUNT(tv.oppID) AS computed_value,
  target_table.T AS actual_value
FROM Teams AS target_table
LEFT JOIN TeamVsTeam AS tv
  ON tv.year = target_table.year
 AND tv.tmID = target_table.tmID
 AND tv.lgID = target_table.lgID
GROUP BY target_table.year, target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_Freight.csv
# Freight = TotalDue - SubTotal - TaxAmt
# [row_scope]
SELECT (CAST(target_table.`TotalDue` AS DECIMAL(38,10)) - CAST(target_table.`SubTotal` AS DECIMAL(38,10)) - CAST(target_table.`TaxAmt` AS DECIMAL(38,10))) AS `computed_value`, target_table.`Freight` AS `actual_value` FROM `SalesOrderHeader` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_Freight.csv
# Freight = ROUND(SubTotal * (CASE WHEN OnlineOrderFlag = 1 THEN 0.025 ELSE 0.03 END), 4)
# [row_scope]
SELECT (target_table.SubTotal * (CASE WHEN CAST(target_table.OnlineOrderFlag AS UNSIGNED) = 1 THEN 0.025 ELSE 0.03 END)) AS computed_value, target_table.Freight AS actual_value FROM SalesOrderHeader AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_ProductReview_ModifiedDate.csv
# ModifiedDate equals the later of (ProductReview.ReviewDate, Product.SellStartDate) for the reviewed product.
# [across_tables], used_tables: ['Product']
SELECT GREATEST(p.SellStartDate, target_table.ReviewDate) AS computed_value, target_table.ModifiedDate AS actual_value FROM `ProductReview` AS target_table INNER JOIN `Product` AS p ON p.ProductID = target_table.ProductID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_ProductReview_ModifiedDate.csv
# ModifiedDate equals the earlier of (ProductReview.ReviewDate, Product.ModifiedDate) for the reviewed product.
# [across_tables], used_tables: ['Product']
SELECT LEAST(p.ModifiedDate, target_table.ReviewDate) AS computed_value, target_table.ModifiedDate AS actual_value FROM `ProductReview` AS target_table INNER JOIN `Product` AS p ON p.ProductID = target_table.ProductID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Shift_EndTime.csv
# EndTime = (StartTime + 8 hours) modulo 24 hours
# [row_scope]
SELECT SEC_TO_TIME(MOD(CAST(TIME_TO_SEC(target_table.`StartTime`) AS SIGNED) + 28800, 86400)) AS computed_value, target_table.`EndTime` AS actual_value FROM `Shift` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_NovOL.csv
# NovOL = (hOTL + rOTL) - (COALESCE(SepOL, 0) + COALESCE(OctOL, 0) + COALESCE(DecOL, 0) + COALESCE(JanOL, 0) + COALESCE(FebOL, 0) + COALESCE(MarOL, 0) + COALESCE(AprOL, 0))
# [row_scope]
SELECT (CAST(target_table.hOTL AS SIGNED) + CAST(target_table.rOTL AS SIGNED)) - (CAST(COALESCE(target_table.SepOL, 0) AS SIGNED) + CAST(COALESCE(target_table.OctOL, 0) AS SIGNED) + CAST(COALESCE(target_table.DecOL, 0) AS SIGNED) + CAST(COALESCE(target_table.JanOL, 0) AS SIGNED) + CAST(COALESCE(target_table.FebOL, 0) AS SIGNED) + CAST(COALESCE(target_table.MarOL, 0) AS SIGNED) + CAST(COALESCE(target_table.AprOL, 0) AS SIGNED)) AS computed_value, CAST(target_table.NovOL AS SIGNED) AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsSC_T.csv
# T = G - W - L
# [row_scope]
SELECT (CAST(target_table.`G` AS SIGNED) - CAST(target_table.`W` AS SIGNED) - CAST(target_table.`L` AS SIGNED)) AS computed_value, target_table.`T` AS actual_value FROM TeamsSC AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsSC_T.csv
# For each TeamsSC row (year, lgID, tmID), T equals the sum of T recorded for all goalies of that same team, league, and year in GoaliesSC: TeamsSC.T = SUM_{g in GoaliesSC where g.year = TeamsSC.year AND g.lgID = TeamsSC.lgID AND g.tmID = TeamsSC.tmID}(g.T).
# [across_tables], used_tables: ['SeriesPost', 'GoaliesSC']
SELECT 
  CAST(gs_t.total_ties AS SIGNED) AS computed_value,
  target_table.T AS actual_value
FROM TeamsSC AS target_table
LEFT JOIN (
  SELECT year, lgID, tmID, SUM(CAST(T AS SIGNED)) AS total_ties
  FROM GoaliesSC
  GROUP BY year, lgID, tmID
) AS gs_t
  ON gs_t.year = target_table.year
 AND gs_t.lgID = target_table.lgID
 AND gs_t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsSC_T.csv
# For each TeamsSC row (year, lgID, tmID), compute T as the total number of tied games recorded for that team across all inter-league SeriesPost rounds in that year. Inter-league rounds are identified by SeriesPost.lgIDWinner <> SeriesPost.lgIDLoser. Sum SeriesPost.T where the team appears as tmIDWinner or tmIDLoser.
# [across_tables], used_tables: ['ScoringSC', 'SeriesPost']
SELECT
  COALESCE(CAST(t_agg.ties AS SIGNED), 0) AS computed_value,
  target_table.T AS actual_value
FROM TeamsSC AS target_table
LEFT JOIN (
  SELECT year, lgIDTeam, tmID, SUM(ties) AS ties
  FROM (
    SELECT sp.year, sp.lgIDWinner AS lgIDTeam, sp.tmIDWinner AS tmID, sp.T AS ties
    FROM SeriesPost sp
    WHERE sp.lgIDWinner <> sp.lgIDLoser
    UNION ALL
    SELECT sp.year, sp.lgIDLoser AS lgIDTeam, sp.tmIDLoser AS tmID, sp.T AS ties
    FROM SeriesPost sp
    WHERE sp.lgIDWinner <> sp.lgIDLoser
  ) AS v
  GROUP BY year, lgIDTeam, tmID
) AS t_agg
  ON t_agg.year = target_table.year
  AND t_agg.tmID = target_table.tmID
  AND t_agg.lgIDTeam = target_table.lgID
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_OctOL.csv
# OctOL = (hOTL + rOTL) - (COALESCE(SepOL, 0) + COALESCE(NovOL, 0) + COALESCE(DecOL, 0) + COALESCE(JanOL, 0) + COALESCE(FebOL, 0) + COALESCE(MarOL, 0) + COALESCE(AprOL, 0))
# [row_scope]
SELECT (CAST(target_table.hOTL AS SIGNED) + CAST(target_table.rOTL AS SIGNED) - (CAST(COALESCE(target_table.SepOL, 0) AS SIGNED) + CAST(COALESCE(target_table.NovOL, 0) AS SIGNED) + CAST(COALESCE(target_table.DecOL, 0) AS SIGNED) + CAST(COALESCE(target_table.JanOL, 0) AS SIGNED) + CAST(COALESCE(target_table.FebOL, 0) AS SIGNED) + CAST(COALESCE(target_table.MarOL, 0) AS SIGNED) + CAST(COALESCE(target_table.AprOL, 0) AS SIGNED))) AS computed_value, target_table.OctOL AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_won.csv
# For each team-season, won equals the sum of coaches.won across all stints for that team and year. Formally: won(team, year) = SUM(coaches.won) WHERE coaches.tmID = teams.tmID AND coaches.year = teams.year.
# [across_tables], used_tables: ['players_teams', 'coaches']
SELECT coach_wins.total_wins AS computed_value, target_table.won AS actual_value FROM teams AS target_table LEFT JOIN ( SELECT tmID, year, SUM(CAST(won AS SIGNED)) AS total_wins FROM coaches GROUP BY tmID, year ) AS coach_wins ON coach_wins.tmID = target_table.tmID AND coach_wins.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_won.csv
# won = games - lost
# [row_scope]
SELECT CAST(`target_table`.`games` AS SIGNED) - CAST(`target_table`.`lost` AS SIGNED) AS computed_value, `target_table`.`won` AS actual_value FROM `teams` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_asts.csv
# For each team-season (teams.tmID, teams.year), o_asts equals the sum of all player regular-season assists recorded in players_teams for that same team and season (league-agnostic): o_asts(team, year) = SUM_{players_teams where tmID = teams.tmID AND year = teams.year}(assists).
# [across_tables], used_tables: ['players_teams']
SELECT
  COALESCE(pt_agg.value, 0) AS computed_value,
  target_table.o_asts AS actual_value
FROM teams AS target_table
LEFT JOIN (
  SELECT tmID, year, SUM(COALESCE(assists, 0)) AS value
  FROM players_teams
  GROUP BY tmID, year
) AS pt_agg
  ON pt_agg.tmID = target_table.tmID
 AND pt_agg.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_PTE_pte_bond_count_Cnt.csv
# nan
# [count_or_exist without data sharing], given_table_name = pte_bond
select pte_bond_count.Arg0, pte_bond_count.Cnt actual_value, Count(*) computed_value from  `pte_bond_count` 
LEFT JOIN pte_drug ON `pte_drug`.`drug_id` = `pte_bond_count`.`Arg0`
LEFT JOIN pte_bond ON `pte_bond`.`drug_id` = `pte_drug`.`drug_id` group by pte_bond_count.Arg0, pte_bond_count.Cnt
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsSC_G.csv
# G = W + L + T
# [row_scope]
SELECT CAST(target_table.`W` AS SIGNED) + CAST(target_table.`L` AS SIGNED) + CAST(target_table.`T` AS SIGNED) AS computed_value, target_table.`G` AS actual_value FROM `TeamsSC` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsSC_G.csv
# For each (year, lgID, tmID), G equals the maximum number of games played (GP) by any goalie on that team in GoaliesSC for that same (year, lgID, tmID): G = MAX_{goalie in GoaliesSC(year, lgID, tmID)}(GP).
# [across_tables], used_tables: ['GoaliesSC']
SELECT MAX_GP.max_gp AS computed_value, target_table.G AS actual_value
FROM TeamsSC AS target_table
LEFT JOIN (
  SELECT year, lgID, tmID, MAX(GP) AS max_gp
  FROM GoaliesSC
  GROUP BY year, lgID, tmID
) AS MAX_GP
  ON MAX_GP.year = target_table.year
 AND MAX_GP.lgID = target_table.lgID
 AND MAX_GP.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsSC_G.csv
# For each TeamsSC row (year, lgID, tmID), compute G as the total number of Stanley Cup games that team played in that year, summing across the SeriesPost rows for rounds in {SCSF, SCF} where the team appears either as winner (tmIDWinner, lgIDWinner) or loser (tmIDLoser, lgIDLoser): G = ?_{SeriesPost where year matches and round ? {SCSF, SCF} and (tmIDWinner=tmID & lgIDWinner=lgID or tmIDLoser=tmID & lgIDLoser=lgID)} (W + L + T).
# [across_tables], used_tables: ['SeriesPost', 'TeamsPost']
SELECT
  sp_sc_agg.computed_g AS computed_value,
  target_table.G AS actual_value
FROM TeamsSC AS target_table
LEFT JOIN (
  SELECT a.year, a.tmID, a.lgID, SUM(a.games) AS computed_g
  FROM (
    SELECT year,
           tmIDWinner AS tmID,
           lgIDWinner AS lgID,
           (COALESCE(CAST(W AS SIGNED), 0) + COALESCE(CAST(L AS SIGNED), 0) + COALESCE(CAST(T AS SIGNED), 0)) AS games
    FROM SeriesPost
    WHERE year IS NOT NULL AND round IN ('SCSF','SCF')
    UNION ALL
    SELECT year,
           tmIDLoser AS tmID,
           lgIDLoser AS lgID,
           (COALESCE(CAST(W AS SIGNED), 0) + COALESCE(CAST(L AS SIGNED), 0) + COALESCE(CAST(T AS SIGNED), 0)) AS games
    FROM SeriesPost
    WHERE year IS NOT NULL AND round IN ('SCSF','SCF')
  ) AS a
  GROUP BY a.year, a.tmID, a.lgID
) AS sp_sc_agg
  ON sp_sc_agg.year = target_table.year
 AND sp_sc_agg.tmID  = target_table.tmID
 AND sp_sc_agg.lgID  = target_table.lgID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_L.csv
# L = G - W - COALESCE(T, 0) - COALESCE(OTL, 0)
# [row_scope]
SELECT CAST(`target_table`.`G` AS SIGNED) - CAST(`target_table`.`W` AS SIGNED) - COALESCE(CAST(`target_table`.`T` AS SIGNED), 0) - COALESCE(CAST(`target_table`.`OTL` AS SIGNED), 0) AS `computed_value`, `target_table`.`L` AS `actual_value` FROM `Teams` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_L.csv
# For each team-season (Teams.year, Teams.tmID), L equals the sum of losses across all coach stints for that team and season: L = SUM(Coaches.l) where Coaches.year = Teams.year and Coaches.tmID = Teams.tmID.
# [across_tables], used_tables: ['Coaches']
SELECT COALESCE(ct.sum_l, 0) AS computed_value, target_table.L AS actual_value FROM Teams AS target_table LEFT JOIN ( SELECT year, tmID, SUM(CAST(l AS SIGNED)) AS sum_l FROM Coaches GROUP BY year, tmID ) AS ct ON ct.year = target_table.year AND ct.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_CreditCard_CardType.csv
# CardType = CASE WHEN CardNumber LIKE '1%' THEN 'Vista' WHEN CardNumber LIKE '3%' THEN 'SuperiorCard' WHEN CardNumber LIKE '5%' THEN 'Distinguish' WHEN CardNumber LIKE '7%' THEN 'ColonialVoice' END
# [row_scope]
SELECT CASE WHEN target_table.CardNumber LIKE '1%' THEN 'Vista' WHEN target_table.CardNumber LIKE '3%' THEN 'SuperiorCard' WHEN target_table.CardNumber LIKE '5%' THEN 'Distinguish' WHEN target_table.CardNumber LIKE '7%' THEN 'ColonialVoice' END AS computed_value, target_table.CardType AS actual_value FROM CreditCard AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_CreditCard_CardType.csv
# Compute the predominant country per card from orders (joins: SalesOrderHeader -> Address -> StateProvince), then predict CardType as the majority (most frequent) CardType observed among all cards sharing the same BIN4 (first 4 digits of CardNumber) used in orders to that country. This leverages cross-table aggregates to infer CardType for a given card from other cards with the same BIN and country.
# [across_tables], used_tables: ['SalesOrderHeader', 'Address', 'StateProvince']
SELECT
  maj.CardType AS computed_value,
  target_table.CardType AS actual_value
FROM CreditCard AS target_table
LEFT JOIN (
  SELECT ccid_country.cid, ccid_country.country
  FROM (
    SELECT soh.CreditCardID AS cid, sp.CountryRegionCode AS country, COUNT(*) AS cnt
    FROM SalesOrderHeader AS soh
    JOIN Address AS a ON a.AddressID = soh.BillToAddressID
    JOIN StateProvince AS sp ON sp.StateProvinceID = a.StateProvinceID
    GROUP BY soh.CreditCardID, sp.CountryRegionCode
  ) AS ccid_country
  JOIN (
    SELECT cid, MAX(cnt) AS maxcnt
    FROM (
      SELECT soh.CreditCardID AS cid, sp.CountryRegionCode AS country, COUNT(*) AS cnt
      FROM SalesOrderHeader AS soh
      JOIN Address AS a ON a.AddressID = soh.BillToAddressID
      JOIN StateProvince AS sp ON sp.StateProvinceID = a.StateProvinceID
      GROUP BY soh.CreditCardID, sp.CountryRegionCode
    ) AS tmp
    GROUP BY cid
  ) AS ccid_country_max
    ON ccid_country.cid = ccid_country_max.cid AND ccid_country.cnt = ccid_country_max.maxcnt
) AS dominant_country ON dominant_country.cid = target_table.CreditCardID
LEFT JOIN (
  SELECT map.bin4, map.country, map.CardType
  FROM (
    SELECT SUBSTRING(cc.CardNumber, 1, 4) AS bin4, sp.CountryRegionCode AS country, cc.CardType AS CardType, COUNT(*) AS cnt
    FROM CreditCard AS cc
    JOIN SalesOrderHeader AS soh ON soh.CreditCardID = cc.CreditCardID
    JOIN Address AS a ON a.AddressID = soh.BillToAddressID
    JOIN StateProvince AS sp ON sp.StateProvinceID = a.StateProvinceID
    GROUP BY SUBSTRING(cc.CardNumber, 1, 4), sp.CountryRegionCode, cc.CardType
  ) AS map
  JOIN (
    SELECT bin4, country, MAX(cnt) AS maxcnt
    FROM (
      SELECT SUBSTRING(cc.CardNumber, 1, 4) AS bin4, sp.CountryRegionCode AS country, cc.CardType AS CardType, COUNT(*) AS cnt
      FROM CreditCard AS cc
      JOIN SalesOrderHeader AS soh ON soh.CreditCardID = cc.CreditCardID
      JOIN Address AS a ON a.AddressID = soh.BillToAddressID
      JOIN StateProvince AS sp ON sp.StateProvinceID = a.StateProvinceID
      GROUP BY SUBSTRING(cc.CardNumber, 1, 4), sp.CountryRegionCode, cc.CardType
    ) AS t
    GROUP BY bin4, country
  ) AS mx ON map.bin4 = mx.bin4 AND map.country = mx.country AND map.cnt = mx.maxcnt
) AS maj ON maj.bin4 = SUBSTRING(target_table.CardNumber, 1, 4) AND maj.country = dominant_country.country;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_CreditCard_CardType.csv
# Same global mapping M from suffix (digits after 'Vi' in CreditCardApprovalCode) to CardType as above. For a target credit card, take the suffix from its latest SalesOrderHeader.OrderDate and compute CardType as M(suffix).
# [across_tables], used_tables: ['SalesOrderHeader', 'SalesPerson']
SELECT COALESCE(mapped_by_card.mapped_card_type, 'UNKNOWN') AS computed_value, target_table.CardType AS actual_value FROM CreditCard AS target_table LEFT JOIN (  SELECT last_order.CreditCardID, suffix_to_type.mapped_card_type  FROM (    SELECT soh.CreditCardID,           SUBSTRING(soh.CreditCardApprovalCode, LOCATE('Vi', soh.CreditCardApprovalCode) + 2) AS suffix    FROM SalesOrderHeader soh    JOIN (      SELECT CreditCardID, MAX(OrderDate) AS max_order_date      FROM SalesOrderHeader      WHERE CreditCardApprovalCode IS NOT NULL        AND LOCATE('Vi', CreditCardApprovalCode) > 0      GROUP BY CreditCardID    ) latest ON soh.CreditCardID = latest.CreditCardID AND soh.OrderDate = latest.max_order_date    WHERE soh.CreditCardApprovalCode IS NOT NULL      AND LOCATE('Vi', soh.CreditCardApprovalCode) > 0  ) last_order  JOIN (    SELECT t.suffix, MAX(t.CardType) AS mapped_card_type    FROM (      SELECT SUBSTRING(soh.CreditCardApprovalCode, LOCATE('Vi', soh.CreditCardApprovalCode) + 2) AS suffix,             cc.CardType      FROM SalesOrderHeader soh      JOIN CreditCard cc ON soh.CreditCardID = cc.CreditCardID      WHERE soh.CreditCardApprovalCode IS NOT NULL        AND LOCATE('Vi', soh.CreditCardApprovalCode) > 0    ) t    GROUP BY t.suffix    HAVING COUNT(DISTINCT t.CardType) = 1  ) suffix_to_type ON suffix_to_type.suffix = last_order.suffix) mapped_by_card ON mapped_by_card.CreditCardID = target_table.CreditCardID
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_homeWon.csv
# homeWon = won - awayWon - neutWon
# [row_scope]
SELECT (CAST(target_table.won AS SIGNED) - CAST(target_table.awayWon AS SIGNED) - CAST(target_table.neutWon AS SIGNED)) AS computed_value, target_table.homeWon AS actual_value FROM teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_awards_coaches_award.csv
# award = CONCAT(lgID, ' Coach of the Year')
# [row_scope]
SELECT CONCAT(`target_table`.`lgID`, ' Coach of the Year') AS computed_value, `target_table`.`award` AS actual_value FROM `awards_coaches` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_match_stats_loc.csv
# Join match_stats to matches on mid. If target_table.tid equals matches.h_tid then loc='h'; if target_table.tid equals matches.a_tid then loc='a'; otherwise NULL.
# [across_tables], used_tables: ['matches']
SELECT CASE WHEN m.h_tid = target_table.tid THEN 'h' WHEN m.a_tid = target_table.tid THEN 'a' ELSE NULL END AS computed_value, target_table.loc AS actual_value FROM match_stats AS target_table JOIN matches AS m ON m.mid = target_table.mid;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_dRebounds.csv
# dRebounds = rebounds - oRebounds
# [row_scope]
SELECT CAST(`target_table`.`rebounds` AS SIGNED) - CAST(`target_table`.`oRebounds` AS SIGNED) AS computed_value, `target_table`.`dRebounds` AS actual_value FROM `players_teams` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_dRebounds.csv
# Residual (team-constrained) method: For a given team-season, a player?s defensive rebounds equal team defensive rebounds minus the defensive rebounds of all other players on that team-season: dRebounds(player) = teams.o_dreb(team,year) ? [SUM_{same team,year}(dRebounds) ? dRebounds(player)]. This exactly recovers a missing value when at most one player?s dRebounds is missing on that team-season.
# [across_tables], used_tables: ['teams']
SELECT (CAST(COALESCE(t.o_dreb, 0) AS SIGNED) - (COALESCE(s.sum_dreb, 0) - COALESCE(target_table.dRebounds, 0))) AS computed_value, target_table.dRebounds AS actual_value FROM players_teams AS target_table LEFT JOIN (SELECT tmID, year, SUM(CAST(dRebounds AS SIGNED)) AS sum_dreb FROM players_teams GROUP BY tmID, year) AS s ON s.tmID = target_table.tmID AND s.year = target_table.year LEFT JOIN teams AS t ON t.tmID = target_table.tmID AND t.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_series_post_W.csv
# For a series_post row, let the winner?s division and league be taken from teams (join on year and tmIDWinner). Compute W as the maximum winner-series wins observed among all series in series_post that share the same (year, round, division, league) as that row. This captures the round-and-bracket win threshold (e.g., best-of-3 or best-of-7) that applies uniformly within that division/league for that year.
# [across_tables], used_tables: ['teams']
SELECT fmt_max.maxW AS computed_value, target_table.W AS actual_value
FROM series_post AS target_table
LEFT JOIN teams AS t_w
  ON target_table.year = t_w.year
 AND target_table.tmIDWinner = t_w.tmID
LEFT JOIN (
  SELECT sp.year, sp.`round`, t.divID AS divID_winner, t.lgID AS lgID_winner, MAX(sp.W) AS maxW
  FROM series_post sp
  JOIN teams t
    ON sp.year = t.year
   AND sp.tmIDWinner = t.tmID
  WHERE sp.W IS NOT NULL
  GROUP BY sp.year, sp.`round`, t.divID, t.lgID
) AS fmt_max
  ON fmt_max.year = target_table.year
 AND fmt_max.`round` = target_table.`round`
 AND fmt_max.lgID_winner = t_w.lgID
 AND fmt_max.divID_winner <=> t_w.divID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_series_post_W.csv
# For a series row S (year = y, loser team = TL, loser league = LL): let TotalLossTL be the sum of post_losses across all coaches for (TL, LL, y). Let LossesWhenTLWon be the sum of L across all series rows in the same season where (tmIDWinner, lgIDWinner) = (TL, LL) (i.e., the losses TL incurred in the series it won). Then W(S) = TotalLossTL - LossesWhenTLWon.
# [across_tables], used_tables: ['coaches']
SELECT
  (CAST(COALESCE(coach_l.total_post_losses, 0) AS SIGNED)
   - CAST(COALESCE(loser_prev.losses_as_winner, 0) AS SIGNED)
  ) AS computed_value,
  target_table.W AS actual_value
FROM series_post AS target_table
LEFT JOIN teams AS t_loser
  ON t_loser.year = target_table.year
 AND t_loser.tmID = target_table.tmIDLoser
 AND t_loser.lgID = target_table.lgIDLoser
LEFT JOIN (
  SELECT tmID, lgID, year, SUM(COALESCE(post_losses, 0)) AS total_post_losses
  FROM coaches
  GROUP BY tmID, lgID, year
) AS coach_l
  ON coach_l.year = target_table.year
 AND coach_l.tmID = target_table.tmIDLoser
 AND coach_l.lgID = target_table.lgIDLoser
LEFT JOIN (
  SELECT year, lgIDWinner AS lgID, tmIDWinner AS tmID, SUM(CAST(L AS SIGNED)) AS losses_as_winner
  FROM series_post
  GROUP BY year, lgIDWinner, tmIDWinner
) AS loser_prev
  ON loser_prev.year = target_table.year
 AND loser_prev.tmID = target_table.tmIDLoser
 AND loser_prev.lgID = target_table.lgIDLoser;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_coaches_post_wins.csv
# nan
# [count_or_exist with data sharing], given_table_name = series_post
SELECT
  COALESCE(w.w_sum, 0) + COALESCE(l.l_sum, 0) AS computed_value,
  target_table.post_wins AS actual_value
FROM coaches AS target_table
LEFT JOIN (
  SELECT sp.year, sp.tmIDWinner AS tmID, sp.lgIDWinner AS lgID, SUM(sp.W) AS w_sum
  FROM series_post sp
  GROUP BY sp.year, sp.tmIDWinner, sp.lgIDWinner
) AS w
  ON w.year = target_table.year AND w.tmID = target_table.tmID AND w.lgID = target_table.lgID
LEFT JOIN (
  SELECT sp.year, sp.tmIDLoser AS tmID, sp.lgIDLoser AS lgID, SUM(sp.L) AS l_sum
  FROM series_post sp
  GROUP BY sp.year, sp.tmIDLoser, sp.lgIDLoser
) AS l
  ON l.year = target_table.year AND l.tmID = target_table.tmID AND l.lgID = target_table.lgID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_player_allstar_points.csv
# points = 2 * fg_made + ft_made + three_made
# [row_scope]
SELECT (2 * CAST(COALESCE(target_table.fg_made, 0) AS SIGNED) + CAST(COALESCE(target_table.ft_made, 0) AS SIGNED) + CAST(COALESCE(target_table.three_made, 0) AS SIGNED)) AS computed_value, target_table.points AS actual_value FROM player_allstar AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_PostftMade.csv
# PostftMade = PostPoints - (2 * PostfgMade) - PostthreeMade
# [row_scope]
SELECT (CAST(target_table.PostPoints AS SIGNED) - (2 * CAST(target_table.PostfgMade AS SIGNED)) - CAST(target_table.PostthreeMade AS SIGNED)) AS computed_value, target_table.PostftMade AS actual_value FROM players_teams AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_PostftMade.csv
# Alternative (cross-table rate-based estimate with bounds): Approximate PostftMade from the All-Star free-throw scoring rate for the same player and season: PostftMade ? PostPoints ? (ft_made / points) using player_allstar values (matched on playerID, season_id=year, league_id=lgID). Clamp the result to [0, PostftAttempted].
# [across_tables], used_tables: ['player_allstar']
SELECT
  LEAST(
    COALESCE(CAST(target_table.PostftAttempted AS SIGNED), CAST(0 AS SIGNED)),
    GREATEST(
      0,
      CAST(target_table.PostPoints AS SIGNED) * COALESCE(
        CAST(pa.ft_made AS DECIMAL(20,6)) / NULLIF(CAST(pa.points AS DECIMAL(20,6)), 0),
        0
      )
    )
  ) AS computed_value,
  target_table.PostftMade AS actual_value
FROM players_teams AS target_table
LEFT JOIN players AS p
  ON p.playerID = target_table.playerID
LEFT JOIN player_allstar AS pa
  ON pa.playerID = target_table.playerID
 AND pa.season_id = target_table.year
 AND pa.league_id = target_table.lgID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Employee_LoginID.csv
# LoginID = 'adventure-works\' concatenated with the local-part (substring before '@') of the employee's primary email address (the EmailAddress row with the smallest EmailAddressID for that BusinessEntityID).
# [across_tables], used_tables: ['EmailAddress', 'Person']
SELECT CONCAT('adventure-works', '\\', sel.local_part) AS computed_value, target_table.LoginID AS actual_value FROM Employee AS target_table LEFT JOIN (  SELECT ea.BusinessEntityID, SUBSTRING_INDEX(ea.EmailAddress, '@', 1) AS local_part  FROM EmailAddress ea  JOIN (    SELECT BusinessEntityID, MIN(EmailAddressID) AS min_email_id    FROM EmailAddress    GROUP BY BusinessEntityID  ) min_ea ON ea.BusinessEntityID = min_ea.BusinessEntityID AND ea.EmailAddressID = min_ea.min_email_id) sel ON sel.BusinessEntityID = target_table.BusinessEntityID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Employee_LoginID.csv
# LoginID = adventure-works + lower(Person.FirstName) + '0' (joined on Employee.BusinessEntityID = Person.BusinessEntityID).
# [across_tables], used_tables: ['Person']
SELECT CONCAT('adventure-works\\', LOWER(p.FirstName), '0') AS computed_value, target_table.LoginID AS actual_value FROM Employee AS target_table INNER JOIN Person AS p ON p.BusinessEntityID = target_table.BusinessEntityID;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_PostTypeId.csv
# If ParentId is not null then the post is an Answer (2). Otherwise, if any question-only indicators are present (AcceptedAnswerId, AnswerCount, or ViewCount non-null) OR there exists at least one outgoing postLinks row of LinkTypeId 1 or 3 for this post, then classify as Question (1). Otherwise classify as Other (7).
# [across_tables], used_tables: ['postLinks']
SELECT
  CASE
    WHEN target_table.ParentId IS NOT NULL THEN 2
    WHEN target_table.AcceptedAnswerId IS NOT NULL
      OR target_table.AnswerCount IS NOT NULL
      OR target_table.ViewCount IS NOT NULL
      OR CAST(COALESCE(pl_out_rel.cnt_rel, 0) AS SIGNED) > 0 THEN 1
    ELSE 7
  END AS computed_value,
  target_table.PostTypeId AS actual_value
FROM posts AS target_table
LEFT JOIN (
  SELECT PostId, COUNT(*) AS cnt_rel
  FROM postLinks
  WHERE LinkTypeId IN (1, 3)
  GROUP BY PostId
) AS pl_out_rel ON pl_out_rel.PostId = target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_PostTypeId.csv
# Simpler cross-table rule set: (1) If the post has any vote with VoteTypeId=16, set PostTypeId=5 (TagWiki). (2) Else if the post has any vote with VoteTypeId=1 (accept) OR ParentId is not null, set PostTypeId=2 (Answer). (3) Else if the post has any vote with VoteTypeId=5 (favorite) OR any of Title, Tags, ViewCount, AnswerCount, AcceptedAnswerId, or ClosedDate is non-null, set PostTypeId=1 (Question). (4) Otherwise default to PostTypeId=3.
# [across_tables], used_tables: ['votes']
SELECT
  CASE
    WHEN v16.has_v16 = 1 THEN 5
    WHEN v1.has_v1 = 1 OR target_table.ParentId IS NOT NULL THEN 2
    WHEN v5.has_v5 = 1
         OR target_table.Title IS NOT NULL
         OR target_table.Tags IS NOT NULL
         OR target_table.ViewCount IS NOT NULL
         OR target_table.AnswerCount IS NOT NULL
         OR target_table.AcceptedAnswerId IS NOT NULL
         OR target_table.ClosedDate IS NOT NULL THEN 1
    ELSE 3
  END AS computed_value,
  target_table.PostTypeId AS actual_value
FROM posts AS target_table
LEFT JOIN (
  SELECT PostId, 1 AS has_v1
  FROM votes
  WHERE VoteTypeId = 1
  GROUP BY PostId
) AS v1 ON v1.PostId = target_table.Id
LEFT JOIN (
  SELECT PostId, 1 AS has_v5
  FROM votes
  WHERE VoteTypeId = 5
  GROUP BY PostId
) AS v5 ON v5.PostId = target_table.Id
LEFT JOIN (
  SELECT PostId, 1 AS has_v16
  FROM votes
  WHERE VoteTypeId = 16
  GROUP BY PostId
) AS v16 ON v16.PostId = target_table.Id;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_awards_players_pos.csv
# For team-selection awards (All-NBA First/Second/Third Team, All-Defensive First/Second Team, All-Rookie First/Second Team), compute pos as the uppercase of players.pos with '-' replaced by '/' (e.g., G-F -> G/F, F-C -> F/C). For non-team awards or missing players.pos, return NULL.
# [across_tables], used_tables: ['players']
SELECT
  CASE
    WHEN target_table.award IN ('All-NBA First Team','All-NBA Second Team','All-NBA Third Team','All-Defensive First Team','All-Defensive Second Team','All-Rookie First Team','All-Rookie Second Team') THEN UPPER(REPLACE(TRIM(p.pos),'-','/'))
    ELSE NULL
  END AS computed_value,
  target_table.pos AS actual_value
FROM awards_players AS target_table
LEFT JOIN players AS p ON p.playerID = target_table.playerID;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_results_milliseconds.csv
# If time starts with '+', let gap_ms = parse the substring after '+' as either M:SS(.sss) or SS(.sss) and compute gap_ms = (M * 60000) + (SS.sss * 1000). Find the winner row for the same race (raceId) where positionOrder = 1 (or positionText = '1'), parse its time (H:MM:SS(.sss)) to leader_ms as in formula_1. Then milliseconds = leader_ms + gap_ms.
# [row_scope]
SELECT CASE WHEN target_table.time IS NULL THEN NULL WHEN LEFT(target_table.time,1) = '+' THEN CAST(MAX(CASE WHEN target_table.positionOrder = 1 OR target_table.positionText = '1' THEN (CAST(SUBSTRING_INDEX(target_table.time, ':', 1) AS SIGNED) * 3600000 + CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(target_table.time, ':', 2), ':', -1) AS SIGNED) * 60000 + CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(target_table.time, ':', -1), '.', 1) AS SIGNED) * 1000 + CASE WHEN LOCATE('.', SUBSTRING_INDEX(target_table.time, ':', -1)) > 0 THEN CAST(RPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(target_table.time, ':', -1), '.', -1), 3, '0') AS SIGNED) ELSE 0 END) ELSE NULL END) OVER (PARTITION BY target_table.raceId) AS SIGNED) + CAST((CAST(CASE WHEN LOCATE(':', SUBSTRING(target_table.time, 2)) > 0 THEN SUBSTRING_INDEX(SUBSTRING(target_table.time, 2), ':', 1) ELSE 0 END AS SIGNED) * 60000 + CAST(SUBSTRING_INDEX(CASE WHEN LOCATE(':', SUBSTRING(target_table.time, 2)) > 0 THEN SUBSTRING_INDEX(SUBSTRING(target_table.time, 2), ':', -1) ELSE SUBSTRING(target_table.time, 2) END, '.', 1) AS SIGNED) * 1000 + CASE WHEN LOCATE('.', CASE WHEN LOCATE(':', SUBSTRING(target_table.time, 2)) > 0 THEN SUBSTRING_INDEX(SUBSTRING(target_table.time, 2), ':', -1) ELSE SUBSTRING(target_table.time, 2) END) > 0 THEN CAST(RPAD(SUBSTRING_INDEX(CASE WHEN LOCATE(':', SUBSTRING(target_table.time, 2)) > 0 THEN SUBSTRING_INDEX(SUBSTRING(target_table.time, 2), ':', -1) ELSE SUBSTRING(target_table.time, 2) END, '.', -1), 3, '0') AS SIGNED) ELSE 0 END) AS SIGNED) WHEN target_table.positionOrder = 1 OR target_table.positionText = '1' THEN (CAST(SUBSTRING_INDEX(target_table.time, ':', 1) AS SIGNED) * 3600000 + CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(target_table.time, ':', 2), ':', -1) AS SIGNED) * 60000 + CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(target_table.time, ':', -1), '.', 1) AS SIGNED) * 1000 + CASE WHEN LOCATE('.', SUBSTRING_INDEX(target_table.time, ':', -1)) > 0 THEN CAST(RPAD(SUBSTRING_INDEX(SUBSTRING_INDEX(target_table.time, ':', -1), '.', -1), 3, '0') AS SIGNED) ELSE 0 END) ELSE NULL END AS computed_value, target_table.milliseconds AS actual_value FROM results AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_results_milliseconds.csv
# For each result (raceId, driverId), milliseconds equals the sum of all lapTimes.milliseconds for that race and driver across the completed laps: results.milliseconds = SUM(lapTimes.milliseconds WHERE lapTimes.raceId = results.raceId AND lapTimes.driverId = results.driverId).
# [across_tables], used_tables: ['lapTimes', 'pitStops']
SELECT lt_sum.value AS computed_value, target_table.milliseconds AS actual_value
FROM results AS target_table
LEFT JOIN (
  SELECT raceId, driverId, SUM(milliseconds) AS value
  FROM lapTimes
  GROUP BY raceId, driverId
) AS lt_sum
  ON lt_sum.raceId = target_table.raceId AND lt_sum.driverId = target_table.driverId;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_round.csv
# round = split_part(mid, '_', 2)
# [row_scope]
SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(target_table.mid, '_', 2), '_', -1) AS computed_value, target_table.`round` AS actual_value FROM matches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_round.csv
# round = 'R' + lpad(DENSE_RANK() OVER (PARTITION BY season ORDER BY week_of_year(start_dt)), 2, '0')
# [row_scope]
SELECT CONCAT('R', LPAD(DENSE_RANK() OVER (PARTITION BY target_table.season ORDER BY WEEKOFYEAR(target_table.start_dt)), 2, '0')) AS computed_value, target_table.round AS actual_value FROM matches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_o_blk.csv
# For each team-season (tmID, lgID, year), team blocks (o_blk) equal the sum of all players? regular-season blocks recorded in players_teams for that same team, league, and season: o_blk(tmID, lgID, year) = SUM(players_teams.blocks WHERE players_teams.tmID = teams.tmID AND players_teams.lgID = teams.lgID AND players_teams.year = teams.year).
# [across_tables], used_tables: ['players_teams']
SELECT COALESCE(pt.sum_blocks, 0) AS computed_value, target_table.o_blk AS actual_value FROM teams AS target_table LEFT JOIN ( SELECT tmID, lgID, year, SUM(CAST(blocks AS SIGNED)) AS sum_blocks FROM players_teams GROUP BY tmID, lgID, year ) AS pt ON pt.tmID = target_table.tmID AND pt.lgID = target_table.lgID AND pt.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_OnlineOrderFlag.csv
# OnlineOrderFlag = CASE WHEN SalesPersonID IS NULL THEN 1 ELSE 0 END
# [row_scope]
SELECT CASE WHEN target_table.SalesPersonID IS NULL THEN 1 ELSE 0 END AS computed_value, target_table.OnlineOrderFlag AS actual_value FROM SalesOrderHeader AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_OnlineOrderFlag.csv
# OnlineOrderFlag = 1 if the related Customer has StoreID IS NULL; otherwise OnlineOrderFlag = 0.
# [across_tables], used_tables: ['Customer']
SELECT
  CASE WHEN c.StoreID IS NULL THEN 1 ELSE 0 END AS computed_value,
  target_table.OnlineOrderFlag AS actual_value
FROM SalesOrderHeader AS target_table
LEFT JOIN Customer AS c
  ON c.CustomerID = target_table.CustomerID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_SalesOrderHeader_OnlineOrderFlag.csv
# OnlineOrderFlag = 1 if and only if the order has no linked SalesReason with ReasonType in ('Marketing','Promotion'); otherwise OnlineOrderFlag = 0.
# [across_tables], used_tables: ['SalesOrderHeaderSalesReason', 'SalesReason']
SELECT
  CASE WHEN COALESCE(non_other.value, 0) = 0 THEN 1 ELSE 0 END AS computed_value,
  target_table.OnlineOrderFlag AS actual_value
FROM SalesOrderHeader AS target_table
LEFT JOIN (
  SELECT sohsr.SalesOrderID, COUNT(*) AS value
  FROM SalesOrderHeaderSalesReason sohsr
  JOIN SalesReason sr ON sr.SalesReasonID = sohsr.SalesReasonID
  WHERE sr.ReasonType IN ('Marketing','Promotion')
  GROUP BY sohsr.SalesOrderID
) AS non_other ON non_other.SalesOrderID = target_table.SalesOrderID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_MarW.csv
# MarW = (hW + rW) - (COALESCE(SepW, 0) + COALESCE(OctW, 0) + COALESCE(NovW, 0) + COALESCE(DecW, 0) + COALESCE(JanW, 0) + COALESCE(FebW, 0) + COALESCE(AprW, 0))
# [row_scope]
SELECT
  (CAST(target_table.hW AS SIGNED) + CAST(target_table.rW AS SIGNED)) - (
    COALESCE(CAST(target_table.SepW AS SIGNED), 0) +
    COALESCE(CAST(target_table.OctW AS SIGNED), 0) +
    COALESCE(CAST(target_table.NovW AS SIGNED), 0) +
    COALESCE(CAST(target_table.DecW AS SIGNED), 0) +
    COALESCE(CAST(target_table.JanW AS SIGNED), 0) +
    COALESCE(CAST(target_table.FebW AS SIGNED), 0) +
    COALESCE(CAST(target_table.AprW AS SIGNED), 0)
  ) AS computed_value,
  target_table.MarW AS actual_value
FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Employee_State.csv
# State = map first letter of PostalCode to Canadian province/territory when Country = 'Canada' (A -> 'NL', B -> 'NS', C -> 'PE', E -> 'NB', G/H/J -> 'QC', K/L/M/N/P -> 'ON', R -> 'MB', S -> 'SK', T -> 'AB', V -> 'BC', X -> 'NT/NU', Y -> 'YT')
# [row_scope]
SELECT CASE WHEN target_table.`Country` = 'Canada' THEN CASE UPPER(SUBSTRING(TRIM(target_table.`PostalCode`), 1, 1)) WHEN 'A' THEN 'NL' WHEN 'B' THEN 'NS' WHEN 'C' THEN 'PE' WHEN 'E' THEN 'NB' WHEN 'G' THEN 'QC' WHEN 'H' THEN 'QC' WHEN 'J' THEN 'QC' WHEN 'K' THEN 'ON' WHEN 'L' THEN 'ON' WHEN 'M' THEN 'ON' WHEN 'N' THEN 'ON' WHEN 'P' THEN 'ON' WHEN 'R' THEN 'MB' WHEN 'S' THEN 'SK' WHEN 'T' THEN 'AB' WHEN 'V' THEN 'BC' WHEN 'X' THEN 'NT/NU' WHEN 'Y' THEN 'YT' ELSE NULL END ELSE NULL END AS computed_value, target_table.`State` AS actual_value FROM `Employee` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Employee_State.csv
# State = map area code extracted from Fax to province when Country = 'Canada' or Fax begins with '+1'; for Alberta: 403, 587, 780, 825 -> 'AB'
# [row_scope]
SELECT CASE WHEN target_table.Country = 'Canada' OR target_table.Fax LIKE '+1%' THEN CASE WHEN (CASE WHEN LEFT(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(target_table.Fax,''),' ',''),'(',''),')',''),'-',''),'+',''), 1) = '1' THEN SUBSTRING(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(target_table.Fax,''),' ',''),'(',''),')',''),'-',''),'+',''), 2, 3) ELSE SUBSTRING(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(COALESCE(target_table.Fax,''),' ',''),'(',''),')',''),'-',''),'+',''), 1, 3) END) IN ('403','587','780','825') THEN 'AB' ELSE NULL END ELSE NULL END AS computed_value, target_table.`State` AS actual_value FROM Employee AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Employee_State.csv
# For each employee E, set State to the most frequent Customer.State among customers C where C.Country = E.Country and C.City = E.City.
# [across_tables], used_tables: ['Customer']
SELECT city_map.state AS computed_value, target_table.State AS actual_value
FROM Employee AS target_table
LEFT JOIN (
  SELECT country, city, state
  FROM (
    SELECT country, city, state, cnt,
           ROW_NUMBER() OVER (PARTITION BY country, city ORDER BY cnt DESC, state) AS rn
    FROM (
      SELECT country, city, state, COUNT(*) AS cnt
      FROM Customer
      WHERE state IS NOT NULL AND city IS NOT NULL
      GROUP BY country, city, state
    ) AS counts
  ) AS ranked
  WHERE rn = 1
) AS city_map
ON target_table.Country = city_map.country
AND target_table.City = city_map.city;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Employee_State.csv
# State = map City to province within Country; for Canada: if City = 'Calgary' then 'AB'
# [row_scope]
SELECT
  CASE
    WHEN target_table.Country = 'Canada' AND target_table.City = 'Calgary' THEN 'AB'
    ELSE NULL
  END AS computed_value,
  target_table.State AS actual_value
FROM Employee AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_AnswerCount.csv
# AnswerCount = COUNT of rows in posts where ParentId = this_row.Id AND PostTypeId = 2
# [row_scope]
SELECT (SELECT COUNT(*) FROM posts AS p WHERE p.ParentId = target_table.Id AND p.PostTypeId = 2) AS computed_value, target_table.AnswerCount AS actual_value FROM posts AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_rT.csv
# rT = Teams.T - TeamSplits.hT (road ties equal total season ties minus home ties)
# [across_tables], used_tables: ['Teams', 'TeamVsTeam']
SELECT CAST(t.T AS SIGNED) - CAST(target_table.hT AS SIGNED) AS computed_value, target_table.rT AS actual_value FROM TeamSplits AS target_table INNER JOIN Teams AS t ON t.year = target_table.year AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_driverStandings_wins.csv
# nan
# [count_or_exist with data sharing], given_table_name = results
SELECT
  COALESCE(COUNT(DISTINCT r2.raceId), 0) AS computed_value,
  MAX(target_table.wins) AS actual_value
FROM driverStandings AS target_table
LEFT JOIN races AS r0
  ON r0.raceId = target_table.raceId
LEFT JOIN results AS res
  ON res.driverId = target_table.driverId
  AND res.positionText LIKE '1'
LEFT JOIN races AS r2
  ON r2.raceId = res.raceId
  AND r2.year = r0.year
  AND r2.round <= r0.round
GROUP BY target_table.driverStandingsId;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_NovT.csv
# NovT = COALESCE(hT, 0) + COALESCE(rT, 0) - (COALESCE(SepT, 0) + COALESCE(OctT, 0) + COALESCE(DecT, 0) + COALESCE(JanT, 0) + COALESCE(FebT, 0) + COALESCE(MarT, 0) + COALESCE(AprT, 0))
# [row_scope]
SELECT (CAST(COALESCE(target_table.hT, 0) AS SIGNED) + CAST(COALESCE(target_table.rT, 0) AS SIGNED) - (CAST(COALESCE(target_table.SepT, 0) AS SIGNED) + CAST(COALESCE(target_table.OctT, 0) AS SIGNED) + CAST(COALESCE(target_table.DecT, 0) AS SIGNED) + CAST(COALESCE(target_table.JanT, 0) AS SIGNED) + CAST(COALESCE(target_table.FebT, 0) AS SIGNED) + CAST(COALESCE(target_table.MarT, 0) AS SIGNED) + CAST(COALESCE(target_table.AprT, 0) AS SIGNED))) AS computed_value, target_table.NovT AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_MakeFlag.csv
# nan
# [count_or_exist with data sharing], given_table_name = BillOfMaterials
SELECT CASE WHEN COALESCE(bom.cnt, 0) > 0 THEN 1 ELSE 0 END AS computed_value, target_table.MakeFlag AS actual_value FROM `Product` AS target_table LEFT JOIN ( SELECT ProductAssemblyID, COUNT(*) AS cnt FROM `BillOfMaterials` WHERE ProductAssemblyID IS NOT NULL GROUP BY ProductAssemblyID ) AS bom ON bom.ProductAssemblyID = target_table.ProductID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_MakeFlag.csv
# MakeFlag = CASE WHEN DaysToManufacture > 0 THEN 1 ELSE 0 END
# [row_scope]
SELECT CASE WHEN `target_table`.`DaysToManufacture` > 0 THEN 1 ELSE 0 END AS `computed_value`, `target_table`.`MakeFlag` AS `actual_value` FROM `Product` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_AprL.csv
# AprL = (hL + rL) - (coalesce(SepL,0) + coalesce(OctL,0) + coalesce(NovL,0) + coalesce(DecL,0) + coalesce(JanL,0) + coalesce(FebL,0) + coalesce(MarL,0))
# [row_scope]
SELECT (CAST(target_table.hL AS SIGNED) + CAST(target_table.rL AS SIGNED)) - (CAST(COALESCE(target_table.SepL, 0) AS SIGNED) + CAST(COALESCE(target_table.OctL, 0) AS SIGNED) + CAST(COALESCE(target_table.NovL, 0) AS SIGNED) + CAST(COALESCE(target_table.DecL, 0) AS SIGNED) + CAST(COALESCE(target_table.JanL, 0) AS SIGNED) + CAST(COALESCE(target_table.FebL, 0) AS SIGNED) + CAST(COALESCE(target_table.MarL, 0) AS SIGNED)) AS computed_value, target_table.AprL AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_lgID.csv
# For each teams row (year, tmID), set lgID to the modal (most frequent) lgID found in players_teams for the same (year, tmID). If multiple lgID values tie for the mode, pick the alphabetically smallest lgID.
# [across_tables], used_tables: ['players_teams']
SELECT
  exact_mode.lgID AS computed_value,
  target_table.lgID AS actual_value
FROM teams AS target_table
LEFT JOIN (
  SELECT z.tmID, z.year, z.lgID
  FROM (
    SELECT y.tmID, y.year, y.lgID, y.cnt,
           ROW_NUMBER() OVER (PARTITION BY y.tmID, y.year ORDER BY y.cnt DESC, y.lgID ASC) AS rn
    FROM (
      SELECT pt.tmID, pt.year, pt.lgID, COUNT(*) AS cnt
      FROM players_teams AS pt
      GROUP BY pt.tmID, pt.year, pt.lgID
    ) AS y
  ) AS z
  WHERE z.rn = 1
) AS exact_mode
  ON exact_mode.tmID = target_table.tmID AND exact_mode.year = target_table.year
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_lgID.csv
# For each team-season (teams.tmID, teams.year), set computed lgID to the unique league code found in coaches for the same (tmID, year). If no coaches row exists (or no lgID is present), fall back to the league code recorded in awards_coaches for any coach who coached that team in that same season (join coaches on (tmID, year) to get coachID, then awards_coaches on (coachID, year) and take the unique lgID).
# [across_tables], used_tables: ['awards_coaches', 'coaches']
SELECT
  COALESCE(c_by_team_year.lgID, ac_by_team_year.lgID) AS computed_value,
  target_table.lgID AS actual_value
FROM teams AS target_table
LEFT JOIN (
  SELECT tmID, year, MIN(lgID) AS lgID
  FROM coaches
  WHERE lgID IS NOT NULL
  GROUP BY tmID, year
) AS c_by_team_year
  ON c_by_team_year.tmID = target_table.tmID
 AND c_by_team_year.year = target_table.year
LEFT JOIN (
  SELECT c.tmID, c.year, MIN(ac.lgID) AS lgID
  FROM coaches AS c
  JOIN awards_coaches AS ac
    ON ac.coachID = c.coachID
   AND ac.year = c.year
  WHERE ac.lgID IS NOT NULL
  GROUP BY c.tmID, c.year
) AS ac_by_team_year
  ON ac_by_team_year.tmID = target_table.tmID
 AND ac_by_team_year.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Scoring_PostA.csv
# PostA = PostPts - PostG
# [row_scope]
SELECT CAST(target_table.PostPts AS SIGNED) - CAST(target_table.PostG AS SIGNED) AS computed_value, target_table.PostA AS actual_value FROM Scoring AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Scoring_PostA.csv
# For seasons covered by ScoringSC (per playerID and year), a players playoff assists in Scoring (PostA) equal the Stanley Cup assists recorded in ScoringSC (A). Apply the same value to all Scoring rows for that player-year (stints share the same playoff totals). Join keys: Scoring.playerID = ScoringSC.playerID and Scoring.year = ScoringSC.year.
# [across_tables], used_tables: ['ScoringSC']
SELECT
  ssc.A AS computed_value,
  target_table.PostA AS actual_value
FROM Scoring AS target_table
LEFT JOIN ScoringSC AS ssc
  ON ssc.playerID = target_table.playerID
  AND ssc.year = target_table.year
LEFT JOIN Master AS m
  ON m.playerID = target_table.playerID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_player_allstar_three_made.csv
# three_made = points - 2 * fg_made - ft_made
# [row_scope]
SELECT CAST(target_table.points AS SIGNED) - 2 * CAST(target_table.fg_made AS SIGNED) - CAST(target_table.ft_made AS SIGNED) AS computed_value, target_table.three_made AS actual_value FROM player_allstar AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_win_loc.csv
# win_loc = 'h' if lose_loc = 'a' else 'a' if lose_loc = 'h' else 'd'
# [row_scope]
SELECT CASE WHEN target_table.lose_loc = 'a' THEN 'h' WHEN target_table.lose_loc = 'h' THEN 'a' ELSE 'd' END AS computed_value, target_table.win_loc AS actual_value FROM matches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_PTE_pte_atm_bond_count_Cnt.csv
# nan
# [count_or_exist without data sharing], given_table_name = pte_bond
select pte_atm_bond_count.atom_id, pte_atm_bond_count.Cnt actual_value, Count(*) computed_value from  `pte_atm_bond_count` 
LEFT JOIN pte_atm ON `pte_atm`.`atom_id` = `pte_atm_bond_count`.`atom_id`
LEFT JOIN pte_bond ON `pte_bond`.`atom_id1` = `pte_atm`.`atom_id` group by pte_atm_bond_count.atom_id, pte_atm_bond_count.Cnt
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_lose_tid.csv
# lose_tid = CASE WHEN win_tid = tid1 THEN tid2 WHEN win_tid = tid2 THEN tid1 ELSE 100 END
# [row_scope]
SELECT CASE WHEN target_table.win_tid = target_table.tid1 THEN target_table.tid2 WHEN target_table.win_tid = target_table.tid2 THEN target_table.tid1 ELSE 100 END AS computed_value, target_table.lose_tid AS actual_value FROM matches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Coaches_l.csv
# l = g - w - t
# [row_scope]
SELECT (CAST(`target_table`.`g` AS SIGNED) - CAST(`target_table`.`w` AS SIGNED) - CAST(`target_table`.`t` AS SIGNED)) AS computed_value, `target_table`.`l` AS actual_value FROM `Coaches` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Coaches_l.csv
# Alternate derivation using goalies: The coach's regular-season losses equal the total goalie-credited regular-season losses for that team-season minus the combined losses of all other coach stints on that same team-season. Goalies' losses are summed from Goalies.L for the same (year, tmID). Formally: l_current = (SUM_{goalies g on (year, tmID)} Goalies.L_g) - SUM_{other stints s on (year, tmID)}( COALESCE(l_s, g_s - w_s - t_s) ).
# [across_tables], used_tables: ['Teams', 'Goalies']
SELECT
  CAST(COALESCE(gl.goalie_losses, 0) AS SIGNED)
  - CAST(COALESCE(sum_all.sum_losses, 0) AS SIGNED)
  + CAST(COALESCE(target_table.l, CAST(target_table.g AS SIGNED) - CAST(target_table.w AS SIGNED) - CAST(target_table.t AS SIGNED), 0) AS SIGNED) AS computed_value,
  target_table.l AS actual_value
FROM Coaches AS target_table
LEFT JOIN (
  SELECT year, tmID,
         SUM(CAST(L AS SIGNED)) AS goalie_losses
  FROM Goalies
  GROUP BY year, tmID
) AS gl
  ON gl.year = target_table.year AND gl.tmID = target_table.tmID
LEFT JOIN (
  SELECT year, tmID,
         SUM(CAST(COALESCE(l, CAST(g AS SIGNED) - CAST(w AS SIGNED) - CAST(t AS SIGNED)) AS SIGNED)) AS sum_losses
  FROM Coaches
  GROUP BY year, tmID
) AS sum_all
  ON sum_all.year = target_table.year AND sum_all.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Coaches_l.csv
# For a given Coaches row (year, tmID), derive losses directly from the Teams seasonal record: l = Teams.L.
# [across_tables], used_tables: ['Teams', 'TeamVsTeam']
SELECT
  t.`L` AS computed_value,
  target_table.`l` AS actual_value
FROM Coaches AS target_table
JOIN Teams AS t
  ON t.`year` = target_table.`year` AND t.`tmID` = target_table.`tmID`;
###########################################################

###########################################################
# filtered_reported_accuracy_Dallas_incidents_subject_count.csv
# nan
# [count_or_exist without data sharing], given_table_name = subjects
select incidents.case_number, incidents.subject_count actual_value, Count(*) computed_value from  `incidents` 
LEFT JOIN subjects ON `subjects`.`case_number` = `incidents`.`case_number` group by incidents.case_number, incidents.subject_count
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Coaches_t.csv
# t = g - w - l
# [row_scope]
SELECT (CAST(target_table.g AS SIGNED) - CAST(target_table.w AS SIGNED) - CAST(target_table.l AS SIGNED)) AS computed_value, target_table.t AS actual_value FROM Coaches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Coaches_t.csv
# For a given coach-season (coachID, year, tmID, stint), derive regular-season ties t by proportionally allocating the team?s season ties to the coach?s games: t = floor( Teams.T(year, tmID) * Coaches.g / Teams.G(year, tmID) ).
# [across_tables], used_tables: ['TeamVsTeam', 'Teams']
SELECT
  CAST(FLOOR(CAST(team_totals.T AS SIGNED) * CAST(target_table.g AS SIGNED) / NULLIF(CAST(team_totals.G AS SIGNED), 0)) AS SIGNED) AS computed_value,
  target_table.t AS actual_value
FROM Coaches AS target_table
JOIN Teams AS team_totals
  ON team_totals.year = target_table.year
 AND team_totals.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_FinishedGoodsFlag.csv
# FinishedGoodsFlag = CASE WHEN ProductModelID IS NOT NULL THEN 1 ELSE 0 END
# [row_scope]
SELECT CASE WHEN target_table.ProductModelID IS NOT NULL THEN 1 ELSE 0 END AS computed_value, target_table.FinishedGoodsFlag AS actual_value FROM Product AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_FinishedGoodsFlag.csv
# FinishedGoodsFlag = 1 if the product appears in SpecialOfferProduct (i.e., is offered for sale); otherwise 0.
# [across_tables], used_tables: ['SalesOrderDetail', 'SpecialOfferProduct']
SELECT
  CASE WHEN sop.has_offer IS NOT NULL THEN 1 ELSE 0 END AS computed_value,
  target_table.FinishedGoodsFlag AS actual_value
FROM Product AS target_table
LEFT JOIN (
  SELECT ProductID, 1 AS has_offer
  FROM SpecialOfferProduct
  GROUP BY ProductID
) AS sop ON sop.ProductID = target_table.ProductID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_FinishedGoodsFlag.csv
# FinishedGoodsFlag = 1 if (ProductSubcategoryID is not NULL AND ProductModelID is not NULL AND ListPrice > 0) OR the product appears in ShoppingCartItem OR the product appears in ProductReview; otherwise 0.
# [across_tables], used_tables: ['ShoppingCartItem', 'ProductReview']
SELECT CASE WHEN ((target_table.`ProductSubcategoryID` IS NOT NULL AND target_table.`ProductModelID` IS NOT NULL AND target_table.`ListPrice` > 0) OR COALESCE(cart_stats.`cnt_cart`, 0) > 0 OR COALESCE(review_stats.`cnt_reviews`, 0) > 0) THEN 1 ELSE 0 END AS computed_value, target_table.`FinishedGoodsFlag` AS actual_value FROM `Product` AS target_table LEFT JOIN ( SELECT `ProductID`, COUNT(*) AS `cnt_cart` FROM `ShoppingCartItem` GROUP BY `ProductID` ) AS cart_stats ON cart_stats.`ProductID` = target_table.`ProductID` LEFT JOIN ( SELECT `ProductID`, COUNT(*) AS `cnt_reviews` FROM `ProductReview` GROUP BY `ProductID` ) AS review_stats ON review_stats.`ProductID` = target_table.`ProductID`;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_FinishedGoodsFlag.csv
# FinishedGoodsFlag = CASE WHEN ListPrice > 0 THEN 1 ELSE 0 END
# [row_scope]
SELECT CASE WHEN `target_table`.`ListPrice` > 0 THEN 1 ELSE 0 END AS `computed_value`, `target_table`.`FinishedGoodsFlag` AS `actual_value` FROM `Product` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_AprOL.csv
# AprOL = COALESCE(hOTL, 0) + COALESCE(rOTL, 0) - (COALESCE(SepOL, 0) + COALESCE(OctOL, 0) + COALESCE(NovOL, 0) + COALESCE(DecOL, 0) + COALESCE(JanOL, 0) + COALESCE(FebOL, 0) + COALESCE(MarOL, 0))
# [row_scope]
SELECT
  (
    CAST(COALESCE(target_table.hOTL, 0) AS SIGNED) +
    CAST(COALESCE(target_table.rOTL, 0) AS SIGNED) -
    (
      CAST(COALESCE(target_table.SepOL, 0) AS SIGNED) +
      CAST(COALESCE(target_table.OctOL, 0) AS SIGNED) +
      CAST(COALESCE(target_table.NovOL, 0) AS SIGNED) +
      CAST(COALESCE(target_table.DecOL, 0) AS SIGNED) +
      CAST(COALESCE(target_table.JanOL, 0) AS SIGNED) +
      CAST(COALESCE(target_table.FebOL, 0) AS SIGNED) +
      CAST(COALESCE(target_table.MarOL, 0) AS SIGNED)
    )
  ) AS computed_value,
  target_table.AprOL AS actual_value
FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_ProductPhoto_LargePhotoFileName.csv
# LargePhotoFileName = REPLACE(ThumbnailPhotoFileName, '_small', '_large')
# [row_scope]
SELECT REPLACE(target_table.`ThumbnailPhotoFileName`, '_small', '_large') AS computed_value, target_table.`LargePhotoFileName` AS actual_value FROM `ProductPhoto` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_target_win.csv
# nan
# [count_or_exist with data sharing], given_table_name = results
SELECT
  CASE WHEN COUNT(w.resultId) > 0 THEN 1 ELSE 0 END AS computed_value,
  target_table.win AS actual_value
FROM target AS target_table
LEFT JOIN (
  SELECT r.resultId, r.raceId, r.driverId
  FROM results r
  LEFT JOIN status s ON s.statusId = r.statusId
  WHERE s.status LIKE 'Finished'
    AND (r.position = 1 OR r.positionText LIKE '1' OR r.positionOrder = 1)
) AS w
  ON w.raceId = target_table.raceId AND w.driverId = target_table.driverId
GROUP BY target_table.targetId, target_table.win;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_OTL.csv
# OTL = G - W - L - COALESCE(T, 0)
# [row_scope]
SELECT CAST(`target_table`.`G` AS SIGNED) - CAST(`target_table`.`W` AS SIGNED) - CAST(`target_table`.`L` AS SIGNED) - CAST(COALESCE(`target_table`.`T`, 0) AS SIGNED) AS computed_value, `target_table`.`OTL` AS actual_value FROM `Teams` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_Teams_OTL.csv
# For each team-season (year, tmID), OTL equals the total of the coaches 't' column across all coaching stints for that team and season: OTL(year, tmID) = ?_over_stints CAST(Coaches.t AS SIGNED) where Coaches.year = Teams.year and Coaches.tmID = Teams.tmID. (In the shootout era, Coaches.t captures OT/SO losses.)
# [across_tables], used_tables: ['GoaliesShootout', 'Coaches', 'TeamVsTeam']
SELECT coach_tot.value AS computed_value, CAST(target_table.OTL AS SIGNED) AS actual_value
FROM Teams AS target_table
LEFT JOIN (
  SELECT year, tmID, SUM(CAST(t AS SIGNED)) AS value
  FROM Coaches
  GROUP BY year, tmID
) AS coach_tot
  ON coach_tot.year = target_table.year AND coach_tot.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_MarT.csv
# MarT = COALESCE(hT, 0) + COALESCE(rT, 0) - (COALESCE(SepT, 0) + COALESCE(OctT, 0) + COALESCE(NovT, 0) + COALESCE(DecT, 0) + COALESCE(JanT, 0) + COALESCE(FebT, 0) + COALESCE(AprT, 0))
# [row_scope]
SELECT (COALESCE(CAST(target_table.hT AS SIGNED), 0) + COALESCE(CAST(target_table.rT AS SIGNED), 0) - (COALESCE(CAST(target_table.SepT AS SIGNED), 0) + COALESCE(CAST(target_table.OctT AS SIGNED), 0) + COALESCE(CAST(target_table.NovT AS SIGNED), 0) + COALESCE(CAST(target_table.DecT AS SIGNED), 0) + COALESCE(CAST(target_table.JanT AS SIGNED), 0) + COALESCE(CAST(target_table.FebT AS SIGNED), 0) + COALESCE(CAST(target_table.AprT AS SIGNED), 0))) AS computed_value, target_table.MarT AS actual_value FROM TeamSplits AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Dallas_subjects_race.csv
# If the incident has exactly one subject (incidents.subject_count = 1), join incidents on case_number and parse incidents.subjects by taking the last space-delimited token, then return the substring before the slash (the race code) from that token.
# [across_tables], used_tables: ['incidents']
SELECT
  CASE
    WHEN i.subjects IS NOT NULL AND i.subject_count = 1
    THEN SUBSTRING_INDEX(SUBSTRING_INDEX(i.subjects, ' ', -1), '/', 1)
    ELSE NULL
  END AS computed_value,
  target_table.race AS actual_value
FROM subjects AS target_table
LEFT JOIN incidents AS i ON i.case_number = target_table.case_number;
###########################################################

###########################################################
# filtered_reported_accuracy_Chinook_Employee_City.csv
# Normalize the employee?s PostalCode by removing spaces and hyphens and uppercasing it; define FSA as its first three characters. Compute City using external address evidence in this precedence: (1) the most frequent Invoice.BillingCity among all invoices whose normalized BillingPostalCode shares that FSA; if none, (2) the most frequent Customer.City among all customers whose normalized PostalCode shares that FSA; if none, (3) the most frequent City among other Employee rows whose normalized PostalCode shares that FSA.
# [across_tables], used_tables: ['Invoice', 'Customer']
SELECT
  COALESCE(inv_fsa.city, cust_fsa.city, emp_fsa.city) AS computed_value,
  target_table.City AS actual_value
FROM Employee AS target_table
LEFT JOIN (
  SELECT fsa, city
  FROM (
    SELECT fsa, city, cnt,
           ROW_NUMBER() OVER (PARTITION BY fsa ORDER BY cnt DESC, city ASC) AS rn
    FROM (
      SELECT UPPER(LEFT(REPLACE(REPLACE(BillingPostalCode, ' ', ''), '-', ''), 3)) AS fsa,
             BillingCity AS city,
             COUNT(*) AS cnt
      FROM Invoice
      WHERE BillingPostalCode IS NOT NULL
        AND BillingCity IS NOT NULL
      GROUP BY fsa, city
    ) AS g
  ) AS r
  WHERE rn = 1
) AS inv_fsa
  ON inv_fsa.fsa = UPPER(LEFT(REPLACE(REPLACE(target_table.PostalCode, ' ', ''), '-', ''), 3))
LEFT JOIN (
  SELECT fsa, city
  FROM (
    SELECT fsa, city, cnt,
           ROW_NUMBER() OVER (PARTITION BY fsa ORDER BY cnt DESC, city ASC) AS rn
    FROM (
      SELECT UPPER(LEFT(REPLACE(REPLACE(PostalCode, ' ', ''), '-', ''), 3)) AS fsa,
             City AS city,
             COUNT(*) AS cnt
      FROM Customer
      WHERE PostalCode IS NOT NULL
        AND City IS NOT NULL
      GROUP BY fsa, city
    ) AS g
  ) AS r
  WHERE rn = 1
) AS cust_fsa
  ON cust_fsa.fsa = UPPER(LEFT(REPLACE(REPLACE(target_table.PostalCode, ' ', ''), '-', ''), 3))
LEFT JOIN (
  SELECT fsa, city
  FROM (
    SELECT fsa, city, cnt,
           ROW_NUMBER() OVER (PARTITION BY fsa ORDER BY cnt DESC, city ASC) AS rn
    FROM (
      SELECT UPPER(LEFT(REPLACE(REPLACE(PostalCode, ' ', ''), '-', ''), 3)) AS fsa,
             City AS city,
             COUNT(*) AS cnt
      FROM Employee
      WHERE PostalCode IS NOT NULL
        AND City IS NOT NULL
      GROUP BY fsa, city
    ) AS g
  ) AS r
  WHERE rn = 1
) AS emp_fsa
  ON emp_fsa.fsa = UPPER(LEFT(REPLACE(REPLACE(target_table.PostalCode, ' ', ''), '-', ''), 3));
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_qualifying_position.csv
# position = ROW_NUMBER() OVER (PARTITION BY raceId ORDER BY (CASE WHEN q3 IS NOT NULL THEN 3 WHEN q2 IS NOT NULL THEN 2 WHEN q1 IS NOT NULL THEN 1 ELSE 0 END) DESC, parse_time(COALESCE(q3, q2, q1)) ASC NULLS LAST)
# [row_scope]
SELECT
  ROW_NUMBER() OVER (
    PARTITION BY target_table.raceId
    ORDER BY
      CASE
        WHEN target_table.q3 IS NOT NULL THEN 3
        WHEN target_table.q2 IS NOT NULL THEN 2
        WHEN target_table.q1 IS NOT NULL THEN 1
        ELSE 0
      END DESC,
      CASE WHEN COALESCE(target_table.q3, target_table.q2, target_table.q1) IS NULL THEN 1 ELSE 0 END ASC,
      (
        CAST(TRIM(SUBSTRING_INDEX(COALESCE(target_table.q3, target_table.q2, target_table.q1), ':', 1)) AS SIGNED) * 60
        + CAST(TRIM(SUBSTRING_INDEX(COALESCE(target_table.q3, target_table.q2, target_table.q1), ':', -1)) AS DECIMAL(10,3))
      ) ASC
  ) AS computed_value,
  target_table.position AS actual_value
FROM qualifying AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_qualifying_position.csv
# For each qualifying row (raceId, driverId, constructorId), the qualifying.position equals the corresponding results.grid from the results table for the same (raceId, driverId, constructorId).
# [across_tables], used_tables: ['results', 'races']
SELECT r.grid AS computed_value, target_table.position AS actual_value
FROM qualifying AS target_table
JOIN results AS r
  ON r.raceId = target_table.raceId
 AND r.driverId = target_table.driverId
 AND r.constructorId = target_table.constructorId;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Customer_AccountNumber.csv
# AccountNumber = CONCAT('AW', FORMAT(CustomerID, '00000000'))
# [row_scope]
SELECT CONCAT('AW', LPAD(target_table.CustomerID, 8, '0')) AS computed_value, target_table.AccountNumber AS actual_value FROM Customer AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_players_teams_PostdRebounds.csv
# PostdRebounds = PostRebounds - PostoRebounds
# [row_scope]
SELECT CAST(`target_table`.`PostRebounds` AS SIGNED) - CAST(`target_table`.`PostoRebounds` AS SIGNED) AS `computed_value`, `target_table`.`PostdRebounds` AS `actual_value` FROM `players_teams` AS `target_table`;
###########################################################

###########################################################
# filtered_reported_accuracy_ErgastF1_results_fastestLapTime.csv
# For each result (raceId, driverId), fastestLapTime equals the lapTimes.time of the lap whose number equals results.fastestLap for that driver and race.
# [across_tables], used_tables: ['lapTimes', 'pitStops']
SELECT lt.time AS computed_value, target_table.fastestLapTime AS actual_value
FROM results AS target_table
LEFT JOIN lapTimes lt ON lt.raceId = target_table.raceId AND lt.driverId = target_table.driverId AND lt.lap = target_table.fastestLap;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_G.csv
# G = W + L + T
# [row_scope]
SELECT CAST(target_table.`W` AS SIGNED) + CAST(target_table.`L` AS SIGNED) + CAST(target_table.`T` AS SIGNED) AS computed_value, target_table.`G` AS actual_value FROM `TeamsPost` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_G.csv
# For each (year, lgID, tmID), postseason team games G equals the maximum player postseason games played recorded in Scoring (PostGP) for that same (year, lgID, tmID). I.e., G = max_over_players_in_team_year(CAST(Scoring.PostGP AS SIGNED)).
# [across_tables], used_tables: ['Scoring']
SELECT smax.max_postgp AS computed_value, target_table.G AS actual_value FROM TeamsPost AS target_table LEFT JOIN (  SELECT s.year, s.lgID, s.tmID, MAX(CAST(s.PostGP AS SIGNED)) AS max_postgp   FROM Scoring s   JOIN Teams t ON t.year = s.year AND t.tmID = s.tmID AND t.lgID = s.lgID   WHERE s.PostGP IS NOT NULL   GROUP BY s.year, s.lgID, s.tmID ) AS smax  ON smax.year = target_table.year AND smax.lgID = target_table.lgID AND smax.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_G.csv
# For a given (year, tmID), postseason games played G equals the sum over all goalies on that team of their postseason decisions: G = ?_goalies (PostW + PostL + PostT). Join Goalies to TeamsPost by (year, tmID) to aggregate these goalie decisions for the team-season; Teams is joined only to anchor the team-season context.
# [across_tables], used_tables: ['Goalies']
SELECT goalie_decisions.value AS computed_value, target_table.G AS actual_value
FROM TeamsPost AS target_table
LEFT JOIN Teams AS t
  ON t.year = target_table.year AND t.tmID = target_table.tmID
LEFT JOIN (
  SELECT year, tmID,
         SUM(
           COALESCE(CAST(PostW AS SIGNED), 0) +
           COALESCE(CAST(PostL AS SIGNED), 0) +
           COALESCE(CAST(PostT AS SIGNED), 0)
         ) AS value
  FROM Goalies
  GROUP BY year, tmID
) AS goalie_decisions
  ON goalie_decisions.year = target_table.year AND goalie_decisions.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_G.csv
# For each TeamsPost row (year, lgID, tmID), compute G as the total number of playoff games the team played within its own league that year by summing (W + L + T) over all SeriesPost rows where both leagues match the team?s league (lgIDWinner = lgIDLoser = TeamsPost.lgID) and the team appears either as tmIDWinner or tmIDLoser. Formally: G = sum_{SeriesPost where year matches and lgIDWinner = lgIDLoser = target lgID and (tmIDWinner = target tmID or tmIDLoser = target tmID)} (W + L + T).
# [across_tables], used_tables: ['GoaliesSC', 'SeriesPost']
SELECT (COALESCE(win_games.games, 0) + COALESCE(lose_games.games, 0)) AS computed_value, target_table.G AS actual_value
FROM TeamsPost AS target_table
LEFT JOIN (
  SELECT year, lgIDWinner AS lgID, tmIDWinner AS tmID,
         SUM(CAST(COALESCE(W, 0) AS SIGNED) + CAST(COALESCE(L, 0) AS SIGNED) + CAST(COALESCE(T, 0) AS SIGNED)) AS games
  FROM SeriesPost
  WHERE lgIDWinner IS NOT NULL AND lgIDLoser IS NOT NULL AND lgIDWinner = lgIDLoser
  GROUP BY year, lgID, tmID
) AS win_games
  ON win_games.year = target_table.year AND win_games.lgID = target_table.lgID AND win_games.tmID = target_table.tmID
LEFT JOIN (
  SELECT year, lgIDLoser AS lgID, tmIDLoser AS tmID,
         SUM(CAST(COALESCE(W, 0) AS SIGNED) + CAST(COALESCE(L, 0) AS SIGNED) + CAST(COALESCE(T, 0) AS SIGNED)) AS games
  FROM SeriesPost
  WHERE lgIDWinner IS NOT NULL AND lgIDLoser IS NOT NULL AND lgIDWinner = lgIDLoser
  GROUP BY year, lgID, tmID
) AS lose_games
  ON lose_games.year = target_table.year AND lose_games.lgID = target_table.lgID AND lose_games.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamsPost_G.csv
# For each (year, tmID) in TeamsPost, G equals the sum of Coaches.postg (postseason games coached) across all coach stints for the same team-year and league. Concretely: G(year, tmID) = SUM_{c in Coaches where c.year = year AND c.tmID = tmID AND c.lgID = Teams.lgID}(CAST(c.postg AS SIGNED)).
# [across_tables], used_tables: ['Coaches']
SELECT
  coach_postg.value AS computed_value,
  target_table.G AS actual_value
FROM TeamsPost AS target_table
LEFT JOIN Teams AS t
  ON t.year = target_table.year AND t.tmID = target_table.tmID
LEFT JOIN (
  SELECT year, tmID, lgID, SUM(CAST(postg AS SIGNED)) AS value
  FROM Coaches
  WHERE postg IS NOT NULL
  GROUP BY year, tmID, lgID
) AS coach_postg
  ON coach_postg.year = target_table.year
 AND coach_postg.tmID = target_table.tmID
 AND coach_postg.lgID = t.lgID;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_PurchaseOrderDetail_StockedQty.csv
# StockedQty = ReceivedQty - RejectedQty
# [row_scope]
SELECT (CAST(target_table.`ReceivedQty` AS DECIMAL(65,30)) - CAST(target_table.`RejectedQty` AS DECIMAL(65,30))) AS computed_value, target_table.`StockedQty` AS actual_value FROM `PurchaseOrderDetail` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_GoaliesSC_GP.csv
# GP = CASE WHEN (W + L + T) > 0 THEN (W + L + T) WHEN Min > 0 THEN 1 ELSE 0 END
# [row_scope]
SELECT CASE WHEN (CAST(target_table.W AS SIGNED) + CAST(target_table.L AS SIGNED) + CAST(target_table.T AS SIGNED)) > 0 THEN (CAST(target_table.W AS SIGNED) + CAST(target_table.L AS SIGNED) + CAST(target_table.T AS SIGNED)) WHEN CAST(target_table.`Min` AS SIGNED) > 0 THEN 1 ELSE 0 END AS computed_value, target_table.GP AS actual_value FROM GoaliesSC AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_GoaliesSC_GP.csv
# For each GoaliesSC row (playerID, year, tmID, lgID), GP equals the Games Played recorded for that same (playerID, year, tmID, lgID) in ScoringSC when the player is a goalie, determined by ScoringSC.pos = 'G' or Master.pos = 'G'.
# [across_tables], used_tables: ['ScoringSC']
SELECT s_gp.value AS computed_value, target_table.GP AS actual_value
FROM `GoaliesSC` AS target_table
LEFT JOIN (
  SELECT s.playerID, s.year, s.tmID, s.lgID, SUM(CAST(s.GP AS SIGNED)) AS value
  FROM `ScoringSC` AS s
  LEFT JOIN `Master` AS m ON m.playerID = s.playerID
  WHERE s.pos = 'G' OR m.pos = 'G'
  GROUP BY s.playerID, s.year, s.tmID, s.lgID
) AS s_gp
  ON s_gp.playerID = target_table.playerID
 AND s_gp.year = target_table.year
 AND s_gp.tmID = target_table.tmID
 AND s_gp.lgID = target_table.lgID;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_GoaliesSC_GP.csv
# For a given goalie-season-team tuple (playerID, year, lgID, tmID), GP equals the total number of Stanley Cup games that the team played that season: GP = TeamsSC.G where TeamsSC is matched on (year, lgID, tmID).
# [across_tables], used_tables: ['TeamsSC']
SELECT ts.G AS computed_value, target_table.GP AS actual_value
FROM GoaliesSC AS target_table
LEFT JOIN TeamsSC AS ts
  ON ts.year = target_table.year
 AND ts.lgID = target_table.lgID
 AND ts.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_AcceptedAnswerId.csv
# For each question post (posts.PostTypeId = 1), the AcceptedAnswerId equals the Id of the answer post (posts.PostTypeId = 2 and posts.ParentId = question.Id) that has a vote of type 'AcceptedByOriginator' (votes.VoteTypeId = 1). If more than one such record exists, choose the smallest answer Id.
# [across_tables], used_tables: ['votes', 'postHistory']
SELECT
  accepted_by_votes.answer_id AS computed_value,
  target_table.AcceptedAnswerId AS actual_value
FROM posts AS target_table
LEFT JOIN (
  SELECT pa.ParentId AS question_id, MIN(pa.Id) AS answer_id
  FROM posts AS pa
  INNER JOIN votes AS v
    ON v.PostId = pa.Id AND v.VoteTypeId = 1
  WHERE pa.PostTypeId = 2
  GROUP BY pa.ParentId
) AS accepted_by_votes
  ON accepted_by_votes.question_id = target_table.Id
WHERE target_table.PostTypeId = 1;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_AcceptedAnswerId.csv
# For each question post q (posts.PostTypeId = 1), choose the answer a (posts.PostTypeId = 2 and posts.ParentId = q.Id) with the highest Score; break ties by the earliest initial creation time of the answer in postHistory (MIN(postHistory.CreationDate) where PostHistoryTypeId IN (1,2)); if still tied, choose the lowest answer Id. The chosen a.Id is the computed AcceptedAnswerId.
# [across_tables], used_tables: ['postHistory']
SELECT (SELECT a.Id FROM posts AS a JOIN (SELECT ph.PostId, MIN(ph.CreationDate) AS min_creation FROM postHistory AS ph WHERE ph.PostHistoryTypeId IN (1,2) GROUP BY ph.PostId) AS ph ON ph.PostId = a.Id WHERE a.PostTypeId = 2 AND a.ParentId = target_table.Id ORDER BY a.Score DESC, ph.min_creation ASC, a.Id ASC LIMIT 1) AS computed_value, target_table.AcceptedAnswerId AS actual_value FROM posts AS target_table WHERE target_table.PostTypeId = 1
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_AcceptedAnswerId.csv
# For each question post (posts.PostTypeId = 1), the AcceptedAnswerId equals the Id of the answer post (posts.PostTypeId = 2 and posts.ParentId = question.Id) that has the highest number of upvote records (votes.VoteTypeId = 2). In case of ties, choose the smallest answer Id.
# [across_tables], used_tables: ['votes', 'postHistory']
SELECT
  most_upvoted.answer_id AS computed_value,
  target_table.AcceptedAnswerId AS actual_value
FROM posts AS target_table
LEFT JOIN (
  SELECT c.ParentId AS question_id, MIN(c.Id) AS answer_id
  FROM (
    SELECT pa.Id, pa.ParentId, COUNT(*) AS upvotes
    FROM posts AS pa
    INNER JOIN votes AS v
      ON v.PostId = pa.Id AND v.VoteTypeId = 2
    WHERE pa.PostTypeId = 2
    GROUP BY pa.Id, pa.ParentId
  ) AS c
  INNER JOIN (
    SELECT c2.ParentId AS question_id, MAX(c2.upvotes) AS max_upvotes
    FROM (
      SELECT pa.Id, pa.ParentId, COUNT(*) AS upvotes
      FROM posts AS pa
      INNER JOIN votes AS v
        ON v.PostId = pa.Id AND v.VoteTypeId = 2
      WHERE pa.PostTypeId = 2
      GROUP BY pa.Id, pa.ParentId
    ) AS c2
    GROUP BY c2.ParentId
  ) AS m
    ON m.question_id = c.ParentId AND m.max_upvotes = c.upvotes
  GROUP BY c.ParentId
) AS most_upvoted
  ON most_upvoted.question_id = target_table.Id
WHERE target_table.PostTypeId = 1;
###########################################################

###########################################################
# filtered_reported_accuracy_stats_posts_AcceptedAnswerId.csv
# For each question: among its answers, select the answer with the highest number of comments attached to that answer (comments.PostId = answer.Id). If multiple answers share that maximum comment count, prefer the one with the highest Score. If still tied, choose the earliest-created answer (minimum posts.CreaionDate).
# [across_tables], used_tables: ['comments']
SELECT chosen.answer_id AS computed_value, target_table.AcceptedAnswerId AS actual_value FROM posts AS target_table LEFT JOIN (  SELECT final_choice.question_id, final_choice.answer_id   FROM (    SELECT tbs.question_id, tbs.answer_id     FROM (      SELECT tbc_max.question_id, tbc_max.answer_id, tbc_max.CreaionDate       FROM (        SELECT awc.question_id, awc.answer_id, awc.Score, awc.CreaionDate, awc.ccount         FROM (          SELECT p.ParentId AS question_id, p.Id AS answer_id, p.Score, p.CreaionDate, IFNULL(cc.ccount, 0) AS ccount           FROM posts p           LEFT JOIN (            SELECT c.PostId AS answer_id, COUNT(*) AS ccount             FROM comments c             GROUP BY c.PostId           ) cc           ON cc.answer_id = p.Id           WHERE p.PostTypeId = 2 AND p.ParentId IS NOT NULL         ) awc         JOIN (          SELECT awc.question_id, MAX(awc.ccount) AS max_ccount           FROM (            SELECT p.ParentId AS question_id, p.Id AS answer_id, IFNULL(cc.ccount, 0) AS ccount             FROM posts p             LEFT JOIN (              SELECT c.PostId AS answer_id, COUNT(*) AS ccount               FROM comments c               GROUP BY c.PostId             ) cc             ON cc.answer_id = p.Id             WHERE p.PostTypeId = 2 AND p.ParentId IS NOT NULL           ) awc           GROUP BY awc.question_id         ) m1         ON awc.question_id = m1.question_id AND awc.ccount = m1.max_ccount       ) tbc_max       JOIN (        SELECT tbc.question_id, MAX(tbc.Score) AS max_score         FROM (          SELECT awc.question_id, awc.Score           FROM (            SELECT p.ParentId AS question_id, p.Id AS answer_id, p.Score, IFNULL(cc.ccount, 0) AS ccount             FROM posts p             LEFT JOIN (              SELECT c.PostId AS answer_id, COUNT(*) AS ccount               FROM comments c               GROUP BY c.PostId             ) cc             ON cc.answer_id = p.Id             WHERE p.PostTypeId = 2 AND p.ParentId IS NOT NULL           ) awc           JOIN (            SELECT awc.question_id, MAX(awc.ccount) AS max_ccount             FROM (              SELECT p.ParentId AS question_id, p.Id AS answer_id, IFNULL(cc.ccount, 0) AS ccount               FROM posts p               LEFT JOIN (                SELECT c.PostId AS answer_id, COUNT(*) AS ccount                 FROM comments c                 GROUP BY c.PostId               ) cc               ON cc.answer_id = p.Id               WHERE p.PostTypeId = 2 AND p.ParentId IS NOT NULL             ) awc             GROUP BY awc.question_id           ) m1           ON awc.question_id = m1.question_id AND awc.ccount = m1.max_ccount         ) tbc         GROUP BY tbc.question_id       ) ms2       ON tbc_max.question_id = ms2.question_id AND tbc_max.Score = ms2.max_score     ) tbs     JOIN (      SELECT question_id, MIN(CreaionDate) AS min_creation       FROM (        SELECT tbc.question_id, tbc.CreaionDate         FROM (          SELECT awc.question_id, awc.answer_id, awc.Score, awc.CreaionDate, awc.ccount           FROM (            SELECT p.ParentId AS question_id, p.Id AS answer_id, p.Score, p.CreaionDate, IFNULL(cc.ccount, 0) AS ccount             FROM posts p             LEFT JOIN (              SELECT c.PostId AS answer_id, COUNT(*) AS ccount               FROM comments c               GROUP BY c.PostId             ) cc             ON cc.answer_id = p.Id             WHERE p.PostTypeId = 2 AND p.ParentId IS NOT NULL           ) awc           JOIN (            SELECT awc.question_id, MAX(awc.ccount) AS max_ccount             FROM (              SELECT p.ParentId AS question_id, p.Id AS answer_id, IFNULL(cc.ccount, 0) AS ccount               FROM posts p               LEFT JOIN (                SELECT c.PostId AS answer_id, COUNT(*) AS ccount                 FROM comments c                 GROUP BY c.PostId               ) cc               ON cc.answer_id = p.Id               WHERE p.PostTypeId = 2 AND p.ParentId IS NOT NULL             ) awc             GROUP BY awc.question_id           ) m1           ON awc.question_id = m1.question_id AND awc.ccount = m1.max_ccount         ) tbc         JOIN (          SELECT question_id, MAX(Score) AS max_score           FROM (            SELECT awc.question_id, awc.Score             FROM (              SELECT p.ParentId AS question_id, p.Id AS answer_id, p.Score, IFNULL(cc.ccount, 0) AS ccount               FROM posts p               LEFT JOIN (                SELECT c.PostId AS answer_id, COUNT(*) AS ccount                 FROM comments c                 GROUP BY c.PostId               ) cc               ON cc.answer_id = p.Id               WHERE p.PostTypeId = 2 AND p.ParentId IS NOT NULL             ) awc             JOIN (              SELECT awc.question_id, MAX(awc.ccount) AS max_ccount               FROM (                SELECT p.ParentId AS question_id, p.Id AS answer_id, IFNULL(cc.ccount, 0) AS ccount                 FROM posts p                 LEFT JOIN (                  SELECT c.PostId AS answer_id, COUNT(*) AS ccount                   FROM comments c                   GROUP BY c.PostId                 ) cc                 ON cc.answer_id = p.Id                 WHERE p.PostTypeId = 2 AND p.ParentId IS NOT NULL               ) awc               GROUP BY awc.question_id             ) m1             ON awc.question_id = m1.question_id AND awc.ccount = m1.max_ccount           ) sc           GROUP BY question_id         ) ms2         ON tbc.question_id = ms2.question_id AND tbc.Score = ms2.max_score       ) z       GROUP BY question_id     ) earliest     ON tbs.question_id = earliest.question_id AND tbs.CreaionDate = earliest.min_creation   ) final_choice ) chosen ON chosen.question_id = target_table.Id WHERE target_table.PostTypeId = 1;
###########################################################

###########################################################
# filtered_reported_accuracy_AdventureWorks2014_Product_ReorderPoint.csv
# ReorderPoint = 0.75 * SafetyStockLevel
# [row_scope]
SELECT (CAST(target_table.SafetyStockLevel AS SIGNED) * 0.75) AS computed_value, target_table.ReorderPoint AS actual_value FROM `Product` AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_AustralianFootball_matches_lose_loc.csv
# lose_loc = (win_loc == 'd') ? 'd' : (win_loc == 'h' ? 'a' : 'h')
# [row_scope]
SELECT CASE WHEN target_table.win_loc = 'd' THEN 'd' WHEN target_table.win_loc = 'h' THEN 'a' ELSE 'h' END AS computed_value, target_table.lose_loc AS actual_value FROM matches AS target_table;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_min.csv
# For each team-year (tmID, year), team minutes (min) equal the sum of regular-season player minutes recorded in players_teams for that same team and year: min = SUM(players_teams.minutes) WHERE players_teams.tmID = teams.tmID AND players_teams.year = teams.year.
# [across_tables], used_tables: ['players_teams', 'series_post']
SELECT p_sum.sum_minutes AS computed_value, target_table.min AS actual_value
FROM teams AS target_table
LEFT JOIN (
  SELECT tmID, year, SUM(minutes) AS sum_minutes
  FROM players_teams
  GROUP BY tmID, year
) AS p_sum
  ON p_sum.tmID = target_table.tmID
 AND p_sum.year = target_table.year;
###########################################################

###########################################################
# filtered_reported_accuracy_Hockey_TeamSplits_rL.csv
# For each (year, tmID), rL = Teams.L - TeamSplits.hL. Rationale: total regulation losses (L) split into home (hL) and road (rL), while overtime/shootout losses are tracked separately in OTL columns.
# [across_tables], used_tables: ['Teams']
SELECT
  (CAST(t.L AS SIGNED) - CAST(target_table.hL AS SIGNED)) AS computed_value,
  target_table.rL AS actual_value
FROM TeamSplits AS target_table
JOIN Teams AS t
  ON t.year = target_table.year
 AND t.tmID = target_table.tmID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_lost.csv
# For each team-season (year, tmID, lgID), lost equals the sum of all coaches.lost for that same (year, tmID, lgID) across all stints.
# [across_tables], used_tables: ['coaches']
SELECT losses.value AS computed_value, target_table.lost AS actual_value FROM teams AS target_table LEFT JOIN ( SELECT year, tmID, lgID, SUM(lost) AS value FROM coaches GROUP BY year, tmID, lgID ) AS losses ON losses.year = target_table.year AND losses.tmID = target_table.tmID AND losses.lgID = target_table.lgID;
###########################################################

###########################################################
# filtered_reported_accuracy_Basketball_men_teams_lost.csv
# lost = games - won
# [row_scope]
SELECT CAST(target_table.games AS SIGNED) - CAST(target_table.won AS SIGNED) AS computed_value, target_table.lost AS actual_value FROM teams AS target_table;
###########################################################


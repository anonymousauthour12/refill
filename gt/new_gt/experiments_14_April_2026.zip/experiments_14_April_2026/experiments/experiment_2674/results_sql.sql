# ErgastF1	constructorStandings	positionText	-1
-- Not computed
###########################################################
# ErgastF1	constructors	name	-1
-- Not computed
###########################################################
# ErgastF1	constructors	nationality	-1
-- Not computed
###########################################################
# ErgastF1	constructors	url	-1
-- Not computed
###########################################################
# ErgastF1	driverStandings	positionText	-1
-- Not computed
###########################################################
# ErgastF1	drivers	code	-1
-- Not computed
###########################################################
# ErgastF1	drivers	surname	-1
-- Not computed
###########################################################
# ErgastF1	drivers	dob	-1
-- Not computed
###########################################################
# ErgastF1	drivers	nationality	-1
-- Not computed
###########################################################
# ErgastF1	pitStops	time	-1
-- Not computed
###########################################################
# ErgastF1	qualifying	q1	-1
-- Not computed
###########################################################
# ErgastF1	qualifying	q2	-1
-- Not computed
###########################################################
# ErgastF1	qualifying	q3	-1
-- Not computed
###########################################################
# ErgastF1	races	date	-1
-- Not computed
###########################################################
# ErgastF1	races	time	-1
-- Not computed
###########################################################
# ErgastF1	results	number	-1
-- Not computed
###########################################################
# ErgastF1	results	grid	-1
-- Not computed
###########################################################
# ErgastF1	results	positionOrder	-1
-- Not computed
###########################################################
# ErgastF1	results	points	-1
-- Not computed
###########################################################
# ErgastF1	results	laps	-1
-- Not computed
###########################################################
# ErgastF1	results	time	-1
-- Not computed
###########################################################
# ErgastF1	results	fastestLapSpeed	-1
-- Not computed
###########################################################
# ErgastF1	status	status	-1
-- Not computed
###########################################################
# GOSales	go_daily_sales	Retailer code	-1
-- Not computed
###########################################################
# GOSales	go_daily_sales	Product number	-1
-- Not computed
###########################################################
# GOSales	go_daily_sales	Date	-1
-- Not computed
###########################################################
# GOSales	go_daily_sales	Unit sale price	-1
-- Not computed
###########################################################
# GOSales	go_methods	Order method type	-1
-- Not computed
###########################################################
# GOSales	go_products	Product	-1
-- Not computed
###########################################################
# GOSales	go_products	Product color	-1
-- Not computed
###########################################################
# GOSales	go_products	Unit cost	-1
-- Not computed
###########################################################
# GOSales	go_products	Unit price	-1
-- Not computed
###########################################################
# GOSales	go_retailers	Retailer name	-1
-- Not computed
###########################################################
# GOSales	go_retailers	Type	-1
-- Not computed
###########################################################
# GOSales	go_retailers	Country	-1
-- Not computed
###########################################################
# Hockey	AwardsCoaches	award	-1
-- Not computed
###########################################################
# Hockey	AwardsCoaches	year	-1
-- Not computed
###########################################################
# Hockey	AwardsCoaches	note	-1
-- Not computed
###########################################################
# Hockey	AwardsMisc	award	-1
-- Not computed
###########################################################
# Hockey	AwardsMisc	year	-1
-- Not computed
###########################################################
# Hockey	Coaches	notes	-1
-- Not computed
###########################################################
# Hockey	Coaches	g	-1
-- Not computed
###########################################################
# Hockey	CombinedShutouts	year	-1
-- Not computed
###########################################################
# Hockey	CombinedShutouts	month	-1
-- Not computed
###########################################################
# Hockey	CombinedShutouts	date	-1
-- Not computed
###########################################################
# Hockey	CombinedShutouts	oppID	-1
-- Not computed
###########################################################
# Hockey	Goalies	GP	-1
-- Not computed
###########################################################
# Hockey	Goalies	Min	-1
-- Not computed
###########################################################
# Hockey	Goalies	W	-1
-- Not computed
###########################################################
# Hockey	Goalies	L	-1
-- Not computed
###########################################################
# Hockey	Goalies	ENG	-1
-- Not computed
###########################################################
# Hockey	Goalies	SHO	-1
-- Not computed
###########################################################
# Hockey	Goalies	GA	-1
-- Not computed
###########################################################
# Hockey	Goalies	SA	-1
-- Not computed
###########################################################
# Hockey	Goalies	PostGP	-1
-- Not computed
###########################################################
# Hockey	Goalies	PostMin	-1
-- Not computed
###########################################################
# Hockey	Goalies	PostW	-1
-- Not computed
###########################################################
# Hockey	Goalies	PostL	-1
-- Not computed
###########################################################
# Hockey	Goalies	PostENG	-1
-- Not computed
###########################################################
# Hockey	Goalies	PostSHO	-1
-- Not computed
###########################################################
# Hockey	Goalies	PostGA	-1
-- Not computed
###########################################################
# Hockey	Goalies	PostSA	-1
-- Not computed
###########################################################
# Hockey	GoaliesSC	Min	-1
-- Not computed
###########################################################
# Hockey	GoaliesSC	SHO	-1
-- Not computed
###########################################################
# Hockey	GoaliesSC	GA	-1
-- Not computed
###########################################################
# Hockey	GoaliesShootout	stint	-1
-- Not computed
###########################################################
# Hockey	GoaliesShootout	W	-1
-- Not computed
###########################################################
# Hockey	GoaliesShootout	L	-1
-- Not computed
###########################################################
# Hockey	GoaliesShootout	SA	-1
-- Not computed
###########################################################
# Hockey	GoaliesShootout	GA	-1
-- Not computed
###########################################################
# Hockey	HOF	year	-1
-- Not computed
###########################################################
# Hockey	HOF	category	-1
-- Not computed
###########################################################
# Hockey	Master	lastName	-1
-- Not computed
###########################################################
# Hockey	Master	nameNote	-1
-- Not computed
###########################################################
# Hockey	Master	nameGiven	-1
-- Not computed
###########################################################
# Hockey	Master	nameNick	-1
-- Not computed
###########################################################
# Hockey	Master	height	-1
-- Not computed
###########################################################
# Hockey	Master	weight	-1
-- Not computed
###########################################################
# Hockey	Master	shootCatch	-1
-- Not computed
###########################################################
# Hockey	Master	legendsID	-1
-- Not computed
###########################################################
# Hockey	Master	ihdbID	-1
-- Not computed
###########################################################
# Hockey	Master	birthYear	-1
-- Not computed
###########################################################
# Hockey	Master	birthMon	-1
-- Not computed
###########################################################
# Hockey	Master	birthDay	-1
-- Not computed
###########################################################
# Hockey	Master	birthState	-1
-- Not computed
###########################################################
# Hockey	Master	birthCity	-1
-- Not computed
###########################################################
# Hockey	Master	deathYear	-1
-- Not computed
###########################################################
# Hockey	Master	deathMon	-1
-- Not computed
###########################################################
# Hockey	Master	deathDay	-1
-- Not computed
###########################################################
# Hockey	Master	deathState	-1
-- Not computed
###########################################################
# Hockey	Master	deathCity	-1
-- Not computed
###########################################################
# Hockey	Scoring	stint	-1
-- Not computed
###########################################################
# Hockey	Scoring	pos	-1
-- Not computed
###########################################################
# Hockey	Scoring	GP	-1
-- Not computed
###########################################################
# Hockey	Scoring	PIM	-1
-- Not computed
###########################################################
# Hockey	Scoring	PPG	-1
-- Not computed
###########################################################
# Hockey	Scoring	PPA	-1
-- Not computed
###########################################################
# Hockey	Scoring	SHG	-1
-- Not computed
###########################################################
# Hockey	Scoring	SHA	-1
-- Not computed
###########################################################
# Hockey	Scoring	GWG	-1
-- Not computed
###########################################################
# Hockey	Scoring	GTG	-1
-- Not computed
###########################################################
# Hockey	Scoring	SOG	-1
-- Not computed
###########################################################
# Hockey	Scoring	PostGP	-1
-- Not computed
###########################################################
# Hockey	Scoring	PostPIM	-1
-- Not computed
###########################################################
# Hockey	Scoring	PostPPG	-1
-- Not computed
###########################################################
# Hockey	Scoring	PostPPA	-1
-- Not computed
###########################################################
# Hockey	Scoring	PostSHG	-1
-- Not computed
###########################################################
# Hockey	Scoring	PostSHA	-1
-- Not computed
###########################################################
# Hockey	Scoring	PostGWG	-1
-- Not computed
###########################################################
# Hockey	Scoring	PostSOG	-1
-- Not computed
###########################################################
# Hockey	ScoringSC	GP	-1
-- Not computed
###########################################################
# Hockey	ScoringSC	PIM	-1
-- Not computed
###########################################################
# Hockey	ScoringShootout	stint	-1
-- Not computed
###########################################################
# Hockey	ScoringShootout	S	-1
-- Not computed
###########################################################
# Hockey	ScoringShootout	G	-1
-- Not computed
###########################################################
# Hockey	ScoringShootout	GDG	-1
-- Not computed
###########################################################
# Hockey	ScoringSup	PPA	-1
-- Not computed
###########################################################
# Hockey	SeriesPost	round	-1
-- Not computed
###########################################################
# Hockey	SeriesPost	L	-1
-- Not computed
###########################################################
# Hockey	SeriesPost	T	-1
-- Not computed
###########################################################
# Hockey	SeriesPost	GoalsWinner	-1
-- Not computed
###########################################################
# Hockey	SeriesPost	GoalsLoser	-1
-- Not computed
###########################################################
# Hockey	SeriesPost	note	-1
-- Not computed
###########################################################
# Hockey	TeamSplits	SepL	-1
-- Not computed
###########################################################
# Hockey	TeamSplits	FebW	-1
-- Not computed
###########################################################
# Hockey	TeamVsTeam	T	-1
-- Not computed
###########################################################
# Hockey	Teams	divID	-1
-- Not computed
###########################################################
# Hockey	Teams	name	-1
-- Not computed
###########################################################
# Hockey	Teams	BenchMinor	-1
-- Not computed
###########################################################
# Hockey	Teams	PPC	-1
-- Not computed
###########################################################
# Hockey	Teams	SHA	-1
-- Not computed
###########################################################
# Hockey	Teams	PKG	-1
-- Not computed
###########################################################
# Hockey	Teams	PKC	-1
-- Not computed
###########################################################
# Hockey	TeamsPost	BenchMinor	-1
-- Not computed
###########################################################
# Hockey	TeamsPost	PPC	-1
-- Not computed
###########################################################
# Hockey	TeamsPost	SHA	-1
-- Not computed
###########################################################
# Hockey	TeamsPost	PKG	-1
-- Not computed
###########################################################
# Hockey	TeamsPost	PKC	-1
-- Not computed
###########################################################
# Hockey	abbrev	Fullname	-1
-- Not computed
###########################################################
# AdventureWorks2014	AWBuildVersion	Database Version	-1
-- Not computed
###########################################################
# AdventureWorks2014	AWBuildVersion	VersionDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	AWBuildVersion	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Address	AddressLine1	-1
-- Not computed
###########################################################
# AdventureWorks2014	Address	AddressLine2	-1
-- Not computed
###########################################################
# AdventureWorks2014	Address	City	-1
-- Not computed
###########################################################
# AdventureWorks2014	Address	PostalCode	-1
-- Not computed
###########################################################
# AdventureWorks2014	Address	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	Address	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	AddressType	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	AddressType	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	AddressType	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	BillOfMaterials	StartDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	BillOfMaterials	PerAssemblyQty	-1
-- Not computed
###########################################################
# AdventureWorks2014	BillOfMaterials	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	BusinessEntity	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	BusinessEntity	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	BusinessEntityAddress	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	BusinessEntityAddress	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	BusinessEntityContact	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	BusinessEntityContact	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ContactType	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	ContactType	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	CountryRegion	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	CountryRegion	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	CountryRegionCurrency	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	CreditCard	CardNumber	-1
-- Not computed
###########################################################
# AdventureWorks2014	CreditCard	ExpMonth	-1
-- Not computed
###########################################################
# AdventureWorks2014	CreditCard	ExpYear	-1
-- Not computed
###########################################################
# AdventureWorks2014	CreditCard	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Culture	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Currency	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	Currency	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	CurrencyRate	AverageRate	-1
-- Not computed
###########################################################
# AdventureWorks2014	CurrencyRate	EndOfDayRate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Customer	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	Customer	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Department	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	Department	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Document	Revision	-1
-- Not computed
###########################################################
# AdventureWorks2014	Document	ChangeNumber	-1
-- Not computed
###########################################################
# AdventureWorks2014	Document	Status	-1
-- Not computed
###########################################################
# AdventureWorks2014	Document	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	Document	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	EmailAddress	EmailAddress	-1
-- Not computed
###########################################################
# AdventureWorks2014	EmailAddress	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	EmailAddress	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Employee	NationalIDNumber	-1
-- Not computed
###########################################################
# AdventureWorks2014	Employee	OrganizationNode	-1
-- Not computed
###########################################################
# AdventureWorks2014	Employee	JobTitle	-1
-- Not computed
###########################################################
# AdventureWorks2014	Employee	BirthDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Employee	MaritalStatus	-1
-- Not computed
###########################################################
# AdventureWorks2014	Employee	Gender	-1
-- Not computed
###########################################################
# AdventureWorks2014	Employee	SalariedFlag	-1
-- Not computed
###########################################################
# AdventureWorks2014	Employee	VacationHours	-1
-- Not computed
###########################################################
# AdventureWorks2014	Employee	SickLeaveHours	-1
-- Not computed
###########################################################
# AdventureWorks2014	Employee	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	Employee	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	EmployeeDepartmentHistory	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	EmployeePayHistory	Rate	-1
-- Not computed
###########################################################
# AdventureWorks2014	EmployeePayHistory	PayFrequency	-1
-- Not computed
###########################################################
# AdventureWorks2014	EmployeePayHistory	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ErrorLog	ErrorTime	-1
-- Not computed
###########################################################
# AdventureWorks2014	ErrorLog	UserName	-1
-- Not computed
###########################################################
# AdventureWorks2014	ErrorLog	ErrorNumber	-1
-- Not computed
###########################################################
# AdventureWorks2014	ErrorLog	ErrorSeverity	-1
-- Not computed
###########################################################
# AdventureWorks2014	ErrorLog	ErrorState	-1
-- Not computed
###########################################################
# AdventureWorks2014	ErrorLog	ErrorProcedure	-1
-- Not computed
###########################################################
# AdventureWorks2014	ErrorLog	ErrorLine	-1
-- Not computed
###########################################################
# AdventureWorks2014	ErrorLog	ErrorMessage	-1
-- Not computed
###########################################################
# AdventureWorks2014	Illustration	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	JobCandidate	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Location	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	Location	Availability	-1
-- Not computed
###########################################################
# AdventureWorks2014	Location	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Password	PasswordHash	-1
-- Not computed
###########################################################
# AdventureWorks2014	Password	PasswordSalt	-1
-- Not computed
###########################################################
# AdventureWorks2014	Password	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	Password	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Person	NameStyle	-1
-- Not computed
###########################################################
# AdventureWorks2014	Person	Title	-1
-- Not computed
###########################################################
# AdventureWorks2014	Person	FirstName	-1
-- Not computed
###########################################################
# AdventureWorks2014	Person	MiddleName	-1
-- Not computed
###########################################################
# AdventureWorks2014	Person	LastName	-1
-- Not computed
###########################################################
# AdventureWorks2014	Person	Suffix	-1
-- Not computed
###########################################################
# AdventureWorks2014	Person	EmailPromotion	-1
-- Not computed
###########################################################
# AdventureWorks2014	Person	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	Person	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	PersonCreditCard	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	PersonPhone	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	PhoneNumberType	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	PhoneNumberType	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	ProductNumber	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	Color	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	ListPrice	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	Size	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	Weight	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	DaysToManufacture	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	ProductLine	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	Class	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	Style	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	SellStartDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	DiscontinuedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	Product	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductCategory	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductCategory	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductCategory	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductCostHistory	StandardCost	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductCostHistory	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductDescription	Description	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductDescription	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductDescription	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductDocument	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductInventory	Shelf	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductInventory	Bin	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductInventory	Quantity	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductInventory	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductInventory	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductListPriceHistory	ListPrice	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductListPriceHistory	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductModel	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductModel	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductModel	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductModelIllustration	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductModelProductDescriptionCulture	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductPhoto	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductProductPhoto	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductReview	ReviewerName	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductReview	ReviewDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductReview	EmailAddress	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductReview	Rating	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductReview	Comments	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductSubcategory	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductSubcategory	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductSubcategory	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductVendor	MinOrderQty	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductVendor	MaxOrderQty	-1
-- Not computed
###########################################################
# AdventureWorks2014	ProductVendor	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	PurchaseOrderDetail	DueDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	PurchaseOrderDetail	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	PurchaseOrderHeader	RevisionNumber	-1
-- Not computed
###########################################################
# AdventureWorks2014	PurchaseOrderHeader	Status	-1
-- Not computed
###########################################################
# AdventureWorks2014	PurchaseOrderHeader	OrderDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	PurchaseOrderHeader	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesOrderDetail	CarrierTrackingNumber	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesOrderDetail	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesOrderHeader	RevisionNumber	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesOrderHeader	Status	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesOrderHeader	PurchaseOrderNumber	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesOrderHeader	CreditCardApprovalCode	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesOrderHeader	Comment	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesOrderHeader	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesPerson	SalesQuota	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesPerson	CommissionPct	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesPerson	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesPerson	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesPersonQuotaHistory	SalesQuota	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesPersonQuotaHistory	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesReason	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesReason	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesTaxRate	TaxType	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesTaxRate	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesTaxRate	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesTerritory	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesTerritory	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesTerritory	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	SalesTerritoryHistory	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	ScrapReason	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	ScrapReason	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Shift	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ShipMethod	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	ShipMethod	ShipBase	-1
-- Not computed
###########################################################
# AdventureWorks2014	ShipMethod	ShipRate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ShipMethod	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	ShipMethod	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	ShoppingCartItem	ShoppingCartID	-1
-- Not computed
###########################################################
# AdventureWorks2014	ShoppingCartItem	Quantity	-1
-- Not computed
###########################################################
# AdventureWorks2014	ShoppingCartItem	DateCreated	-1
-- Not computed
###########################################################
# AdventureWorks2014	ShoppingCartItem	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	SpecialOffer	Description	-1
-- Not computed
###########################################################
# AdventureWorks2014	SpecialOffer	EndDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	SpecialOffer	MaxQty	-1
-- Not computed
###########################################################
# AdventureWorks2014	SpecialOffer	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	SpecialOffer	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	SpecialOfferProduct	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	SpecialOfferProduct	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	StateProvince	StateProvinceCode	-1
-- Not computed
###########################################################
# AdventureWorks2014	StateProvince	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	StateProvince	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	StateProvince	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	Store	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	Store	rowguid	-1
-- Not computed
###########################################################
# AdventureWorks2014	Store	ModifiedDate	-1
-- Not computed
###########################################################
# AdventureWorks2014	TransactionHistory	ReferenceOrderID	-1
-- Not computed
###########################################################
# AdventureWorks2014	TransactionHistory	Quantity	-1
-- Not computed
###########################################################
# AdventureWorks2014	TransactionHistoryArchive	ReferenceOrderID	-1
-- Not computed
###########################################################
# AdventureWorks2014	TransactionHistoryArchive	Quantity	-1
-- Not computed
###########################################################
# AdventureWorks2014	UnitMeasure	Name	-1
-- Not computed
###########################################################
# AdventureWorks2014	UnitMeasure	ModifiedDate	-1
-- Not computed
###########################################################

import os
import configparser
import csv
import re

# Path to the 'uni' folder
base_path = 'uni'

# Output CSV file
output_csv = 'experiment_config_summary.csv'

# Fields to extract
fields = [
    'experiment',
    'data_sharing_strategy',
    'different_formula_max_tries',
    'formula_max_subtries',
    'temperature',
    'total_time_minutes',
    'computed_values_count',
    'total_enrollments',
    'gpa',
    'pass_rate',
    'other_accurate_columns'
]

# Prepare CSV writing
with open(output_csv, mode='w', newline='') as file:
    writer = csv.DictWriter(file, fieldnames=fields)
    writer.writeheader()

    # Loop through experiment folders
    for i in range(90):
        folder_name = f'experiment_{i}'
        config_path = os.path.join(base_path, folder_name, 'config.ini')
        output_path = os.path.join(base_path, folder_name, 'output_uni_0.txt')

        row = {'experiment': folder_name}

        # Read config.ini
        if os.path.exists(config_path):
            config = configparser.ConfigParser()
            config.read(config_path)

            row.update({
                'data_sharing_strategy': config.get('DataSharing', 'data_sharing_strategy', fallback=''),
                'different_formula_max_tries': config.get('Execution', 'different_formula_max_tries', fallback=''),
                'formula_max_subtries': config.get('Execution', 'formula_max_subtries', fallback=''),
                'temperature': config.get('LLM', 'temperature', fallback='')
            })
        else:
            print(f"Missing config.ini in {folder_name}")

        # Read output_uni_0.txt
        total_time = ''
        computed_values = ''
        enrollments_flag = 0
        gpa_flag = 0
        pass_rate_flag = 0
        other_accurate_count = 0

        if os.path.exists(output_path):
            with open(output_path, 'r') as f:
                for line in f:
                    if line.startswith('total_time is'):
                        match = re.search(r'total_time is ([\d.]+) mins', line)
                        if match:
                            total_time = match.group(1)
                    elif 'Number of computed values out of all non-key columns' in line:
                        match = re.search(r'Number of computed values out of all non-key columns: (\d+)/\d+', line)
                        if match:
                            computed_values = match.group(1)
                    elif 'Table: Course, Column: total_enrollments, Accuracy: 100%' in line:
                        enrollments_flag = 1
                    elif 'Table: Student, Column: gpa, Accuracy: 100%' in line:
                        gpa_flag = 1
                    elif 'Table: Course, Column: pass_rate, Accuracy: 100%' in line:
                        pass_rate_flag = 1
                    elif re.match(r'Table: .+, Column: .+, Accuracy: 100%', line):
                        if not any(x in line for x in [
                            'Table: Course, Column: total_enrollments',
                            'Table: Student, Column: gpa',
                            'Table: Course, Column: pass_rate'
                        ]):
                            other_accurate_count += 1
        else:
            print(f"Missing output_uni_0.txt in {folder_name}")

        row['total_time_minutes'] = total_time
        row['computed_values_count'] = computed_values
        row['total_enrollments'] = enrollments_flag
        row['gpa'] = gpa_flag
        row['pass_rate'] = pass_rate_flag
        row['other_accurate_columns'] = other_accurate_count
        writer.writerow(row)